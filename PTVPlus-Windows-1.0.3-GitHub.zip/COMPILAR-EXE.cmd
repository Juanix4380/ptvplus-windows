@echo off
setlocal
cd /d "%~dp0"
set "ROOT=%~dp0"
echo ===========================================================
echo    PTV PLUS WINDOWS 1.0.2 - GENERAR ARCHIVO EXE
 echo ===========================================================
echo.
echo Este proceso requiere internet y Windows 10/11 (64 bits).
echo Descarga solo .NET oficial de Microsoft y libmpv oficial.
echo El ejecutable corregido aparecera en la carpeta resultado.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%ROOT%COMPILAR-EXE.ps1"
set "RC=%ERRORLEVEL%"
echo.
if %RC% EQU 0 (
 echo EXITO: "resultado\PTVPlus.exe"
 echo Puedes copiar ese EXE donde quieras.
) else (
 echo Error en la compilacion ^(codigo %RC%^).
 echo La aplicacion antigua no fue reemplazada.
)
echo.
pause
exit /b %RC%
