$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Set-Location $PSScriptRoot

function Say([string]$s) { Write-Host "`n==> $s" -ForegroundColor Cyan }
try {
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Este proyecto necesita Windows de 64 bits.' }
    $project = Join-Path $PSScriptRoot 'src\PTVPlus\PTVPlus.csproj'
    if (-not (Test-Path $project)) { throw 'No aparece el proyecto: src\PTVPlus\PTVPlus.csproj' }

    Say 'Revisando .NET SDK 10'
    $dotnet = Get-Command dotnet -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -ErrorAction SilentlyContinue
    $hasTen = $false
    if ($dotnet) {
        try { $hasTen = @(& $dotnet --list-sdks | Where-Object { $_ -match '^10\.' }).Count -gt 0 }
        catch { $hasTen = $false }
    }
    if (-not $hasTen) {
        $local = Join-Path $PSScriptRoot '.tools\dotnet'
        $dotnet = Join-Path $local 'dotnet.exe'
        if (-not (Test-Path $dotnet)) {
            New-Item -ItemType Directory -Path $local -Force | Out-Null
            $installer = Join-Path $PSScriptRoot '.tools\dotnet-install.ps1'
            Say 'Descargando instalador oficial de Microsoft'
            Invoke-WebRequest -Uri 'https://dot.net/v1/dotnet-install.ps1' -OutFile $installer -UseBasicParsing
            Say 'Instalando .NET SDK 10 localmente (sin cambiar el sistema)'
            & $installer -Channel '10.0' -InstallDir $local -NoPath
            if ($LASTEXITCODE -ne 0) { throw 'Fallo la instalacion de .NET SDK 10.' }
        }
        if (-not (Test-Path $dotnet)) { throw 'No se encuentra dotnet.exe.' }
    }
    Say 'Revisando motor de reproduccion libmpv'
    $native = Join-Path $PSScriptRoot 'src\PTVPlus\libmpv-2.dll'
    if (-not (Test-Path $native)) {
        $url = 'https://github.com/mpv-player/mpv/releases/download/v0.42.0/libmpv-v0.42.0-x86_64-w64-mingw32-lgpl.zip'
        $package = Join-Path $PSScriptRoot '.tools\libmpv.zip'
        New-Item -ItemType Directory -Path (Split-Path $package) -Force | Out-Null
        Say 'Descargando libmpv 0.42.0 Windows x64 de GitHub oficial'
        Invoke-WebRequest -Uri $url -OutFile $package -UseBasicParsing
        $expected = '8e5f77430efc53ef175804ba6618527e3af0448a0dcabf04d3cc72659d1a6fce'
        $actual = (Get-FileHash -Algorithm SHA256 -Path $package).Hash.ToLowerInvariant()
        if ($actual -ne $expected) { throw "El motor de video no paso la comprobacion SHA256: $actual" }
        $extracted = Join-Path $PSScriptRoot '.tools\libmpv-extracted'
        Expand-Archive -Path $package -DestinationPath $extracted -Force
        $dll = Get-ChildItem -Path $extracted -Filter 'libmpv-2.dll' -File -Recurse | Select-Object -First 1
        if (-not $dll) { throw 'No se encuentra libmpv-2.dll en el paquete oficial.' }
        Copy-Item $dll.FullName $native -Force
        $vulkan = Get-ChildItem -Path $extracted -Filter 'vulkan-1.dll' -File -Recurse | Select-Object -First 1
        if ($vulkan) { Copy-Item $vulkan.FullName (Join-Path $PSScriptRoot 'src\PTVPlus\vulkan-1.dll') -Force }
    }
    Say 'Compilando PTVPlus.exe (Windows x64, un solo archivo)'
    $dest = Join-Path $PSScriptRoot 'resultado'
    & $dotnet publish $project --configuration Release --runtime win-x64 --self-contained true --output $dest
    if ($LASTEXITCODE -ne 0) { throw 'Fallo la compilacion .NET. Revisa el error detallado arriba.' }
    $exe = Join-Path $dest 'PTVPlus.exe'
    if (-not (Test-Path $exe)) { throw 'La compilacion termino sin crear PTVPlus.exe.' }
    Say "ARCHIVO GENERADO: $exe"
    exit 0
}
catch {
    Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
