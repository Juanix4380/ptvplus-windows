# PTV Plus Windows 1.0.3 — listo para compilar en GitHub Actions

## Subir y compilar en GitHub

1. Extrae **TODO** el ZIP en tu computadora (no subas sólo el ZIP sin extraer).
2. Crea un repositorio privado en GitHub. En **Add file > Upload files**, sube el contenido extraído con las carpetas `src` y `.github` y los archivos de la raíz.
3. Muy importante: confirma que GitHub tenga **`.github/workflows/build.yml`**. Sin ese archivo GitHub no sabe cómo compilar. Si tu navegador omitió la carpeta `.github`, crea ese archivo en GitHub con **Add file > Create new file** y el nombre `.github/workflows/build.yml`; copia el archivo de este proyecto.
4. Ve a **Actions > Compilar PTV Plus Windows > Run workflow > Run workflow**. También se dispara al subir cambios en `src` o en el workflow.
5. Al acabar con marca verde, entra al trabajo y descarga el artefacto **PTVPlus-Windows-1.0.3-EXE**. Descomprime ese artefacto: dentro estará `PTVPlus.exe`.
6. Si la ejecución sale roja, abre el paso rojo y comparte el error literal para corregir la compilación. No sustituyas el .exe actual hasta verificar el nuevo.

## Archivos incluidos

- `src/PTVPlus/` — código fuente WPF .NET 10 para Windows 10/11 x64.
- `.github/workflows/build.yml` — compila automáticamente en un equipo Windows de GitHub, con .NET 10 y libmpv comprobado por SHA-256.
- `COMPILAR-EXE.cmd` — alternativa para compilar directamente en tu Windows.

## Qué cambió en 1.0.3

- El aviso de error por caída del panel deja de abrir un gran cuadro que tape toda la pantalla. La pantalla muestra el error sin ocultar los controles.
- Reintentos breves cuando `/session/status` falla por red, servidor 5xx, 408 o 429. **No se elimina la validación de la cuenta** ni se reproduce con autorización desconocida.
- Log de comprobación del panel en `%LOCALAPPDATA%\PTVPlus\log.txt` para distinguir error de DNS/TLS/HTTP de cuenta rechazada. No copiar ni publicar tu contraseña.
- Atrás visible en la esquina superior izquierda de TV ampliada aunque se oculten los demás controles.
- Nombres largos de categorías y canales limitados al ancho disponible.
- Controles de películas y series en las orillas inferiores; al reducir el tamaño, se acomodan en dos filas para que nunca se monten.
- Marcos de multipantalla: nombres limitados dentro de cada mosaico.
- Sin VLC, reproductores externos ni otras ventanas visibles de video; la app conserva su overlay transparente integrado para superponer controles sobre libmpv.

## Limitaciones

Este es el **proyecto fuente**; el `.exe` se genera al ejecutar Actions. Aquí no se ha realizado una compilación real en Windows ni una prueba contra tu panel privado. No se puede afirmar que el error de verificación del panel esté resuelto sin los datos de diagnóstico y el comportamiento en una ejecución real. Si el servicio Cloud está caído, el código seguirá sin autorizar la reproducción.
