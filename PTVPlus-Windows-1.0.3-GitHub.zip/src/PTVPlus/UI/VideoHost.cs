using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using PTVPlus.Core;

namespace PTVPlus.UI
{
    internal static class Native
    {
        public const int WS_CHILD = 0x40000000;
        public const int WS_VISIBLE = 0x10000000;
        public const int WS_CLIPCHILDREN = 0x02000000;
        public const int WS_CLIPSIBLINGS = 0x04000000;
        public const int WS_DISABLED = 0x08000000;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct WNDCLASSEX
        {
            public int cbSize;
            public int style;
            public IntPtr lpfnWndProc;
            public int cbClsExtra;
            public int cbWndExtra;
            public IntPtr hInstance;
            public IntPtr hIcon;
            public IntPtr hCursor;
            public IntPtr hbrBackground;
            public string lpszMenuName;
            public string lpszClassName;
            public IntPtr hIconSm;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern ushort RegisterClassEx(ref WNDCLASSEX wc);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern IntPtr CreateWindowEx(int exStyle, string className, string windowName, int style,
            int x, int y, int width, int height, IntPtr parent, IntPtr menu, IntPtr instance, IntPtr param);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool DestroyWindow(IntPtr hwnd);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr GetModuleHandle(string name);

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        public static extern IntPtr GetProcAddress(IntPtr module, string name);

        [DllImport("gdi32.dll")]
        public static extern IntPtr GetStockObject(int obj);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr LoadCursor(IntPtr instance, IntPtr cursor);

        [DllImport("dwmapi.dll")]
        public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hwnd);

        private static bool _registered;
        public const string VideoClass = "PTVPlusVideo";

        /// <summary>Clase de ventana con fondo negro (sin parpadeo gris mientras carga el video).</summary>
        public static void RegisterVideoClass()
        {
            if (_registered) return;
            _registered = true;
            var wc = new WNDCLASSEX
            {
                cbSize = Marshal.SizeOf(typeof(WNDCLASSEX)),
                style = 0x0003, // CS_HREDRAW | CS_VREDRAW
                lpfnWndProc = GetProcAddress(GetModuleHandle("user32.dll"), "DefWindowProcW"),
                hInstance = GetModuleHandle(null),
                hCursor = LoadCursor(IntPtr.Zero, new IntPtr(32512)),
                hbrBackground = GetStockObject(4), // BLACK_BRUSH
                lpszClassName = VideoClass
            };
            if (RegisterClassEx(ref wc) == 0) Log.Write("RegisterClassEx video: " + Marshal.GetLastWin32Error());
        }

        /// <summary>Barra de título oscura (Windows 10/11).</summary>
        public static void DarkTitle(IntPtr hwnd)
        {
            try
            {
                int on = 1;
                if (DwmSetWindowAttribute(hwnd, 20, ref on, 4) != 0) DwmSetWindowAttribute(hwnd, 19, ref on, 4);
                int caption = 0x00120D0B; // COLORREF 0x00BBGGRR: #0B0D12 aprox.
                DwmSetWindowAttribute(hwnd, 35, ref caption, 4);
            }
            catch { }
        }
    }

    /// <summary>
    /// Superficie donde mpv dibuja el video (una ventana hija dentro de la ventana de la app).
    /// No recibe el ratón: los clics pasan a la capa de controles.
    /// </summary>
    public sealed class VideoHost : HwndHost
    {
        public IntPtr Hwnd { get; private set; }
        public event Action<IntPtr> Created;

        protected override HandleRef BuildWindowCore(HandleRef hwndParent)
        {
            Native.RegisterVideoClass();
            Hwnd = Native.CreateWindowEx(0, Native.VideoClass, "", Native.WS_CHILD | Native.WS_VISIBLE | Native.WS_CLIPCHILDREN | Native.WS_CLIPSIBLINGS | Native.WS_DISABLED,
                0, 0, 16, 16, hwndParent.Handle, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
            if (Hwnd == IntPtr.Zero)
            {
                Log.Write("CreateWindowEx video: " + Marshal.GetLastWin32Error());
                Hwnd = Native.CreateWindowEx(0, "static", "", Native.WS_CHILD | Native.WS_VISIBLE | Native.WS_DISABLED,
                    0, 0, 16, 16, hwndParent.Handle, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
            }
            var h = Hwnd;
            Dispatcher.BeginInvoke(new Action(() => Created?.Invoke(h)));
            return new HandleRef(this, Hwnd);
        }

        protected override void DestroyWindowCore(HandleRef hwnd)
        {
            Native.DestroyWindow(hwnd.Handle);
            Hwnd = IntPtr.Zero;
        }
    }
}
