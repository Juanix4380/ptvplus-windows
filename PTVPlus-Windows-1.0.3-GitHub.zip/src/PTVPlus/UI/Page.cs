using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace PTVPlus.UI
{
    /// <summary>Una pantalla de la app (todas viven dentro de la misma ventana).</summary>
    public abstract class Page : Grid
    {
        protected MainWindow Main => MainWindow.Instance;

        /// <summary>Dónde va el video principal en esta pantalla (null = sin video).</summary>
        public virtual FrameworkElement VideoSlot => null;

        /// <summary>El video ocupa toda la ventana (TV en vivo, reproductor).</summary>
        public virtual bool VideoFull => false;

        /// <summary>Parte de arriba que tapa el video al desplazar (el video se oculta si queda debajo).</summary>
        public virtual double VideoTopLimit => 0;

        /// <summary>Contenido encima del video (controles, listas). Null = nada.</summary>
        public virtual UIElement OverlayContent => null;

        public virtual void OnShow() { }
        public virtual void OnHide() { }
        public virtual bool OnKey(KeyEventArgs e) => false;
        public virtual bool OnBack() => false;
        public virtual void FocusFirst() { }

        /// <summary>Rectángulo del video ya colocado (para poner etiquetas encima en la capa).</summary>
        public virtual void OnVideoPlaced(Rect r, bool visible) { }

        /// <summary>Mover el foco en una dirección (flechas) dentro de esta pantalla.</summary>
        protected static bool Move(FocusNavigationDirection dir)
        {
            var el = Keyboard.FocusedElement as UIElement;
            return el != null && el.MoveFocus(new TraversalRequest(dir));
        }
    }
}
