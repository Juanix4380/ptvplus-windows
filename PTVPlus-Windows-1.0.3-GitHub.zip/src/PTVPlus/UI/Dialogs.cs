using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace PTVPlus.UI
{
    /// <summary>Ventanas de aviso premium dentro de la misma ventana (encima de todo, también del video).</summary>
    public static class Dialogs
    {
        private static OverlayWindow O => MainWindow.Instance?.Overlay;

        private static Border Card(double width)
        {
            return new Border
            {
                Width = width,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                CornerRadius = new CornerRadius(24),
                BorderBrush = Ui.Hex("#55A782E8"),
                BorderThickness = new Thickness(1.2),
                Background = Ui.Gradient("#FF221838", "#FF120D1C", 90),
                Padding = new Thickness(30, 26, 30, 24),
                Effect = Ui.Shadow(40, 0.7)
            };
        }

        private static void Open(Border card, UIElement focus)
        {
            var o = O;
            if (o == null) return;
            o.OpenDialog(card);
            card.Dispatcher.BeginInvoke(new Action(() => focus?.Focus()), System.Windows.Threading.DispatcherPriority.Input);
        }

        public static void Close() => O?.CloseDialog();

        public static void Message(string title, string message, Action ok = null)
        {
            var card = Card(520);
            var sp = new StackPanel();
            sp.Children.Add(Ui.T(title, 22, Ui.B("Text"), FontWeights.Bold));
            var m = Ui.T(message, 15.5, Ui.B("Text2"));
            m.TextWrapping = TextWrapping.Wrap;
            m.Margin = new Thickness(0, 12, 0, 22);
            sp.Children.Add(m);
            var btn = Ui.Primary("Aceptar", () => { Close(); ok?.Invoke(); });
            btn.HorizontalAlignment = HorizontalAlignment.Right;
            btn.MinWidth = 140;
            sp.Children.Add(btn);
            card.Child = sp;
            Open(card, btn);
        }

        public static void Confirm(string title, string message, string okText, Action ok, string cancelText = "Cancelar")
        {
            var card = Card(540);
            var sp = new StackPanel();
            sp.Children.Add(Ui.T(title, 22, Ui.B("Text"), FontWeights.Bold));
            var m = Ui.T(message, 15.5, Ui.B("Text2"));
            m.TextWrapping = TextWrapping.Wrap;
            m.Margin = new Thickness(0, 12, 0, 22);
            sp.Children.Add(m);
            var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            var cancel = Ui.Pill(cancelText, Close);
            cancel.Margin = new Thickness(0, 0, 12, 0);
            var yes = Ui.Primary(okText, () => { Close(); ok?.Invoke(); });
            row.Children.Add(cancel);
            row.Children.Add(yes);
            sp.Children.Add(row);
            card.Child = sp;
            Open(card, yes);
        }

        /// <summary>Lista de opciones (búfer, idioma, pistas de audio…); la elegida lleva ✓.</summary>
        public static void Choice(string title, IList<string> options, int selected, Action<int> pick)
        {
            var card = Card(460);
            var sp = new StackPanel();
            var t = Ui.T(title, 21, Ui.B("Text"), FontWeights.Bold);
            t.Margin = new Thickness(4, 0, 0, 14);
            sp.Children.Add(t);
            var list = new StackPanel();
            Button first = null;
            for (int i = 0; i < options.Count; i++)
            {
                int index = i;
                var g = new Grid();
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                var label = Ui.T(options[i], 16, Ui.B("Text"), i == selected ? FontWeights.Bold : FontWeights.Normal);
                g.Children.Add(label);
                if (i == selected)
                {
                    var check = Ui.Icon(G.Check, 16, Ui.B("Accent"));
                    Grid.SetColumn(check, 1);
                    g.Children.Add(check);
                }
                var b = Ui.Btn("RowBtn", g, () => { Close(); pick?.Invoke(index); });
                b.Margin = new Thickness(0, 0, 0, 6);
                list.Children.Add(b);
                if (i == selected || first == null) first = b;
            }
            sp.Children.Add(new ScrollViewer
            {
                Content = list,
                MaxHeight = 460,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Focusable = false
            });
            card.Child = sp;
            Open(card, first);
        }

        /// <summary>PIN de 4 dígitos (teclado o ratón).</summary>
        public static void Pin(string title, string subtitle, Action<string> done)
        {
            var card = Card(420);
            var sp = new StackPanel();
            sp.Children.Add(Ui.T(title, 22, Ui.B("Text"), FontWeights.Bold));
            if (!string.IsNullOrEmpty(subtitle))
            {
                var st = Ui.T(subtitle, 14.5, Ui.B("Text2"));
                st.Margin = new Thickness(0, 6, 0, 0);
                st.TextWrapping = TextWrapping.Wrap;
                sp.Children.Add(st);
            }
            var dots = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 22, 0, 18) };
            var dotList = new List<Border>();
            for (int i = 0; i < 4; i++)
            {
                var d = new Border
                {
                    Width = 46, Height = 54, CornerRadius = new CornerRadius(12), Margin = new Thickness(6, 0, 6, 0),
                    Background = Ui.Hex("#FF161124"), BorderBrush = Ui.Hex("#FF3A2D58"), BorderThickness = new Thickness(1.5)
                };
                dotList.Add(d);
                dots.Children.Add(d);
            }
            sp.Children.Add(dots);
            string value = "";
            Action paint = () =>
            {
                for (int i = 0; i < 4; i++)
                {
                    dotList[i].Child = i < value.Length ? Ui.T("●", 22, Ui.B("Accent")) : null;
                    if (dotList[i].Child is TextBlock tb)
                    {
                        tb.HorizontalAlignment = HorizontalAlignment.Center;
                        tb.VerticalAlignment = VerticalAlignment.Center;
                    }
                    dotList[i].BorderBrush = i == value.Length ? Ui.B("Accent") : Ui.Hex("#FF3A2D58");
                }
            };
            Action<string> press = null;
            press = k =>
            {
                if (k == "<") { if (value.Length > 0) value = value.Substring(0, value.Length - 1); }
                else if (value.Length < 4) value += k;
                paint();
                if (value.Length == 4)
                {
                    string v = value;
                    Close();
                    done?.Invoke(v);
                }
            };
            var pad = new UniformGrid { Columns = 3, HorizontalAlignment = HorizontalAlignment.Center };
            Button firstKey = null;
            foreach (var k in new[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "<" })
            {
                if (k.Length == 0) { pad.Children.Add(new Border()); continue; }
                string key = k;
                var b = Ui.Btn("Pill", k == "<" ? (object)Ui.Icon(G.Back, 16) : k, () => press(key));
                b.Width = 84;
                b.Height = 52;
                b.FontSize = 20;
                b.Margin = new Thickness(5);
                pad.Children.Add(b);
                if (firstKey == null) firstKey = b;
            }
            sp.Children.Add(pad);
            var cancel = Ui.Pill("Cancelar", Close);
            cancel.HorizontalAlignment = HorizontalAlignment.Center;
            cancel.Margin = new Thickness(0, 14, 0, 0);
            sp.Children.Add(cancel);
            card.Child = sp;
            // También con los números del teclado.
            card.PreviewKeyDown += (s, e) =>
            {
                string d = null;
                if (e.Key >= Key.D0 && e.Key <= Key.D9) d = ((int)(e.Key - Key.D0)).ToString();
                else if (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9) d = ((int)(e.Key - Key.NumPad0)).ToString();
                else if (e.Key == Key.Back) d = "<";
                if (d != null)
                {
                    press(d);
                    e.Handled = true;
                }
            };
            paint();
            Open(card, firstKey);
        }

        /// <summary>Escribir un texto (nombre del perfil, contraseña de la cuenta…).</summary>
        public static void Input(string title, string hint, string initial, bool password, Action<string> done)
        {
            var card = Card(500);
            var sp = new StackPanel();
            sp.Children.Add(Ui.T(title, 22, Ui.B("Text"), FontWeights.Bold));
            var h = Ui.T(hint, 14.5, Ui.B("Text2"));
            h.Margin = new Thickness(0, 6, 0, 14);
            h.TextWrapping = TextWrapping.Wrap;
            sp.Children.Add(h);
            Control field;
            Func<string> read;
            if (password)
            {
                var pb = new PasswordBox { Style = Ui.S("PassField") };
                field = pb;
                read = () => pb.Password;
            }
            else
            {
                var tb = new TextBox { Style = Ui.S("Field"), Text = initial ?? "" };
                field = tb;
                read = () => tb.Text;
            }
            sp.Children.Add(field);
            var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 20, 0, 0) };
            var cancel = Ui.Pill("Cancelar", Close);
            cancel.Margin = new Thickness(0, 0, 12, 0);
            Action ok = () => { string v = read(); Close(); done?.Invoke(v); };
            var yes = Ui.Primary("Aceptar", ok);
            row.Children.Add(cancel);
            row.Children.Add(yes);
            sp.Children.Add(row);
            field.KeyDown += (s, e) => { if (e.Key == Key.Enter) { e.Handled = true; ok(); } };
            card.Child = sp;
            Open(card, field);
        }
    }
}
