using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using PTVPlus.Core;

namespace PTVPlus.UI
{
    /// <summary>Piezas de interfaz reutilizables (textos, íconos, tarjetas) con el estilo PTV PLUS.</summary>
    public static class Ui
    {
        public static Brush B(string key) => (Brush)Application.Current.Resources[key];
        public static Style S(string key) => (Style)Application.Current.Resources[key];
        public static FontFamily Font => (FontFamily)Application.Current.Resources["Font"];
        public static FontFamily Icons => (FontFamily)Application.Current.Resources["Icons"];

        public static SolidColorBrush Hex(string hex)
        {
            var b = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
            b.Freeze();
            return b;
        }

        public static TextBlock T(string text, double size = 15, Brush fg = null, FontWeight? weight = null, double maxLines = 0)
        {
            var t = new TextBlock
            {
                Text = text ?? "",
                FontSize = size,
                FontFamily = Font,
                Foreground = fg ?? B("Text"),
                FontWeight = weight ?? FontWeights.Normal,
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            if (maxLines > 1)
            {
                t.TextWrapping = TextWrapping.Wrap;
                t.MaxHeight = size * 1.36 * maxLines;
            }
            return t;
        }

        public static TextBlock Icon(string glyph, double size = 18, Brush fg = null)
        {
            return new TextBlock
            {
                Text = glyph,
                FontFamily = Icons,
                FontSize = size,
                Foreground = fg ?? B("Text"),
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };
        }

        /// <summary>Contenido de botón: ícono + texto.</summary>
        public static StackPanel IconText(string glyph, string text, double size = 15)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            if (!string.IsNullOrEmpty(glyph))
            {
                var ic = new TextBlock
                {
                    Text = glyph, FontFamily = Icons, FontSize = size + 1, VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 10, 0)
                };
                ic.SetBinding(TextBlock.ForegroundProperty, new System.Windows.Data.Binding("Foreground")
                {
                    RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.FindAncestor, typeof(Button), 1)
                });
                sp.Children.Add(ic);
            }
            var tb = new TextBlock { Text = text, FontSize = size, VerticalAlignment = VerticalAlignment.Center, FontFamily = Font };
            tb.SetBinding(TextBlock.ForegroundProperty, new System.Windows.Data.Binding("Foreground")
            {
                RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.FindAncestor, typeof(Button), 1)
            });
            sp.Children.Add(tb);
            return sp;
        }

        public static Button Btn(string styleKey, object content, Action click)
        {
            var b = new Button { Style = S(styleKey), Content = content };
            if (click != null) b.Click += (s, e) => click();
            return b;
        }

        public static Button Pill(string text, Action click, string glyph = null) => Btn("Pill", glyph == null ? (object)text : IconText(glyph, text), click);
        public static Button Primary(string text, Action click, string glyph = null) => Btn("Primary", glyph == null ? (object)text : IconText(glyph, text), click);
        public static Button Round(string glyph, Action click, string tip = null)
        {
            var b = Btn("Round", glyph, click);
            if (tip != null) b.ToolTip = tip;
            return b;
        }

        public static Image Picture(string url, double w, double h, int decode, Stretch stretch = Stretch.UniformToFill)
        {
            var img = new Image { Width = w, Height = h, Stretch = stretch };
            RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);
            Images.Load(img, url, decode);
            return img;
        }

        public static Geometry Rounded(double w, double h, double r)
        {
            var g = new RectangleGeometry(new Rect(0, 0, w, h), r, r);
            g.Freeze();
            return g;
        }

        public static LinearGradientBrush Gradient(string a, string b, double angle = 90)
        {
            var g = new LinearGradientBrush((Color)ColorConverter.ConvertFromString(a), (Color)ColorConverter.ConvertFromString(b), angle);
            g.Freeze();
            return g;
        }

        /// <summary>Tarjeta morada cuando no hay imagen (con el nombre).</summary>
        public static Border Placeholder(string title, double w, double h)
        {
            var b = new Border
            {
                Width = w, Height = h, CornerRadius = new CornerRadius(12),
                Background = Gradient("#FF2A1E46", "#FF140F22", 90)
            };
            b.Child = new TextBlock
            {
                Text = title ?? "", Foreground = B("Text2"), FontSize = 13, FontFamily = Font, TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10),
                MaxHeight = 80, TextTrimming = TextTrimming.CharacterEllipsis
            };
            return b;
        }

        /// <summary>Póster vertical con título abajo (y barra de avance si se empezó a ver).</summary>
        public static Button Poster(Item it, double w, Action click, int percent = -1, string subtitle = null)
        {
            double h = Math.Round(w * 1.5);
            var root = new StackPanel { Width = w };
            var frame = new Grid { Width = w, Height = h, Clip = Rounded(w, h, 12) };
            frame.Children.Add(Placeholder(it.Title, w, h));
            if (!string.IsNullOrEmpty(it.Icon)) frame.Children.Add(Picture(it.Icon, w, h, (int)(w * 1.6)));
            if (it.Rating > 0)
            {
                var badge = new Border
                {
                    Background = Hex("#CC0B0812"), CornerRadius = new CornerRadius(8), Padding = new Thickness(7, 2, 7, 2),
                    HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(6),
                    Child = T(it.RatingText, 11, Hex("#FFFFD27A"), FontWeights.SemiBold)
                };
                frame.Children.Add(badge);
            }
            if (percent > 0)
            {
                var bar = new Grid { Height = 4, VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(8, 0, 8, 8) };
                bar.Children.Add(new Border { Background = Hex("#55FFFFFF"), CornerRadius = new CornerRadius(2) });
                bar.Children.Add(new Border
                {
                    Background = B("Accent"), CornerRadius = new CornerRadius(2), HorizontalAlignment = HorizontalAlignment.Left,
                    Width = Math.Max(4, (w - 16) * percent / 100.0)
                });
                frame.Children.Add(bar);
            }
            root.Children.Add(frame);
            var title = T(it.Title, 13.5, B("Text"), FontWeights.SemiBold);
            title.Margin = new Thickness(2, 8, 2, 0);
            title.TextWrapping = TextWrapping.Wrap;
            title.MaxHeight = 38;
            root.Children.Add(title);
            var sub = T(subtitle ?? it.YearOrName, 12, B("Text3"));
            sub.Margin = new Thickness(2, 2, 2, 0);
            root.Children.Add(sub);
            var b = new Button { Style = S("CardBtn"), Content = root, Tag = h + 6, Margin = new Thickness(0, 0, 18, 0) };
            b.Click += (s, e) => click?.Invoke();
            return b;
        }

        /// <summary>Tarjeta horizontal 16:9 (continuar viendo, episodios).</summary>
        public static Button Wide(string image, string title, string subtitle, double w, int percent, Action click, string placeholder = null)
        {
            double h = Math.Round(w * 9 / 16);
            var root = new StackPanel { Width = w };
            var frame = new Grid { Width = w, Height = h, Clip = Rounded(w, h, 12) };
            frame.Children.Add(Placeholder(placeholder ?? title, w, h));
            if (!string.IsNullOrEmpty(image)) frame.Children.Add(Picture(image, w, h, (int)(w * 1.4)));
            frame.Children.Add(new Border { Background = Gradient("#00000000", "#AA000000", 90), Height = h * 0.45, VerticalAlignment = VerticalAlignment.Bottom });
            var play = new Border
            {
                Width = 40, Height = 40, CornerRadius = new CornerRadius(20), Background = Hex("#B30B0812"),
                HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(10, 0, 0, 14),
                Child = Icon("", 15)
            };
            frame.Children.Add(play);
            if (percent > 0)
            {
                var bar = new Grid { Height = 4, VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(0, 0, 0, 0) };
                bar.Children.Add(new Border { Background = Hex("#55FFFFFF") });
                bar.Children.Add(new Border { Background = B("Accent"), HorizontalAlignment = HorizontalAlignment.Left, Width = Math.Max(4, w * percent / 100.0) });
                frame.Children.Add(bar);
            }
            root.Children.Add(frame);
            var t = T(title, 14, B("Text"), FontWeights.SemiBold);
            t.Margin = new Thickness(2, 8, 2, 0);
            root.Children.Add(t);
            if (!string.IsNullOrEmpty(subtitle))
            {
                var st = T(subtitle, 12.5, B("Text3"));
                st.Margin = new Thickness(2, 2, 2, 0);
                root.Children.Add(st);
            }
            var b = new Button { Style = S("CardBtn"), Content = root, Tag = h + 6, Margin = new Thickness(0, 0, 18, 0) };
            b.Click += (s, e) => click?.Invoke();
            return b;
        }

        /// <summary>Fila con título y tarjetas que se desplazan a lo ancho.</summary>
        public static StackPanel Row(string title, FrameworkElement[] cards, double edge)
        {
            var sp = new StackPanel { Margin = new Thickness(0, 6, 0, 18) };
            var t = T(title, 20, B("Text"), FontWeights.Bold);
            t.Margin = new Thickness(edge, 0, edge, 12);
            sp.Children.Add(t);
            var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(edge, 6, edge, 10) };
            foreach (var c in cards) panel.Children.Add(c);
            var sv = new ScrollViewer
            {
                HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden,
                VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Content = panel,
                Focusable = false,
                PanningMode = PanningMode.HorizontalOnly
            };
            // La rueda del ratón sobre una fila sigue bajando la página.
            sv.PreviewMouseWheel += (s, e) =>
            {
                if (Keyboard.Modifiers == ModifierKeys.Shift)
                {
                    sv.ScrollToHorizontalOffset(sv.HorizontalOffset - e.Delta);
                    e.Handled = true;
                    return;
                }
                e.Handled = true;
                var parent = FindParent<ScrollViewer>(sv);
                parent?.RaiseEvent(new MouseWheelEventArgs(e.MouseDevice, e.Timestamp, e.Delta) { RoutedEvent = UIElement.MouseWheelEvent });
            };
            sp.Children.Add(sv);
            return sp;
        }

        public static T FindParent<T>(DependencyObject d) where T : DependencyObject
        {
            var p = VisualTreeHelper.GetParent(d);
            while (p != null && !(p is T)) p = VisualTreeHelper.GetParent(p);
            return p as T;
        }

        public static T FindChild<T>(DependencyObject d) where T : DependencyObject
        {
            if (d == null) return null;
            int n = VisualTreeHelper.GetChildrenCount(d);
            for (int i = 0; i < n; i++)
            {
                var c = VisualTreeHelper.GetChild(d, i);
                if (c is T t) return t;
                var r = FindChild<T>(c);
                if (r != null) return r;
            }
            return null;
        }

        public static Effect Shadow(double blur = 24, double opacity = 0.5)
        {
            var e = new DropShadowEffect { BlurRadius = blur, ShadowDepth = 0, Opacity = opacity, Color = Colors.Black };
            e.Freeze();
            return e;
        }

        public static Border Badge(string text, Brush bg, Brush fg = null)
        {
            return new Border
            {
                Background = bg, CornerRadius = new CornerRadius(6), Padding = new Thickness(8, 3, 8, 3),
                Child = T(text, 11.5, fg ?? Brushes.White, FontWeights.Bold), HorizontalAlignment = HorizontalAlignment.Left
            };
        }

        /// <summary>Fondo desenfocado (luz ambiental) con la imagen.</summary>
        public static Image Ambient(string url)
        {
            var img = new Image { Stretch = Stretch.UniformToFill, Opacity = 0.35, IsHitTestVisible = false };
            img.Effect = new BlurEffect { Radius = 60, KernelType = KernelType.Gaussian, RenderingBias = RenderingBias.Performance };
            Images.Load(img, url, 400);
            return img;
        }
    }

    /// <summary>Íconos (Segoe MDL2 Assets, incluida en Windows 10 y 11).</summary>
    public static class G
    {
        public const string Back = "";
        public const string Search = "";
        public const string Settings = "";
        public const string Play = "";
        public const string Pause = "";
        public const string Volume = "";
        public const string Mute = "";
        public const string Full = "";
        public const string ExitFull = "";
        public const string Tv = "";
        public const string Movie = "";
        public const string Video = "";
        public const string Heart = "";
        public const string HeartFill = "";
        public const string Star = "";
        public const string StarFill = "";
        public const string User = "";
        public const string All = "";
        public const string Tiles = "";
        public const string Calendar = "";
        public const string Subs = "";
        public const string Audio = "";
        public const string List = "";
        public const string Refresh = "";
        public const string Add = "";
        public const string Edit = "";
        public const string Delete = "";
        public const string Lock = "";
        public const string Smile = "";
        public const string Info = "";
        public const string Close = "";
        public const string Check = "";
        public const string Next = "";
        public const string Prev = "";
        public const string Left = "";
        public const string Right = "";
    }
}
