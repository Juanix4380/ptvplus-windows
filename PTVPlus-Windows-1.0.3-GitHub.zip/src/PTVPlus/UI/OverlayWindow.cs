using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using PTVPlus.Core;

namespace PTVPlus.UI
{
    /// <summary>
    /// Capa transparente encima del video (controles, listas de canales, avisos y ventanas de
    /// diálogo). Va pegada a la ventana principal: no aparece en la barra de tareas ni se mueve sola.
    /// Donde no hay nada dibujado, los clics pasan a la ventana de abajo.
    /// </summary>
    public sealed class OverlayWindow : Window
    {
        private readonly Grid _root = new Grid();
        private readonly ContentControl _page = new ContentControl { Focusable = false };
        private readonly Grid _dialog = new Grid { Visibility = Visibility.Collapsed };
        private readonly StackPanel _toasts = new StackPanel
        {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 0, 60),
            IsHitTestVisible = false
        };
        private int _toastCount;
        public Action<KeyEventArgs> KeyHandler;
        public bool DialogOpen => _dialog.Visibility == Visibility.Visible;

        public OverlayWindow()
        {
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ShowInTaskbar = false;
            ShowActivated = false;
            ResizeMode = ResizeMode.NoResize;
            Topmost = false;
            Title = "PTV PLUS";
            FontFamily = Ui.Font;
            UseLayoutRounding = true;
            _root.Children.Add(_page);
            _root.Children.Add(_dialog);
            _root.Children.Add(_toasts);
            Content = _root;
            PreviewKeyDown += (s, e) => KeyHandler?.Invoke(e);
        }

        public bool HasPage => _page.Content != null;

        public void SetPage(UIElement content)
        {
            _page.Content = content;
            Refresh();
        }

        /// <summary>Se muestra solo si hay algo que ver (sin capa vacía encima del video).</summary>
        public void Refresh()
        {
            bool need = _page.Content != null || DialogOpen || _toastCount > 0;
            if (need && !IsVisible && Owner != null && Owner.WindowState != WindowState.Minimized) Show();
            else if (!need && IsVisible) Hide();
        }

        public void Sync(Rect screen)
        {
            if (Math.Abs(Left - screen.Left) > 0.5) Left = screen.Left;
            if (Math.Abs(Top - screen.Top) > 0.5) Top = screen.Top;
            if (Math.Abs(Width - screen.Width) > 0.5) Width = Math.Max(1, screen.Width);
            if (Math.Abs(Height - screen.Height) > 0.5) Height = Math.Max(1, screen.Height);
        }

        // --------------------------------------------------------------- diálogos

        public void OpenDialog(UIElement panel)
        {
            _dialog.Children.Clear();
            var dim = new Border { Background = new SolidColorBrush(Color.FromArgb(0xB8, 0x05, 0x03, 0x09)) };
            _dialog.Children.Add(dim);
            _dialog.Children.Add(panel);
            _dialog.Visibility = Visibility.Visible;
            Refresh();
            Activate();
            panel.Opacity = 0;
            panel.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(160)));
        }

        public void CloseDialog()
        {
            _dialog.Children.Clear();
            _dialog.Visibility = Visibility.Collapsed;
            Refresh();
            Owner?.Activate();
        }

        // ------------------------------------------------------------------ avisos

        public void Toast(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            var b = new Border
            {
                Background = new SolidColorBrush(Color.FromArgb(0xF0, 0x2A, 0x1E, 0x46)),
                BorderBrush = Ui.B("Accent"),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(22),
                Padding = new Thickness(22, 12, 22, 12),
                Margin = new Thickness(0, 6, 0, 0),
                Child = Ui.T(text, 15, Brushes.White, FontWeights.SemiBold),
                Effect = Ui.Shadow(20, 0.6)
            };
            _toasts.Children.Add(b);
            _toastCount++;
            Refresh();
            UiThread.After(3200, () =>
            {
                var fade = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(250));
                fade.Completed += (s, e) =>
                {
                    _toasts.Children.Remove(b);
                    _toastCount = Math.Max(0, _toastCount - 1);
                    Refresh();
                };
                b.BeginAnimation(OpacityProperty, fade);
            });
        }
    }
}
