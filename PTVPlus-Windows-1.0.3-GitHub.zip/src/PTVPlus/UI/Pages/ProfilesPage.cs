using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using PTVPlus.Core;

namespace PTVPlus.UI.Pages
{
    /// <summary>"¿Quién está viendo?": perfiles de la cuenta Cloud, PIN, infantil y administrar.</summary>
    public sealed class ProfilesPage : Page
    {
        private readonly WrapPanel _row = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Center };
        private readonly TextBlock _status = Ui.T("", 14.5, Ui.B("Text3"));
        private Button _manage;
        private bool _editing;
        private bool _busy;
        private List<Profile> _list = new List<Profile>();

        public ProfilesPage()
        {
            Background = Ui.Gradient("#FF1D1233", "#FF07050C", 80);
            RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            var top = new Grid { Margin = new Thickness(48, 28, 48, 0) };
            var brand = new StackPanel { Orientation = Orientation.Horizontal };
            brand.Children.Add(new Image { Source = Images.Asset("logo_mark.png"), Height = 44, Width = 44 });
            var name = Ui.T("PTV PLUS", 22, Ui.B("Text"), FontWeights.Bold);
            name.VerticalAlignment = VerticalAlignment.Center;
            name.Margin = new Thickness(12, 0, 0, 0);
            brand.Children.Add(name);
            top.Children.Add(brand);
            var right = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            right.Children.Add(Ui.Pill("Cerrar sesión", Logout, G.Close));
            top.Children.Add(right);
            Children.Add(top);

            var center = new StackPanel { VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center };
            var title = Ui.T("¿Quién está viendo?", 40, Ui.B("Text"), FontWeights.Bold);
            title.HorizontalAlignment = HorizontalAlignment.Center;
            center.Children.Add(title);
            _status.HorizontalAlignment = HorizontalAlignment.Center;
            _status.Margin = new Thickness(0, 8, 0, 30);
            center.Children.Add(_status);
            center.Children.Add(_row);
            _manage = Ui.Pill("Administrar perfiles", ToggleManage, G.Edit);
            _manage.HorizontalAlignment = HorizontalAlignment.Center;
            _manage.Margin = new Thickness(0, 34, 0, 0);
            center.Children.Add(_manage);
            Grid.SetRow(center, 1);
            Children.Add(center);
        }

        public override void OnShow()
        {
            _list = Profiles.List();
            Build();
            Load();
        }

        private async void Load()
        {
            if (_list.Count == 0) _status.Text = "Cargando perfiles…";
            try
            {
                _list = await Profiles.Refresh();
                _status.Text = _list.Count == 0 ? "Crea tu primer perfil" : "";
                Build();
                FocusFirst();
            }
            catch (Exception e)
            {
                Log.Error(e, "Perfiles");
                _status.Text = _list.Count == 0 ? "No se pudieron cargar los perfiles. Revisa tu internet." : "";
            }
        }

        public override void FocusFirst()
        {
            var b = _row.Children.OfType<Button>().FirstOrDefault();
            b?.Focus();
        }

        private void Build()
        {
            _row.Children.Clear();
            foreach (var p in _list) _row.Children.Add(Card(p));
            if (_list.Count < Profiles.Max) _row.Children.Add(AddCard());
            _manage.Content = Ui.IconText(_editing ? G.Check : G.Edit, _editing ? "Listo" : "Administrar perfiles");
        }

        private Button Card(Profile p)
        {
            var sp = new StackPanel { Width = 170 };
            var circle = new Grid { Width = 150, Height = 150 };
            circle.Children.Add(new Ellipse { Fill = Ui.Gradient("#FF3A2462", "#FF1A1030", 90) });
            var av = new Image { Source = Images.Avatar(p.Avatar), Stretch = Stretch.UniformToFill, Clip = new EllipseGeometry(new Point(75, 75), 75, 75) };
            RenderOptions.SetBitmapScalingMode(av, BitmapScalingMode.HighQuality);
            circle.Children.Add(av);
            if (p.HasPin)
            {
                var lk = new Border
                {
                    Width = 34, Height = 34, CornerRadius = new CornerRadius(17), Background = Ui.Hex("#E60B0812"),
                    HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Bottom,
                    Child = Ui.Icon(G.Lock, 14)
                };
                circle.Children.Add(lk);
            }
            if (_editing)
            {
                circle.Children.Add(new Ellipse { Fill = Ui.Hex("#99000000") });
                circle.Children.Add(Ui.Icon(G.Edit, 34));
            }
            sp.Children.Add(circle);
            var n = Ui.T(p.DisplayName, 18, Ui.B("Text"), FontWeights.SemiBold);
            n.HorizontalAlignment = HorizontalAlignment.Center;
            n.Margin = new Thickness(0, 14, 0, 0);
            sp.Children.Add(n);
            if (p.Kids)
            {
                var k = Ui.Badge("NIÑOS", Ui.B("AccentDark"));
                k.HorizontalAlignment = HorizontalAlignment.Center;
                k.Margin = new Thickness(0, 6, 0, 0);
                sp.Children.Add(k);
            }
            var b = new Button { Style = Ui.S("CardBtn"), Content = sp, Tag = 156.0, Margin = new Thickness(18) };
            b.Click += (s, e) => { if (_editing) Edit(p); else Select(p); };
            return b;
        }

        private Button AddCard()
        {
            var sp = new StackPanel { Width = 170 };
            var circle = new Grid { Width = 150, Height = 150 };
            circle.Children.Add(new Ellipse { Stroke = Ui.Hex("#66A782E8"), StrokeThickness = 2, StrokeDashArray = new DoubleCollection { 4, 3 }, Fill = Ui.Hex("#22A782E8") });
            circle.Children.Add(Ui.Icon(G.Add, 40, Ui.B("Accent")));
            sp.Children.Add(circle);
            var n = Ui.T("Agregar perfil", 17, Ui.B("Text2"), FontWeights.SemiBold);
            n.HorizontalAlignment = HorizontalAlignment.Center;
            n.Margin = new Thickness(0, 14, 0, 0);
            sp.Children.Add(n);
            var b = new Button { Style = Ui.S("CardBtn"), Content = sp, Tag = 156.0, Margin = new Thickness(18) };
            b.Click += (s, e) => Edit(null);
            return b;
        }

        private void ToggleManage()
        {
            _editing = !_editing;
            Build();
        }

        // ------------------------------------------------------------------ entrar

        private async void Select(Profile p)
        {
            if (_busy) return;
            _busy = true;
            _status.Text = "Entrando…";
            try
            {
                // El PIN se comprueba en Cloud en cada entrada.
                var fresh = await Profiles.RefreshPin(p);
                if (fresh.HasPin)
                {
                    _status.Text = "";
                    _busy = false;
                    Dialogs.Pin("PIN de " + fresh.DisplayName, "Escribe el PIN de 4 dígitos", pin =>
                    {
                        if (Profiles.PinMatches(fresh, pin)) Enter(fresh);
                        else Main.Toast("PIN incorrecto");
                    });
                    return;
                }
                Enter(fresh);
            }
            catch (Exception e)
            {
                Log.Error(e, "Perfil");
                _status.Text = "No se pudo verificar el perfil. Revisa tu internet.";
            }
            finally
            {
                _busy = false;
            }
        }

        private void Enter(Profile p)
        {
            Prefs.S.ProfileId = p.Id;
            Prefs.S.ProfileChosen = true;
            Prefs.Save();
            Library.Bind(Prefs.S.AccountId, p.Id);
            Catalog.Ensure();
            var t = HistorySync.PullAsync();
            Main.Reset(new HomePage());
        }

        private void Logout()
        {
            Dialogs.Confirm("Cerrar sesión", "Se cerrará la sesión en esta PC. Tu cuenta queda guardada para entrar con un clic.", "Cerrar sesión", () =>
            {
                Player.Playback.Stop();
                Prefs.Logout();
                Catalog.Clear();
                Main.Reset(new LoginPage());
            });
        }

        // ---------------------------------------------------------------- editar

        private void Edit(Profile existing)
        {
            var p = existing == null ? null : new Profile
            {
                Id = existing.Id, Name = existing.Name, Kids = existing.Kids, Pin = existing.Pin, Avatar = existing.Avatar, Uuid = existing.Uuid
            };
            if (p != null && p.HasPin)
            {
                Dialogs.Pin("PIN de " + p.DisplayName, "Para editar este perfil escribe su PIN", pin =>
                {
                    if (Profiles.PinMatches(p, pin)) ShowEditor(p);
                    else Main.Toast("PIN incorrecto");
                });
                return;
            }
            ShowEditor(p);
        }

        private void ShowEditor(Profile p)
        {
            bool isNew = p == null;
            string name = p?.Name ?? "";
            bool kids = p?.Kids ?? false;
            int avatar = p?.Avatar ?? 0;
            string newPin = null; // null = sin cambio, "" = quitar
            var card = new Border
            {
                Width = 720, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center,
                CornerRadius = new CornerRadius(24), BorderBrush = Ui.Hex("#55A782E8"), BorderThickness = new Thickness(1.2),
                Background = Ui.Gradient("#FF221838", "#FF120D1C", 90), Padding = new Thickness(30, 26, 30, 24), Effect = Ui.Shadow(40, 0.7)
            };
            var sp = new StackPanel();
            sp.Children.Add(Ui.T(isNew ? "Nuevo perfil" : "Editar perfil", 24, Ui.B("Text"), FontWeights.Bold));
            var field = new TextBox { Style = Ui.S("Field"), Text = name, Margin = new Thickness(0, 16, 0, 14), MaxLength = 20 };
            sp.Children.Add(field);
            sp.Children.Add(Ui.T("Avatar", 14, Ui.B("Text2"), FontWeights.SemiBold));
            var avatars = new UniformGrid { Columns = 7, Margin = new Thickness(0, 8, 0, 10) };
            var avButtons = new List<Button>();
            Action paintAv = () =>
            {
                for (int i = 0; i < avButtons.Count; i++)
                {
                    var bd = (Grid)avButtons[i].Content;
                    ((Ellipse)bd.Children[1]).Stroke = i == avatar ? Ui.B("Accent") : Brushes.Transparent;
                }
            };
            for (int i = 0; i < Profiles.AvatarNames.Length; i++)
            {
                int index = i;
                var g = new Grid { Width = 74, Height = 74 };
                g.Children.Add(new Image { Source = Images.Avatar(i), Stretch = Stretch.UniformToFill, Clip = new EllipseGeometry(new Point(37, 37), 37, 37) });
                g.Children.Add(new Ellipse { StrokeThickness = 4, Stroke = Brushes.Transparent });
                var ab = new Button { Style = Ui.S("CardBtn"), Content = g, Tag = 74.0, Margin = new Thickness(6) };
                ab.Click += (s, e) => { avatar = index; paintAv(); };
                avButtons.Add(ab);
                avatars.Children.Add(ab);
            }
            paintAv();
            sp.Children.Add(avatars);
            var kidsBtn = Ui.Pill("", null);
            Action paintKids = () => kidsBtn.Content = Ui.IconText(kids ? G.Check : G.Smile, kids ? "Perfil infantil: Sí" : "Perfil infantil: No");
            kidsBtn.Click += (s, e) => { kids = !kids; paintKids(); };
            paintKids();
            var pinBtn = Ui.Pill("", null);
            Action paintPin = () =>
            {
                bool has = newPin != null ? newPin.Length > 0 : (p != null && p.HasPin);
                pinBtn.Content = Ui.IconText(G.Lock, has ? "PIN: activado (cambiar o quitar)" : "PIN: sin PIN (poner)");
            };
            pinBtn.Click += (s, e) =>
            {
                bool has = newPin != null ? newPin.Length > 0 : (p != null && p.HasPin);
                if (has)
                {
                    Dialogs.Choice("PIN del perfil", new[] { "Cambiar PIN", "Quitar PIN" }, 0, i =>
                    {
                        if (i == 1) { newPin = ""; Reopen(); }
                        else AskPin(v => { newPin = v; Reopen(); });
                    });
                }
                else AskPin(v => { newPin = v; Reopen(); });
            };
            paintPin();
            var opts = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 6, 0, 0) };
            kidsBtn.Margin = new Thickness(0, 0, 12, 0);
            opts.Children.Add(kidsBtn);
            opts.Children.Add(pinBtn);
            sp.Children.Add(opts);
            var err = Ui.T("", 14, Ui.Hex("#FFFF8A8A"));
            err.Margin = new Thickness(0, 12, 0, 0);
            sp.Children.Add(err);
            var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 18, 0, 0) };
            if (!isNew)
            {
                var del = Ui.Pill("Eliminar", () => Dialogs.Confirm("Eliminar perfil", "Se borrará " + p.DisplayName + " y lo que vio en todos los equipos.", "Eliminar", async () =>
                {
                    try { _list = await Profiles.Delete(p); Build(); Main.Toast("Perfil eliminado"); }
                    catch (Exception ex) { Dialogs.Message("No se pudo eliminar", ex.Message); }
                }), G.Delete);
                del.Margin = new Thickness(0, 0, 12, 0);
                row.Children.Add(del);
            }
            var cancel = Ui.Pill("Cancelar", Dialogs.Close);
            cancel.Margin = new Thickness(0, 0, 12, 0);
            row.Children.Add(cancel);
            Button save = null;
            save = Ui.Primary("Guardar", async () =>
            {
                string nm = field.Text.Trim();
                if (nm.Length == 0) { err.Text = "Escribe el nombre del perfil"; return; }
                save.IsEnabled = false;
                try
                {
                    Profile target;
                    bool pinChanged = newPin != null;
                    if (isNew)
                    {
                        target = Profiles.NewProfile(nm, avatar, newPin ?? "", kids);
                        pinChanged = !string.IsNullOrEmpty(newPin);
                    }
                    else
                    {
                        target = p;
                        target.Name = nm;
                        target.Kids = kids;
                        target.Avatar = avatar;
                        if (newPin != null) target.Pin = newPin.Length == 0 ? "" : Profiles.HashPin(newPin, target.Index);
                    }
                    _list = await Profiles.Save(target, pinChanged);
                    Dialogs.Close();
                    Build();
                    Main.Toast(isNew ? "Perfil creado" : "Perfil guardado");
                }
                catch (Exception ex)
                {
                    err.Text = ex.Message;
                    save.IsEnabled = true;
                }
            });
            row.Children.Add(save);
            sp.Children.Add(row);
            card.Child = sp;
            Main.Overlay.OpenDialog(card);
            field.Focus();

            void Reopen()
            {
                // Volver a la edición tras el PIN, sin perder lo escrito.
                Main.Overlay.OpenDialog(card);
                paintPin();
            }
        }

        private void AskPin(Action<string> done)
        {
            Dialogs.Pin("Nuevo PIN", "Escribe 4 dígitos", first =>
            {
                Dialogs.Pin("Confirma el PIN", "Escríbelo otra vez", second =>
                {
                    if (first == second) done(first);
                    else Main.Toast("Los PIN no coinciden");
                });
            });
        }
    }
}
