using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>Ficha de película o serie: fondo grande, sinopsis, continuar, Mi lista, temporadas y episodios.</summary>
    public sealed class DetailPage : Page
    {
        private const double Edge = 64;
        private readonly Item _item;
        private readonly Image _backdrop = new Image { Stretch = Stretch.UniformToFill, HorizontalAlignment = HorizontalAlignment.Right };
        private readonly StackPanel _body = new StackPanel { Margin = new Thickness(0, 40, 0, 50) };
        private readonly TextBlock _kicker = Ui.T("", 14, Ui.B("Accent"), FontWeights.Bold);
        private readonly TextBlock _title = Ui.T("", 44, Ui.B("Text"), FontWeights.Bold);
        private readonly TextBlock _meta = Ui.T("", 16, Ui.B("Text2"));
        private readonly TextBlock _plot = Ui.T("", 17, Ui.B("Text2"));
        private readonly TextBlock _credits = Ui.T("", 14, Ui.B("Text3"));
        private readonly StackPanel _buttons = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(Edge, 26, Edge, 0) };
        private readonly TextBlock _progress = Ui.T("", 13.5, Ui.B("Text3"));
        private readonly StackPanel _seasons = new StackPanel { Orientation = Orientation.Horizontal };
        private readonly StackPanel _episodesHost = new StackPanel();
        private readonly StackPanel _similarHost = new StackPanel();
        private Button _play;
        private Button _fav;
        private SeriesInfo _series;
        private VodInfo _vod;
        private int _season = -1;

        public DetailPage(Item item)
        {
            _item = item;
            Background = Ui.B("Bg");
            // Fondo grande a la derecha que se desvanece hacia los textos.
            var bdHost = new Grid { IsHitTestVisible = false };
            _backdrop.OpacityMask = new LinearGradientBrush(
                new GradientStopCollection { new GradientStop(Colors.Transparent, 0), new GradientStop(Color.FromArgb(0xCC, 0, 0, 0), 0.35), new GradientStop(Colors.Black, 0.6) },
                new Point(0, 0.5), new Point(1, 0.5));
            bdHost.Children.Add(_backdrop);
            bdHost.Children.Add(new Border { Background = Ui.Gradient("#000B0812", "#FF0B0812", 90), VerticalAlignment = VerticalAlignment.Bottom, Height = 380 });
            Children.Add(bdHost);

            var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Focusable = false, PanningMode = PanningMode.VerticalOnly };
            var back = Ui.Round(G.Back, () => Main.Back(), "Atrás");
            back.HorizontalAlignment = HorizontalAlignment.Left;
            back.Margin = new Thickness(Edge - 8, 0, 0, 30);
            _body.Children.Add(back);
            _kicker.Margin = new Thickness(Edge, 0, Edge, 0);
            _body.Children.Add(_kicker);
            _title.Margin = new Thickness(Edge, 8, Edge, 0);
            _title.TextWrapping = TextWrapping.Wrap;
            _title.MaxWidth = 900;
            _title.HorizontalAlignment = HorizontalAlignment.Left;
            _title.MaxHeight = 120;
            _body.Children.Add(_title);
            _meta.Margin = new Thickness(Edge, 12, Edge, 0);
            _body.Children.Add(_meta);
            _plot.Margin = new Thickness(Edge, 18, Edge, 0);
            _plot.TextWrapping = TextWrapping.Wrap;
            _plot.MaxWidth = 820;
            _plot.MaxHeight = 140;
            _plot.HorizontalAlignment = HorizontalAlignment.Left;
            _body.Children.Add(_plot);
            _credits.Margin = new Thickness(Edge, 12, Edge, 0);
            _credits.TextWrapping = TextWrapping.Wrap;
            _credits.MaxWidth = 820;
            _credits.HorizontalAlignment = HorizontalAlignment.Left;
            _body.Children.Add(_credits);
            _body.Children.Add(_buttons);
            _progress.Margin = new Thickness(Edge + 4, 10, Edge, 0);
            _body.Children.Add(_progress);
            var seasonsScroll = new ScrollViewer { HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden, VerticalScrollBarVisibility = ScrollBarVisibility.Disabled, Content = _seasons, Focusable = false, Margin = new Thickness(Edge, 34, Edge, 0) };
            _body.Children.Add(seasonsScroll);
            _body.Children.Add(_episodesHost);
            _body.Children.Add(_similarHost);
            scroll.Content = _body;
            Children.Add(scroll);
            SizeChanged += (s, e) => _backdrop.Width = Math.Max(400, ActualWidth * 0.72);
            Fill();
        }

        public override void OnShow()
        {
            Library.Changed += Paint;
            Paint();
        }

        public override void OnHide() => Library.Changed -= Paint;

        public override void FocusFirst() => _play?.Focus();

        private void Fill()
        {
            var it = _item;
            var s = Catalog.Snap;
            string cat = s?.CategoryOf(it.Kind, it.CatId)?.Name ?? "";
            _kicker.Text = (it.Kind == Kind.Movie ? "PELÍCULA" : "SERIE") + (cat.Length > 0 ? " · " + cat.ToUpperInvariant() : "");
            _title.Text = it.Title;
            Images.Load(_backdrop, !string.IsNullOrEmpty(it.Backdrop) ? it.Backdrop : it.Icon, 1280);
            MetaLine();
            _play = Ui.Primary("Ver ahora", Play, G.Play);
            _play.Height = 54;
            _play.MinWidth = 190;
            _play.FontSize = 17;
            _play.Margin = new Thickness(0, 0, 14, 0);
            _buttons.Children.Add(_play);
            if (it.Kind == Kind.Movie)
            {
                var restart = Ui.Pill("Desde el inicio", () => Play(true), G.Refresh);
                restart.Height = 54;
                restart.Margin = new Thickness(0, 0, 14, 0);
                restart.Name = "restart";
                _buttons.Children.Add(restart);
            }
            _fav = Ui.Pill("Mi lista", ToggleFav, G.Heart);
            _fav.Height = 54;
            _buttons.Children.Add(_fav);
            Similar();
            Load();
        }

        private void MetaLine()
        {
            var it = _item;
            var parts = new List<string>();
            if (it.YearOrName.Length > 0) parts.Add(it.YearOrName);
            if (it.Rating > 0) parts.Add(it.RatingText);
            if (_vod != null)
            {
                if (_vod.DurationSecs > 0) parts.Add(TextUtil.Minutes(_vod.DurationSecs / 60));
                else if (_vod.Duration.Length > 0) parts.Add(_vod.Duration);
                if (_vod.Genre.Length > 0) parts.Add(_vod.Genre);
            }
            if (_series != null)
            {
                parts.Add(_series.Seasons.Count == 1 ? "1 temporada" : _series.Seasons.Count + " temporadas");
                if (_series.Genre.Length > 0) parts.Add(_series.Genre);
            }
            _meta.Text = string.Join("   ·   ", parts);
        }

        private async void Load()
        {
            try
            {
                if (_item.Kind == Kind.Movie)
                {
                    _vod = await Xtream.GetVodInfo(Prefs.Account(), _item.Id);
                    _plot.Text = _vod.Plot;
                    Credits(_vod.Director, _vod.Cast);
                    if (string.IsNullOrEmpty(_item.Backdrop) && _vod.Backdrops.Count > 0) Images.Load(_backdrop, _vod.Backdrops[0], 1280);
                }
                else
                {
                    _series = await SeriesCache.Get(_item.Id);
                    _plot.Text = _series.Plot;
                    Credits(_series.Director, _series.Cast);
                    if (string.IsNullOrEmpty(_item.Backdrop) && _series.Backdrops.Count > 0) Images.Load(_backdrop, _series.Backdrops[0], 1280);
                    BuildSeasons();
                }
                MetaLine();
                Paint();
            }
            catch (Exception e)
            {
                Log.Error(e, "Ficha");
                if (_plot.Text.Length == 0) _plot.Text = "No se pudo cargar la información. Puedes intentar verla de todos modos.";
            }
        }

        private void Credits(string director, string cast)
        {
            var parts = new List<string>();
            if (!string.IsNullOrWhiteSpace(director)) parts.Add("Dirección: " + director.Trim());
            if (!string.IsNullOrWhiteSpace(cast)) parts.Add("Reparto: " + cast.Trim());
            _credits.Text = string.Join("\n", parts);
        }

        /// <summary>Botón Ver/Continuar, avance y Mi lista según lo que se haya visto.</summary>
        private void Paint()
        {
            bool fav = Library.IsFav(_item.Kind, _item.Id);
            _fav.Content = Ui.IconText(fav ? G.HeartFill : G.Heart, fav ? "En Mi lista" : "Mi lista");
            if (_item.Kind == Kind.Movie)
            {
                var h = Library.Of("m:" + _item.Id);
                bool resume = h != null && h.Dur > 0 && h.Pos > 30_000 && h.Pos < h.Dur - 60_000;
                _play.Content = Ui.IconText(G.Play, resume ? "Continuar" : "Ver ahora");
                _progress.Text = resume ? "Quedan " + Math.Max(1, (h.Dur - h.Pos) / 60000) + " min" : "";
                var restart = _buttons.Children.OfType<Button>().FirstOrDefault(b => b.Name == "restart");
                if (restart != null) restart.Visibility = resume ? Visibility.Visible : Visibility.Collapsed;
            }
            else
            {
                var h = Library.Of("s:" + _item.Id);
                if (h != null && h.Kind == Kind.Episode)
                {
                    string se = (h.Season > 0 ? "T" + h.Season + " · " : "") + "E" + h.Episode;
                    _play.Content = Ui.IconText(G.Play, "Continuar " + se);
                    _progress.Text = h.Subtitle;
                }
                else
                {
                    _play.Content = Ui.IconText(G.Play, "Ver T1 · E1");
                    _progress.Text = "";
                }
                if (_season >= 0) BuildEpisodes(_season);
            }
        }

        private void ToggleFav()
        {
            bool on = Library.ToggleFav(_item);
            Main.Toast(on ? "Agregada a Mi lista" : "Quitada de Mi lista");
        }

        // --------------------------------------------------------------- ver

        private void Play() => Play(false);

        private void Play(bool fromStart)
        {
            if (_item.Kind == Kind.Movie)
            {
                var m = Media.ForMovie(_item);
                if (_vod != null && _vod.Ext.Length > 0 && string.IsNullOrEmpty(_item.Ext))
                {
                    m.Url = Xtream.MovieUrl(Prefs.Account(), _item.Id, _vod.Ext);
                    m.Ext = _vod.Ext;
                }
                Main.Go(new PlayerPage(m, fromStart ? 0 : Playback.StartFor(m)));
                return;
            }
            if (_series == null) { Main.Toast("Cargando episodios…"); return; }
            var all = _series.Ordered();
            if (all.Count == 0) { Main.Toast("Esta serie no tiene episodios"); return; }
            var h = Library.Of("s:" + _item.Id);
            int i = 0;
            if (h != null)
            {
                i = Math.Max(0, all.FindIndex(e => e.Id == h.Id));
                var p = Library.EpisodeProgress(h.Id);
                if (p != null && p[1] > 0 && p[0] >= p[1] - 60_000 && i + 1 < all.Count) i++;
            }
            PlayEpisode(all, i);
        }

        private void PlayEpisode(List<Episode> all, int i)
        {
            var queue = all.Select(e => Media.ForEpisode(_item, e, _item.Title, _series.Cover)).ToList();
            Main.Go(new PlayerPage(queue[i], Playback.StartFor(queue[i]), queue, i));
        }

        // -------------------------------------------------------- temporadas

        private void BuildSeasons()
        {
            _seasons.Children.Clear();
            if (_series == null || _series.Seasons.Count == 0) return;
            var h = Library.Of("s:" + _item.Id);
            int start = h != null && h.Season > 0 && _series.Episodes.ContainsKey(h.Season) ? h.Season : _series.Seasons[0].Number;
            foreach (var se in _series.Seasons)
            {
                var season = se;
                var b = Ui.Pill(se.Name + "  (" + se.EpisodeCount + ")", () => BuildEpisodes(season.Number));
                b.Margin = new Thickness(0, 0, 10, 0);
                b.Tag = se.Number;
                _seasons.Children.Add(b);
            }
            BuildEpisodes(start);
        }

        private void BuildEpisodes(int number)
        {
            _season = number;
            foreach (var b in _seasons.Children.OfType<Button>())
            {
                bool on = b.Tag is int n && n == number;
                b.BorderBrush = on ? Ui.B("Accent") : Ui.Hex("#FF3A2D58");
                b.Background = on ? Ui.Hex("#FF34275A") : Ui.Hex("#FF231A38");
            }
            _episodesHost.Children.Clear();
            List<Episode> eps;
            if (_series == null || !_series.Episodes.TryGetValue(number, out eps)) return;
            var all = _series.Ordered();
            double w = Math.Max(260, Math.Min(340, ActualWidth / 5.2));
            var cards = new List<FrameworkElement>();
            foreach (var e in eps)
            {
                var ep = e;
                var p = Library.EpisodeProgress(ep.Id);
                int pct = p != null && p[1] > 0 ? (int)(p[0] * 100 / p[1]) : 0;
                string sub = ep.DurationSecs > 0 ? TextUtil.Minutes(ep.DurationSecs / 60) : ep.Duration;
                string title = "E" + ep.Num + (string.IsNullOrWhiteSpace(ep.Title) ? "" : " · " + ep.Title);
                cards.Add(Ui.Wide(string.IsNullOrEmpty(ep.Image) ? _series.Cover : ep.Image, title, sub, w, pct,
                    () => PlayEpisode(all, Math.Max(0, all.FindIndex(x => x.Id == ep.Id))), title));
            }
            _episodesHost.Children.Add(Ui.Row("Episodios", cards.ToArray(), Edge));
        }

        private void Similar()
        {
            var s = Catalog.Snap;
            if (s == null) return;
            var list = s.ItemsOf(_item.Kind, _item.CatId).Where(i => i.Id != _item.Id).OrderByDescending(i => i.Added).Take(24).ToList();
            if (list.Count == 0) return;
            double pw = 160;
            var cards = list.Select(i => (FrameworkElement)Ui.Poster(i, pw, () => Main.Go(new DetailPage(i)))).ToArray();
            _similarHost.Children.Add(Ui.Row("También te puede gustar", cards, Edge));
        }
    }
}
