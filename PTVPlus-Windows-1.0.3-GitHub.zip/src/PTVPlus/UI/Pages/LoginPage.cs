using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using PTVPlus.Core;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// Inicio de sesión: cuenta y contraseña propias de cada usuario (validadas en Cloud). El
    /// servidor nunca se escribe ni se muestra: lo entrega Cloud. Soporte con QR y WhatsApp.
    /// </summary>
    public sealed class LoginPage : Page
    {
        public const string WhatsApp = "15593834323";

        private readonly TextBox _user = new TextBox { Style = Ui.S("Field") };
        private readonly PasswordBox _pass = new PasswordBox { Style = Ui.S("PassField") };
        private readonly TextBox _passShown = new TextBox { Style = Ui.S("Field"), Visibility = Visibility.Collapsed };
        private readonly TextBlock _error = Ui.T("", 14.5, Ui.Hex("#FFFF8A8A"));
        private Button _enter;
        private readonly StackPanel _saved = new StackPanel();
        private bool _busy;

        public LoginPage()
        {
            Background = Ui.Gradient("#FF1A1030", "#FF07050C", 60);
            ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(560) });

            // Izquierda: logo, frase y soporte
            var left = new StackPanel { VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(40) };
            var logo = new Image { Source = Images.Asset("logo_full.png"), Height = 230, Stretch = Stretch.Uniform };
            RenderOptions.SetBitmapScalingMode(logo, BitmapScalingMode.HighQuality);
            left.Children.Add(logo);
            var tag = Ui.T("Tu TV, películas y series en un solo lugar", 19, Ui.B("Text2"));
            tag.HorizontalAlignment = HorizontalAlignment.Center;
            tag.Margin = new Thickness(0, 18, 0, 26);
            left.Children.Add(tag);
            left.Children.Add(SupportBox());
            Children.Add(left);

            // Derecha: tarjeta de inicio de sesión
            var card = new Border
            {
                Margin = new Thickness(0, 40, 56, 40),
                VerticalAlignment = VerticalAlignment.Center,
                CornerRadius = new CornerRadius(26),
                Background = Ui.Gradient("#F2181226", "#F20E0A16", 90),
                BorderBrush = Ui.Hex("#40A782E8"),
                BorderThickness = new Thickness(1.2),
                Padding = new Thickness(38, 34, 38, 34),
                Effect = Ui.Shadow(50, 0.6)
            };
            Grid.SetColumn(card, 1);
            var form = new StackPanel();
            form.Children.Add(Ui.T("Iniciar sesión", 30, Ui.B("Text"), FontWeights.Bold));
            var sub = Ui.T("Entra con la cuenta y contraseña de tu servicio", 15, Ui.B("Text2"));
            sub.Margin = new Thickness(0, 6, 0, 22);
            form.Children.Add(sub);
            form.Children.Add(_saved);
            form.Children.Add(Label("Cuenta"));
            form.Children.Add(_user);
            form.Children.Add(Label("Contraseña"));
            var passGrid = new Grid();
            passGrid.Children.Add(_pass);
            passGrid.Children.Add(_passShown);
            var eye = new Button { Style = Ui.S("Ghost"), Content = Ui.Icon("", 16, Ui.B("Text2")), HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 0, 6, 0), Focusable = false };
            eye.Click += (s, e) => TogglePass();
            passGrid.Children.Add(eye);
            form.Children.Add(passGrid);
            _error.Margin = new Thickness(2, 12, 0, 0);
            _error.TextWrapping = TextWrapping.Wrap;
            form.Children.Add(_error);
            _enter = Ui.Primary("Entrar", DoLogin);
            _enter.Height = 54;
            _enter.FontSize = 17;
            _enter.Margin = new Thickness(0, 18, 0, 0);
            form.Children.Add(_enter);
            card.Child = form;
            Children.Add(card);

            _user.KeyDown += (s, e) => { if (e.Key == Key.Enter) { e.Handled = true; _pass.Focus(); } };
            _pass.KeyDown += (s, e) => { if (e.Key == Key.Enter) { e.Handled = true; DoLogin(); } };
            _passShown.KeyDown += (s, e) => { if (e.Key == Key.Enter) { e.Handled = true; DoLogin(); } };
            BuildSaved();
        }

        private static TextBlock Label(string t)
        {
            var l = Ui.T(t, 14, Ui.B("Text2"), FontWeights.SemiBold);
            l.Margin = new Thickness(4, 14, 0, 8);
            return l;
        }

        private UIElement SupportBox()
        {
            var box = new Border
            {
                CornerRadius = new CornerRadius(20),
                Background = Ui.Hex("#B3161124"),
                BorderBrush = Ui.Hex("#33A782E8"),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(18),
                HorizontalAlignment = HorizontalAlignment.Center
            };
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            var qr = new Border { CornerRadius = new CornerRadius(12), Background = Brushes.White, Padding = new Thickness(6), Width = 116, Height = 116 };
            qr.Child = new Image { Source = Images.Asset("support_qr.png"), Stretch = Stretch.Uniform };
            row.Children.Add(qr);
            var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(18, 0, 0, 0), MaxWidth = 260 };
            text.Children.Add(Ui.T("¿Necesitas ayuda?", 18, Ui.B("Text"), FontWeights.Bold));
            var d = Ui.T("Escanea el código con tu teléfono para escribir a Soporte por WhatsApp.", 14, Ui.B("Text2"));
            d.TextWrapping = TextWrapping.Wrap;
            d.Margin = new Thickness(0, 4, 0, 10);
            text.Children.Add(d);
            var wa = Ui.Pill("WhatsApp de Soporte", OpenWhatsApp, "");
            wa.HorizontalAlignment = HorizontalAlignment.Left;
            text.Children.Add(wa);
            row.Children.Add(text);
            box.Child = row;
            return box;
        }

        public static void OpenWhatsApp()
        {
            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://wa.me/" + WhatsApp) { UseShellExecute = true });
            }
            catch (Exception e) { Log.Error(e, "WhatsApp"); }
        }

        private void TogglePass()
        {
            if (_pass.Visibility == Visibility.Visible)
            {
                _passShown.Text = _pass.Password;
                _pass.Visibility = Visibility.Collapsed;
                _passShown.Visibility = Visibility.Visible;
            }
            else
            {
                _pass.Password = _passShown.Text;
                _passShown.Visibility = Visibility.Collapsed;
                _pass.Visibility = Visibility.Visible;
            }
        }

        private string Password => _pass.Visibility == Visibility.Visible ? _pass.Password : _passShown.Text;

        /// <summary>Cuentas guardadas: entrar con un clic.</summary>
        private void BuildSaved()
        {
            _saved.Children.Clear();
            var list = SavedAccounts.List();
            if (list.Count == 0) return;
            var t = Ui.T("Cuentas guardadas", 14, Ui.B("Text2"), FontWeights.SemiBold);
            t.Margin = new Thickness(4, 0, 0, 8);
            _saved.Children.Add(t);
            foreach (var a in list.Take(4))
            {
                var acc = a;
                var g = new Grid();
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                var circle = new Border
                {
                    Width = 40, Height = 40, CornerRadius = new CornerRadius(20), Background = Ui.Gradient("#FFA782E8", "#FF6B48B8", 45),
                    Child = Ui.T(TextUtil.Initials(acc.User), 15, Brushes.White, FontWeights.Bold)
                };
                ((TextBlock)circle.Child).HorizontalAlignment = HorizontalAlignment.Center;
                ((TextBlock)circle.Child).VerticalAlignment = VerticalAlignment.Center;
                g.Children.Add(circle);
                var info = new StackPanel { Margin = new Thickness(14, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
                info.Children.Add(Ui.T(acc.User, 16, Ui.B("Text"), FontWeights.SemiBold));
                info.Children.Add(Ui.T(acc.ExpDate > 0 ? "Vence: " + TextUtil.ExpText(acc.ExpDate) : "Toca para entrar", 12.5, Ui.B("Text3")));
                Grid.SetColumn(info, 1);
                g.Children.Add(info);
                var arrow = Ui.Icon(G.Right, 14, Ui.B("Text2"));
                Grid.SetColumn(arrow, 2);
                g.Children.Add(arrow);
                var b = Ui.Btn("RowBtn", g, () => Login(acc.User, Secret.Unprotect(acc.PassEnc)));
                b.Margin = new Thickness(0, 0, 0, 8);
                b.Padding = new Thickness(14, 10, 14, 10);
                b.MouseRightButtonUp += (s, e) =>
                    Dialogs.Confirm("Quitar cuenta", "¿Quitar " + acc.User + " de las cuentas guardadas?", "Quitar", () => { SavedAccounts.Remove(acc.User); BuildSaved(); });
                _saved.Children.Add(b);
            }
            var other = Ui.T("O escribe otra cuenta", 13.5, Ui.B("Text3"));
            other.Margin = new Thickness(4, 6, 0, 0);
            _saved.Children.Add(other);
        }

        public override void FocusFirst()
        {
            var first = _saved.Children.OfType<Button>().FirstOrDefault();
            if (first != null) first.Focus();
            else _user.Focus();
        }

        private void DoLogin()
        {
            if (_busy) return;
            string u = _user.Text.Trim(), p = Password.Trim();
            if (u.Length == 0) { _error.Text = "Escribe tu cuenta"; _user.Focus(); return; }
            if (p.Length == 0) { _error.Text = "Escribe tu contraseña"; _pass.Focus(); return; }
            Login(u, p);
        }

        private async void Login(string u, string p)
        {
            if (_busy || string.IsNullOrEmpty(u) || string.IsNullOrEmpty(p)) return;
            _busy = true;
            _error.Text = "";
            _enter.Content = "Entrando…";
            _enter.IsEnabled = false;
            try
            {
                var panel = await Cloud.Login(u, p);
                string server = Xtream.NormalizeServer(panel.Server);
                var info = await Xtream.Login(new Account(server, panel.Username, p));
                bool changed = Prefs.S.Server != server || Prefs.S.User != panel.Username;
                Prefs.S.Server = server;
                Prefs.S.User = panel.Username;
                Prefs.Pass = p;
                Prefs.Token = panel.Token;
                Prefs.S.AccountId = panel.AccountId;
                Prefs.S.ProfileId = "0";
                Prefs.S.ProfileChosen = false;
                Prefs.S.Status = info.Status;
                Prefs.S.ExpDate = info.ExpDate;
                Prefs.S.MaxConnections = info.MaxConnections;
                Prefs.S.Logged = true;
                Prefs.SaveNow();
                SavedAccounts.Save(panel.Username, p, info.ExpDate);
                if (changed) Catalog.Clear();
                Catalog.Ensure();
                Main.Reset(new ProfilesPage());
            }
            catch (Exception e)
            {
                Log.Error(e, "Login");
                _error.Text = Friendly(e);
            }
            finally
            {
                _busy = false;
                _enter.Content = "Entrar";
                _enter.IsEnabled = true;
            }
        }

        private static string Friendly(Exception e)
        {
            string m = (e.Message ?? "").Trim();
            if (e is TaskCanceledException || e is OperationCanceledException) return "El servicio tardó en responder. Revisa tu internet e intenta otra vez.";
            if (e is System.Net.Http.HttpRequestException)
            {
                string why = (e.InnerException?.Message ?? m).Trim();
                return "Sin conexión con el servicio. Revisa tu internet e intenta otra vez." + (why.Length > 0 ? "\n(" + why + ")" : "");
            }
            if (m.StartsWith("HTTP ")) return "Tu servicio no respondió (" + m + "). Intenta de nuevo en un momento.";
            return m.Length > 0 ? m : "No se pudo iniciar sesión (" + e.GetType().Name + ")";
        }
    }
}
