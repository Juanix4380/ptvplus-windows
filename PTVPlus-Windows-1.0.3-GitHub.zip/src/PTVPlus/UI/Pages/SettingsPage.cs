using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>Configuración: cuenta, reproducción, pantalla, catálogo y soporte (en una columna centrada).</summary>
    public sealed class SettingsPage : Page
    {
        private readonly StackPanel _list = new StackPanel { MaxWidth = 860, Margin = new Thickness(40, 10, 40, 60) };
        private Button _first;

        public SettingsPage()
        {
            Background = Ui.B("Bg");
            var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Focusable = false };
            var col = new StackPanel();
            var top = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(40, 26, 40, 10), MaxWidth = 860 };
            top.Children.Add(Ui.Round(G.Back, () => Main.Back(), "Atrás"));
            var t = Ui.T("Configuración", 30, Ui.B("Text"), FontWeights.Bold);
            t.VerticalAlignment = VerticalAlignment.Center;
            t.Margin = new Thickness(16, 0, 0, 0);
            top.Children.Add(t);
            col.Children.Add(top);
            col.Children.Add(_list);
            scroll.Content = col;
            Children.Add(scroll);
        }

        public override void OnShow() => Build();

        public override void FocusFirst() => _first?.Focus();

        private void Section(string title)
        {
            var t = Ui.T(title.ToUpperInvariant(), 13, Ui.B("Accent"), FontWeights.Bold);
            t.Margin = new Thickness(6, 26, 0, 10);
            _list.Children.Add(t);
        }

        private Button Row(string title, string value, string glyph, Action click, string sub = null)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var ic = Ui.Icon(glyph, 18, Ui.B("Accent"));
            ic.HorizontalAlignment = HorizontalAlignment.Left;
            g.Children.Add(ic);
            var texts = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            texts.Children.Add(Ui.T(title, 16, Ui.B("Text"), FontWeights.SemiBold));
            if (!string.IsNullOrEmpty(sub))
            {
                var st = Ui.T(sub, 13, Ui.B("Text3"));
                st.TextWrapping = TextWrapping.Wrap;
                st.Margin = new Thickness(0, 3, 0, 0);
                texts.Children.Add(st);
            }
            Grid.SetColumn(texts, 1);
            g.Children.Add(texts);
            var v = Ui.T(value ?? "", 15, Ui.B("Text2"));
            v.VerticalAlignment = VerticalAlignment.Center;
            v.Margin = new Thickness(16, 0, 0, 0);
            Grid.SetColumn(v, 2);
            g.Children.Add(v);
            var b = Ui.Btn("RowBtn", g, click);
            b.Margin = new Thickness(0, 0, 0, 8);
            _list.Children.Add(b);
            if (_first == null) _first = b;
            return b;
        }

        private void Choose(string title, string[] options, int selected, Action<int> pick)
        {
            Dialogs.Choice(title, options, selected, i =>
            {
                pick(i);
                Prefs.Save();
                Playback.Main?.Reapply();
                Build();
            });
        }

        private void Build()
        {
            var focusedIndex = _list.Children.OfType<Button>().ToList().FindIndex(b => b.IsKeyboardFocused);
            _list.Children.Clear();
            _first = null;
            var s = Prefs.S;
            var profile = Profiles.Current();

            Section("Cuenta");
            Row("Cuenta", s.User, G.User, null, s.ExpDate > 0 ? "Vence: " + TextUtil.ExpText(s.ExpDate) + (s.MaxConnections > 0 ? "   ·   Pantallas: " + s.MaxConnections : "") : null);
            Row("Perfil", profile?.DisplayName ?? "", G.Smile, () => { Playback.Stop(); Prefs.S.ProfileChosen = false; Prefs.Save(); Main.Reset(new ProfilesPage()); }, "Cambiar de perfil");
            Row("Cerrar sesión", "", G.Close, () => Dialogs.Confirm("Cerrar sesión", "Se cerrará la sesión en esta PC.", "Cerrar sesión", () =>
            {
                Playback.Stop();
                Prefs.Logout();
                Catalog.Clear();
                Main.Reset(new LoginPage());
            }));

            Section("Reproducción");
            var bufs = new[] { "Normal (arranque rápido)", "Alto (recomendado)", "Máximo (internet inestable)" };
            Row("Búfer", bufs[Clamp(s.Buffer, 0, 2)], G.Refresh, () => Choose("Búfer", bufs, s.Buffer, i => s.Buffer = i),
                "Más búfer = menos pausas si el internet varía (tarda un poco más en arrancar)");
            var decs = new[] { "Automático (tarjeta de video, recomendado)", "Software (solo si algo no se ve)" };
            Row("Decodificador", decs[Clamp(s.Decoder, 0, 1)], G.Settings, () => Choose("Decodificador", decs, s.Decoder, i => s.Decoder = i));
            var quals = new[] { "Alta calidad", "Rendimiento (PCs sencillas)" };
            Row("Calidad de imagen", quals[Clamp(s.Quality, 0, 1)], G.Video, () => Choose("Calidad de imagen", quals, s.Quality, i =>
            {
                s.Quality = i;
                Main.Toast("Se aplica al volver a abrir la app");
            }));
            var fmts = new[] { "TS (cambia de canal más rápido)", "HLS (.m3u8)" };
            int fi = s.LiveFormat == "m3u8" ? 1 : 0;
            Row("Formato de TV en vivo", fmts[fi], G.Tv, () => Choose("Formato de TV en vivo", fmts, fi, i => s.LiveFormat = i == 1 ? "m3u8" : "ts"));
            var audios = new[] { "Español", "Inglés", "Original" };
            var ac = new[] { "es", "en", "" };
            int ai = Math.Max(0, Array.IndexOf(ac, s.AudioLang));
            Row("Idioma de audio", audios[ai], G.Audio, () => Choose("Idioma de audio", audios, ai, i => s.AudioLang = ac[i]));
            var subs = new[] { "Desactivados", "Español", "Inglés" };
            var sc = new[] { "off", "es", "en" };
            int si = Math.Max(0, Array.IndexOf(sc, s.SubLang));
            Row("Subtítulos", subs[si], G.Subs, () => Choose("Subtítulos", subs, si, i => s.SubLang = sc[i]));
            Row("Siguiente episodio automático", s.AutoNext ? "Sí" : "No", G.Next, () => { s.AutoNext = !s.AutoNext; Prefs.Save(); Build(); });
            Row("Datos de reproducción", s.PlayerStats ? "Sí" : "No", G.Info, () => { s.PlayerStats = !s.PlayerStats; Prefs.Save(); Build(); },
                "Búfer, velocidad, resolución, códec, decodificador y cuadros perdidos encima del video");

            Section("Pantalla");
            Row("Abrir en pantalla completa", s.StartFullscreen ? "Sí" : "No", G.Full, () => { s.StartFullscreen = !s.StartFullscreen; Prefs.Save(); Build(); }, "F11 cambia en cualquier momento");
            Row("No apagar la pantalla", s.KeepAwake ? "Siempre (con la app abierta)" : "No", G.Tv, () => { s.KeepAwake = !s.KeepAwake; Prefs.Save(); Power.Apply(); Build(); });
            Row("Contenido para adultos", s.ShowAdult ? "Visible" : "Oculto", G.Lock, ToggleAdult, "Pide la contraseña de tu cuenta para mostrarlo");

            Section("Contenido");
            Row("Actualizar catálogo", Catalog.Loading ? "Actualizando…" : "", G.Refresh, async () =>
            {
                Main.Toast("Actualizando catálogo…");
                bool ok = await Catalog.Refresh();
                Main.Toast(ok ? "Catálogo actualizado" : "No se pudo actualizar");
            });
            Row("Borrar imágenes guardadas", "", G.Delete, () =>
            {
                try
                {
                    foreach (var f in new DirectoryInfo(Paths.Dir("img")).GetFiles()) { try { f.Delete(); } catch { } }
                    Main.Toast("Listo");
                }
                catch { }
            }, "Libera espacio; las imágenes se vuelven a descargar al verlas");

            Section("Ayuda");
            Row("Soporte por WhatsApp", "", G.User, LoginPage.OpenWhatsApp, "Escríbenos si algo no funciona");
            Row("Versión", "PTV PLUS para Windows " + typeof(SettingsPage).Assembly.GetName().Version.ToString(3), G.Info, null);

            if (focusedIndex >= 0)
            {
                var buttons = _list.Children.OfType<Button>().ToList();
                if (focusedIndex < buttons.Count) buttons[focusedIndex].Focus();
            }
        }

        private void ToggleAdult()
        {
            var s = Prefs.S;
            if (s.ShowAdult)
            {
                s.ShowAdult = false;
                Prefs.Save();
                Build();
                return;
            }
            Dialogs.Input("Contenido para adultos", "Escribe la contraseña de tu cuenta", "", true, v =>
            {
                if (v == Prefs.Pass)
                {
                    s.ShowAdult = true;
                    Prefs.Save();
                    Build();
                    Main.Toast("Contenido para adultos visible");
                }
                else Main.Toast("Contraseña incorrecta");
            });
        }

        private static int Clamp(int v, int a, int b) => Math.Max(a, Math.Min(b, v));
    }
}
