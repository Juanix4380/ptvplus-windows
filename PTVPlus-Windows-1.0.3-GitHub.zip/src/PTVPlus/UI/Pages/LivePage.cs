using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// TV en vivo con vista previa separada de la guía. El reproductor solamente se extiende
    /// a toda la pantalla a petición del usuario. Esc regresa a la guía o a Inicio.
    /// </summary>
    public sealed class LivePage : Page
    {
        public const string FavKey = "fav";
        public const string RecentKey = "recent";
        public const string EventsKey = "events";
        public const string AllKey = "all";

        private readonly int? _startId;
        private string _catKey;
        // A la izquierda hay una guía fija; el vídeo se coloca a la derecha.
        // Únicamente al ampliar el vídeo se usa toda la pantalla.
        private const double NavWidth = 556;
        private double _navWidth = NavWidth;
        private Grid _guideColumns;
        private bool _expanded;
        private readonly Grid _videoSlot = new Grid();
        private readonly Grid _ov = new Grid();
        private readonly Grid _hit = new Grid { Background = new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)), Focusable = true };
        private readonly Border _panel = new Border { HorizontalAlignment = HorizontalAlignment.Left, Width = NavWidth };
        private StackPanel _navHeader;
        private readonly StackPanel _edgeButtons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 22, 20, 0) };
        private Button _edgeBack; // Retroceso siempre visible en TV ampliada.
        private readonly Button _soundBtn = Ui.Round(G.Volume, null, "Silenciar o activar sonido");
        private readonly Button _expandBtn = Ui.Round(G.Full, null, "Ampliar o reducir el vídeo");
        private readonly ListBox _cats = new ListBox();
        private readonly ListBox _channels = new ListBox();
        private readonly TextBox _search = new TextBox();
        private readonly TextBlock _chTitle = Ui.T("", 20, Brushes.White, FontWeights.Bold);
        private readonly Border _banner = new Border { VerticalAlignment = VerticalAlignment.Bottom, Visibility = Visibility.Collapsed };
        private readonly Image _bLogo = new Image { Width = 120, Height = 72, Stretch = Stretch.Uniform };
        private readonly TextBlock _bName = Ui.T("", 20, Brushes.White, FontWeights.Bold);
        private readonly TextBlock _bNow = Ui.T("", 13, Ui.Hex("#FFE4DDF2"));
        private readonly TextBlock _bNext = Ui.T("", 12, Ui.Hex("#FFB3A9C9"));
        private readonly Grid _bProg = new Grid { Height = 4, Width = 210, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 10, 0, 6) };
        private readonly Border _bProgFill = new Border { HorizontalAlignment = HorizontalAlignment.Left, CornerRadius = new CornerRadius(2) };
        private readonly TextBlock _bClock = Ui.T("", 20, Brushes.White, FontWeights.SemiBold);
        private readonly TextBlock _status = Ui.T("", 20, Brushes.White, FontWeights.SemiBold);
        private readonly Border _digitsBox = new Border { Visibility = Visibility.Collapsed, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 82, 34, 0) };
        private readonly TextBlock _digits = Ui.T("", 44, Brushes.White, FontWeights.Bold);
        private readonly TextBlock _stats = Ui.T("", 13, Brushes.White);
        private List<CatEntry> _entries = new List<CatEntry>();
        private List<Item> _shown = new List<Item>();
        private DispatcherTimer _hideBanner, _digitTimer, _tick, _searchTimer;
        private string _digitBuf = "";
        private int _epgFor;

        public override FrameworkElement VideoSlot => _videoSlot;
        public override bool VideoFull => _expanded;
        public override UIElement OverlayContent => _ov;

        public LivePage(int? channelId, string startKey)
        {
            _startId = channelId;
            _catKey = startKey ?? (string.IsNullOrEmpty(Prefs.S.LastLiveCat) ? AllKey : Prefs.S.LastLiveCat);
            Background = Ui.B("Bg");
            ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(NavWidth) });
            ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _videoSlot.Background = Brushes.Black;
            _videoSlot.Margin = new Thickness(10, 12, 12, 12);
            Grid.SetColumn(_videoSlot, 1);
            Children.Add(_videoSlot);
            BuildOverlay();
            SizeChanged += (s, e) => AdjustGuideWidth();
        }

        // ------------------------------------------------------------ capa

        private void BuildOverlay()
        {
            _hit.MouseMove += (s, e) => { if (_expanded) ShowEdgeButtons(); };
            _hit.MouseLeftButtonUp += (s, e) =>
            {
                if (_expanded) ShowEdgeButtons();
                else ExpandVideo();
            };
            _ov.Children.Add(_hit);

            // Estado (conectando / reconectando / error)
            _status.HorizontalAlignment = HorizontalAlignment.Stretch;
            _status.Margin = new Thickness(NavWidth + 20, 0, 20, 0);
            _status.VerticalAlignment = VerticalAlignment.Center;
            _status.TextWrapping = TextWrapping.Wrap;
            _status.TextAlignment = TextAlignment.Center;
            _status.MaxWidth = 700;
            _status.Effect = Ui.Shadow(12, 0.9);
            _status.IsHitTestVisible = false;
            _ov.Children.Add(_status);

            // Panel izquierdo: categorías | canales
            _panel.Background = Ui.Hex("#FF100B19");
            _panel.BorderBrush = Ui.Hex("#FF322347");
            _panel.BorderThickness = new Thickness(0, 0, 1, 0);
            var cols = new Grid { Margin = new Thickness(12, 76, 10, 16) };
            _guideColumns = cols;
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(180) });
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var catCol = new DockPanel { Margin = new Thickness(0, 0, 14, 0) };
            var ct = Ui.T("● CATEGORÍAS", 13, Ui.B("Accent"), FontWeights.Bold);
            ct.Margin = new Thickness(12, 0, 0, 12);
            DockPanel.SetDock(ct, Dock.Top);
            catCol.Children.Add(ct);
            _cats.Style = Ui.S("PlainList");
            _cats.ItemContainerStyle = Ui.S("RowItem");
            _cats.ItemTemplate = (DataTemplate)Application.Current.Resources["CatTemplate"];
            catCol.Children.Add(_cats);
            cols.Children.Add(catCol);

            var chCol = new DockPanel();
            Grid.SetColumn(chCol, 1);
            var sbox = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            _search.Style = Ui.S("Field");
            _search.Height = 46;
            _search.Padding = new Thickness(42, 0, 12, 0);
            sbox.Children.Add(_search);
            var si = Ui.Icon(G.Search, 15, Ui.B("Text3"));
            si.HorizontalAlignment = HorizontalAlignment.Left;
            si.Margin = new Thickness(15, 0, 0, 0);
            si.IsHitTestVisible = false;
            sbox.Children.Add(si);
            var sh = Ui.T("Buscar canal", 15, Ui.B("Text3"));
            sh.VerticalAlignment = VerticalAlignment.Center;
            sh.Margin = new Thickness(44, 0, 0, 0);
            sh.IsHitTestVisible = false;
            sbox.Children.Add(sh);
            _search.TextChanged += (s, e) =>
            {
                sh.Visibility = _search.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
                _searchTimer?.Stop();
                _searchTimer = UiThread.After(220, RunSearch);
                BumpPanel();
            };
            DockPanel.SetDock(sbox, Dock.Top);
            chCol.Children.Add(sbox);
            _chTitle.Margin = new Thickness(6, 0, 0, 8);
            _chTitle.TextTrimming = TextTrimming.CharacterEllipsis;
            _chTitle.TextWrapping = TextWrapping.NoWrap;
            _chTitle.TextTrimming = TextTrimming.CharacterEllipsis;
            _chTitle.FontSize = 18;
            DockPanel.SetDock(_chTitle, Dock.Top);
            chCol.Children.Add(_chTitle);
            _channels.Style = Ui.S("PlainList");
            _channels.ItemContainerStyle = Ui.S("RowItem");
            _channels.ItemTemplate = (DataTemplate)Application.Current.Resources["ChannelTemplate"];
            chCol.Children.Add(_channels);
            cols.Children.Add(chCol);
            _panel.Child = cols;
            _panel.Visibility = Visibility.Collapsed;
            _ov.Children.Add(_panel);

            // Atrás siempre visible; todos los botones pertenecen a esta pantalla,
            // no se crean ventanas externas ni controles encima de las listas.
            var navHeader = new StackPanel { Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(18, 16, 0, 0) };
            var back = Ui.Round(G.Back, () => Main.Back(), "Atrás a Inicio (Esc)");
            back.Width = back.Height = 46;
            navHeader.Children.Add(back);
            var name = Ui.T("TV EN VIVO", 19, Brushes.White, FontWeights.Bold);
            name.VerticalAlignment = VerticalAlignment.Center;
            name.Margin = new Thickness(13, 0, 0, 0);
            navHeader.Children.Add(name);
            _navHeader = navHeader;
            _ov.Children.Add(navHeader);
            _edgeBack = EdgeButton(G.Back, () => Main.Back(), "Volver a la guía (Esc)");
            _edgeBack.HorizontalAlignment = HorizontalAlignment.Left;
            _edgeBack.VerticalAlignment = VerticalAlignment.Top;
            _edgeBack.Margin = new Thickness(20, 20, 0, 0);
            _edgeBack.Visibility = Visibility.Collapsed;
            _ov.Children.Add(_edgeBack);
            _edgeButtons.Children.Add(EdgeButton(G.Prev, () => Zap(-1), "Canal anterior"));
            _edgeButtons.Children.Add(EdgeButton(G.Next, () => Zap(1), "Canal siguiente"));
            _soundBtn.Width = _soundBtn.Height = 44;
            _soundBtn.Margin = new Thickness(5, 0, 0, 0);
            _soundBtn.Click += (s, e) => ToggleSound();
            _edgeButtons.Children.Add(_soundBtn);
            _expandBtn.Width = _expandBtn.Height = 44;
            _expandBtn.Margin = new Thickness(5, 0, 0, 0);
            _expandBtn.Click += (s, e) => { if (_expanded) CollapseVideo(); else ExpandVideo(); };
            _edgeButtons.Children.Add(_expandBtn);
            _ov.Children.Add(_edgeButtons);

            _cats.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var c = ItemsControl.ContainerFromElement(_cats, e.OriginalSource as DependencyObject) as ListBoxItem;
                if (c?.DataContext is CatEntry ce) ApplyCat(ce);
                e.Handled = true;
            };
            _channels.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var c = ItemsControl.ContainerFromElement(_channels, e.OriginalSource as DependencyObject) as ListBoxItem;
                if (c?.DataContext is Item it) Play(it, true);
                e.Handled = true;
            };
            _cats.PreviewMouseWheel += (s, e) => BumpPanel();
            _channels.PreviewMouseWheel += (s, e) => BumpPanel();

            // Cartel inferior al cambiar de canal
            _banner.Background = new LinearGradientBrush(Color.FromArgb(0x00, 0, 0, 0), Color.FromArgb(0xE6, 0x05, 0x03, 0x09), 90);
            _banner.Padding = new Thickness(12, 12, 12, 10);
            _banner.Margin = new Thickness(NavWidth + 10, 0, 12, 12);
            _banner.IsHitTestVisible = false;
            var bg = new Grid();
            bg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            bg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            bg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            _bLogo.Width = 54;
            _bLogo.Height = 42;
            var logoBox = new Border { Width = 60, Height = 48, CornerRadius = new CornerRadius(10), Background = Ui.Hex("#CC120D1C"), Child = _bLogo, Margin = new Thickness(0, 0, 10, 0) };
            bg.Children.Add(logoBox);
            // Grid en vez de StackPanel: los títulos largos quedan recortados
            // dentro de la superficie del video y nunca pisan el reloj.
            var texts = new Grid { VerticalAlignment = VerticalAlignment.Center };
            for (int i = 0; i < 4; i++) texts.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            _bName.FontSize = 17;
            _bName.TextTrimming = TextTrimming.CharacterEllipsis;
            _bNow.TextTrimming = TextTrimming.CharacterEllipsis;
            _bNext.TextTrimming = TextTrimming.CharacterEllipsis;
            texts.Children.Add(_bName);
            _bProg.Children.Add(new Border { Background = Ui.Hex("#44FFFFFF"), CornerRadius = new CornerRadius(2) });
            _bProgFill.Background = Ui.B("Accent");
            _bProg.Children.Add(_bProgFill);
            _bNow.Margin = new Thickness(0, 3, 0, 0);
            Grid.SetRow(_bNow, 1);
            texts.Children.Add(_bNow);
            Grid.SetRow(_bProg, 2);
            texts.Children.Add(_bProg);
            Grid.SetRow(_bNext, 3);
            texts.Children.Add(_bNext);
            Grid.SetColumn(texts, 1);
            bg.Children.Add(texts);
            _bClock.VerticalAlignment = VerticalAlignment.Top;
            _bClock.Margin = new Thickness(12, 0, 0, 0);
            Grid.SetColumn(_bClock, 2);
            bg.Children.Add(_bClock);
            _banner.Child = bg;
            _ov.Children.Add(_banner);

            // Número de canal tecleado
            _digitsBox.Background = Ui.Hex("#D9120D1C");
            _digitsBox.CornerRadius = new CornerRadius(16);
            _digitsBox.Padding = new Thickness(26, 10, 26, 10);
            _digitsBox.Child = _digits;
            _digitsBox.IsHitTestVisible = false;
            _ov.Children.Add(_digitsBox);

            // Datos de reproducción
            var statsBox = new Border
            {
                Background = Ui.Hex("#C0100A1A"), CornerRadius = new CornerRadius(12), Padding = new Thickness(12, 8, 12, 8),
                HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 82, 20, 0),
                Child = _stats, IsHitTestVisible = false
            };
            _stats.FontFamily = new FontFamily("Consolas");
            _stats.TextTrimming = TextTrimming.None;
            statsBox.SetBinding(VisibilityProperty, new System.Windows.Data.Binding("Text") { Source = _stats, Converter = new EmptyToCollapsed() });
            _ov.Children.Add(statsBox);
        }

        // ------------------------------------------------------- ciclo de vida

        public override void OnShow()
        {
            Catalog.Changed += Reload;
            Playback.Changed += PaintStatus;
            _tick = UiThread.Every(1000, Tick);
            Reload();
            var cur = Playback.Current;
            Item start = null;
            var s = Catalog.Snap;
            if (s != null)
            {
                if (_startId.HasValue) start = s.Find(Kind.Live, _startId.Value);
                if (start == null && _catKey == EventsKey) start = _shown.FirstOrDefault();
                if (start == null) start = s.Find(Kind.Live, Prefs.S.LastLiveId) ?? _shown.FirstOrDefault() ?? s.Live.FirstOrDefault();
            }
            if (cur != null && cur.IsLive && cur.Channel != null && start != null && cur.Channel.Id == start.Id)
            {
                // Viene de la vista previa: el mismo canal sigue, ahora con sonido.
                Playback.Main?.SetMute(false);
                Library.AddRecentLive(start.Id);
                ShowBanner();
            }
            else if (start != null) Play(start, false);
            _expanded = false;
            ShowPanel(true);
            UpdatePlayerLayout();
        }

        public override void OnHide()
        {
            Catalog.Changed -= Reload;
            Playback.Changed -= PaintStatus;
            _tick?.Stop();
            _hideBanner?.Stop();
            _digitTimer?.Stop();
            _searchTimer?.Stop();
            _zapTimer?.Stop();
            _edgeHide?.Stop();
            Main.Activate();
        }

        public override void FocusFirst()
        {
            // El teclado va a la capa de encima del video (listas y controles).
            Main.Overlay?.Activate();
            if (!_expanded) FocusCat();
            else _hit.Focus();
        }

        public override bool OnBack()
        {
            if (_search.Text.Length > 0 && _search.IsKeyboardFocusWithin) { _search.Text = ""; return true; }
            if (_expanded) { CollapseVideo(); return true; }
            return false;
        }

        // ------------------------------------------------------------- datos

        private void Reload()
        {
            var s = Catalog.Snap;
            if (s == null) { _status.Text = Catalog.Error ?? "Cargando canales…"; return; }
            bool kids = Profiles.Current()?.Kids ?? false;
            bool adult = Prefs.S.ShowAdult && !kids;
            var list = new List<CatEntry>
            {
                new CatEntry { Key = FavKey, Name = "Mis canales", Items = () => Library.Favorites().Where(f => f.Kind == Kind.Live).Select(f => s.Find(Kind.Live, f.Id)).Where(i => i != null).ToList() },
                new CatEntry { Key = RecentKey, Name = "Recientes", Items = () => Library.RecentLive().Select(id => s.Find(Kind.Live, id)).Where(i => i != null).ToList() },
                new CatEntry { Key = EventsKey, Name = "Eventos", Items = () => Scopes.Events(s) },
                new CatEntry { Key = AllKey, Name = "Todos", Count = s.Live.Count(i => adult || !s.IsAdultItem(i)).ToString(), Items = () => s.Live.Where(i => adult || !s.IsAdultItem(i)).ToList() }
            };
            foreach (var c in s.LiveCats)
            {
                if (c.Adult && !adult) continue;
                if (kids && !Scopes.Matches(c, Scopes.KidsWords)) continue;
                int n = s.ItemsOf(Kind.Live, c.Id).Count;
                if (n == 0) continue;
                var cat = c;
                list.Add(new CatEntry { Key = c.Id, Name = c.Name, Count = n.ToString(), Items = () => s.ItemsOf(Kind.Live, cat.Id) });
            }
            _entries = list;
            _cats.ItemsSource = _entries;
            var sel = _entries.FirstOrDefault(e => e.Key == _catKey) ?? _entries.First(e => e.Key == AllKey);
            ApplyCat(sel, false);
            _cats.SelectedItem = sel;
        }

        private void ApplyCat(CatEntry e, bool bump = true)
        {
            if (e == null) return;
            foreach (var x in _entries) x.Applied = x == e;
            _catKey = e.Key;
            if (e.Key != EventsKey) { Prefs.S.LastLiveCat = e.Key; Prefs.Save(); }
            _shown = e.Items() ?? new List<Item>();
            _pendingIndex = -1;
            _zapTimer?.Stop();
            _chTitle.Text = e.Name + "  ·  " + _shown.Count;
            if (_search.Text.Length > 0) _search.Text = "";
            _channels.ItemsSource = _shown;
            int i = PlayingIndex();
            if (i >= 0) { _channels.SelectedIndex = i; _channels.ScrollIntoView(_shown[i]); }
            if (bump) BumpPanel();
        }

        private void RunSearch()
        {
            var s = Catalog.Snap;
            if (s == null) return;
            string q = TextUtil.Norm(_search.Text.Trim());
            if (q.Length == 0)
            {
                var cur = _entries.FirstOrDefault(x => x.Applied);
                _shown = cur?.Items() ?? new List<Item>();
                _chTitle.Text = (cur?.Name ?? "") + "  ·  " + _shown.Count;
            }
            else
            {
                bool adult = Prefs.S.ShowAdult;
                int num;
                bool isNum = int.TryParse(q, out num);
                _shown = s.Live.Where(i => (adult || !s.IsAdultItem(i)) && (i.Norm.Contains(q) || (isNum && i.Num == num))).Take(300).ToList();
                _chTitle.Text = "Resultados  ·  " + _shown.Count;
            }
            _channels.ItemsSource = _shown;
        }

        private int PlayingIndex()
        {
            var cur = Playback.Current;
            if (cur == null || cur.Channel == null) return _shown.Count > 0 ? 0 : -1;
            int i = _shown.FindIndex(x => x.Id == cur.Channel.Id);
            return i >= 0 ? i : (_shown.Count > 0 ? 0 : -1);
        }

        // ------------------------------------------------------------- canal

        private void Play(Item it, bool fromList)
        {
            if (it == null) return;
            var cur = Playback.Current;
            if (cur != null && cur.Channel != null && cur.Channel.Id == it.Id && Playback.LastError == null)
            {
                if (fromList) ExpandVideo(); // Segundo toque: pantalla completa.
                return;
            }
            _zapTimer?.Stop();
            Playback.PlayChannel(it, false);
            _epgFor = 0;
            ShowBanner();
        }

        private DispatcherTimer _zapTimer, _edgeHide;
        private int _pendingIndex = -1;

        private void Zap(int delta)
        {
            if (_shown.Count == 0) return;
            // Las pulsaciones rápidas se unen: no lanzar decenas de conexiones
            // ni verificaciones Cloud para navegar por la lista.
            int i = _pendingIndex >= 0 ? _pendingIndex : PlayingIndex();
            int n = ((i + delta) % _shown.Count + _shown.Count) % _shown.Count;
            _pendingIndex = n;
            _channels.SelectedIndex = n;
            _zapTimer?.Stop();
            _zapTimer = UiThread.After(180, () =>
            {
                if (n >= _shown.Count) return;
                _pendingIndex = -1;
                Play(_shown[n], false);
            });
        }

        // ------------------------------------------------------------ panel

        private void AdjustGuideWidth()
        {
            // Guía flexible: el video conserva al menos la mitad de la pantalla.
            if (ActualWidth < 1) return;
            double width = Math.Min(NavWidth, Math.Max(400, ActualWidth * 0.49));
            if (Math.Abs(width - _navWidth) < 1) return;
            _navWidth = width;
            ColumnDefinitions[0].Width = new GridLength(_navWidth);
            _panel.Width = _navWidth;
            if (_guideColumns != null)
                _guideColumns.ColumnDefinitions[0].Width = new GridLength(Math.Max(142, Math.Min(180, _navWidth * 0.34)));
            UpdatePlayerLayout();
        }

        private static Button EdgeButton(string glyph, Action click, string tooltip)
        {
            var b = Ui.Round(glyph, click, tooltip);
            b.Width = b.Height = 44;
            b.Margin = new Thickness(5, 0, 0, 0);
            return b;
        }

        private void UpdatePlayerLayout()
        {
            _panel.Visibility = _expanded ? Visibility.Collapsed : Visibility.Visible;
            _status.MaxWidth = _expanded ? 700 : Math.Max(180, ActualWidth - _navWidth - 40);
            _navHeader.Visibility = _expanded ? Visibility.Collapsed : Visibility.Visible;
            _banner.Margin = _expanded ? new Thickness(24, 0, 24, 18) : new Thickness(_navWidth + 10, 0, 12, 12);
            _bClock.Visibility = _expanded ? Visibility.Visible : Visibility.Collapsed;
            _bProg.Width = _expanded ? 210 : Math.Max(90, Math.Min(180, ActualWidth - _navWidth - 142));
            _status.Margin = _expanded ? new Thickness(20, 0, 20, 0) : new Thickness(_navWidth + 20, 0, 20, 0);
            _expandBtn.Content = _expanded ? G.ExitFull : G.Full;
            // Atrás visible también cuando se esconden los demás controles.
            _edgeBack.Visibility = _expanded ? Visibility.Visible : Visibility.Collapsed;
            _edgeButtons.Visibility = Visibility.Visible;
            Main.RefreshVideoPlacement();
        }

        private void ExpandVideo()
        {
            if (_expanded) return;
            _expanded = true;
            UpdatePlayerLayout();
            Main.Overlay?.Activate();
            _hit.Focus();
            ShowEdgeButtons();
        }

        private void CollapseVideo()
        {
            if (!_expanded) return;
            _expanded = false;
            UpdatePlayerLayout();
            Main.Overlay?.Activate();
            FocusChannel(PlayingIndex());
        }

        private void ToggleSound()
        {
            var p = Playback.Main;
            if (p == null) return;
            p.SetMute(!p.Muted);
            _soundBtn.Content = p.Muted ? G.Mute : G.Volume;
            ShowEdgeButtons();
        }

        private void ShowEdgeButtons()
        {
            _edgeHide?.Stop();
            _edgeButtons.Visibility = Visibility.Visible;
            if (_expanded)
                _edgeHide = UiThread.After(5000, () => { if (_expanded && !_edgeButtons.IsMouseOver) _edgeButtons.Visibility = Visibility.Collapsed; });
        }

        private void ShowPanel(bool focusCats)
        {
            if (_expanded) { CollapseVideo(); return; }
            _panel.Visibility = Visibility.Visible;
            Main.Overlay?.Activate();
            if (focusCats) FocusCat();
            else FocusChannel(PlayingIndex());
        }

        private void HidePanel()
        {
            // Ya no se esconden las categorías al seleccionar un canal.
            // Para ver la TV sin listas se amplía el video explícitamente.
            ExpandVideo();
        }

        private void BumpPanel() { /* Guía fija, sin ocultado automático. */ }

        private void FocusChannel(int i)
        {
            if (_shown.Count == 0) { FocusCat(); return; }
            i = Math.Max(0, Math.Min(i, _shown.Count - 1));
            _channels.SelectedIndex = i;
            _channels.ScrollIntoView(_shown[i]);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                var c = _channels.ItemContainerGenerator.ContainerFromIndex(i) as ListBoxItem;
                c?.Focus();
            }), DispatcherPriority.Loaded);
        }

        private void FocusCat()
        {
            var cur = _entries.FirstOrDefault(e => e.Applied);
            if (cur == null) return;
            _cats.SelectedItem = cur;
            _cats.ScrollIntoView(cur);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                var c = _cats.ItemContainerGenerator.ContainerFromItem(cur) as ListBoxItem;
                c?.Focus();
            }), DispatcherPriority.Loaded);
        }

        // ----------------------------------------------------------- cartel

        private void ShowBanner()
        {
            // La guía tiene su propia columna; el cartel solo ocupa el área de vídeo.
            var cur = Playback.Current;
            var it = cur?.Channel;
            if (it == null) return;
            _bName.Text = (it.Num > 0 ? it.Num + "   " : "") + it.Name;
            Images.Load(_bLogo, it.Icon, 240);
            _bClock.Text = DateTime.Now.ToString("h:mm tt", new CultureInfo("es-MX"));
            if (_epgFor != it.Id) LoadEpg(it);
            if (_banner.Visibility != Visibility.Visible)
            {
                _banner.Visibility = Visibility.Visible;
                _banner.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(160)));
            }
            _hideBanner?.Stop();
            _hideBanner = UiThread.After(5000, () => _banner.Visibility = Visibility.Collapsed);
        }

        private async void LoadEpg(Item it)
        {
            _epgFor = it.Id;
            _bNow.Text = "";
            _bNext.Text = "";
            _bProg.Visibility = Visibility.Collapsed;
            try
            {
                var list = await Xtream.ShortEpg(Prefs.Account(), it.Id, 4);
                if (_epgFor != it.Id) return;
                long now = J.NowMs();
                var cur = list.FirstOrDefault(e => e.Start <= now && (e.End == 0 || e.End > now));
                var next = list.FirstOrDefault(e => e.Start > now);
                if (cur != null)
                {
                    _bNow.Text = "Ahora: " + cur.Title + (cur.End > 0 ? "   (" + cur.Hours + ")" : "");
                    _bProg.Visibility = Visibility.Visible;
                    _bProgFill.Width = Math.Max(4, _bProg.Width * cur.Progress(now));
                }
                if (next != null) _bNext.Text = "Después: " + next.Title + "   " + TextUtil.Clock(next.Start);
            }
            catch { }
        }

        private void PaintStatus()
        {
            var m = Playback.Main;
            if (Playback.LastError != null) _status.Text = Playback.LastError;
            else if (Playback.Notice != null) _status.Text = Playback.Notice;
            else if (m != null && Playback.Current != null && (m.Buffering || (m.CoreIdle && m.Position <= 0))) _status.Text = "Cargando…";
            else _status.Text = "";
        }

        private void Tick()
        {
            PaintStatus();
            _stats.Text = Prefs.S.PlayerStats && Playback.Main != null && Playback.Current != null ? Playback.Main.Stats() : "";
            _soundBtn.Content = Playback.Main != null && Playback.Main.Muted ? G.Mute : G.Volume;
        }

        // ------------------------------------------------------------ teclado

        public override bool OnKey(KeyEventArgs e)
        {
            var k = e.Key;
            bool panel = !_expanded;
            // Número de canal directo
            int digit = -1;
            if (k >= Key.D0 && k <= Key.D9 && !_search.IsKeyboardFocusWithin) digit = k - Key.D0;
            if (k >= Key.NumPad0 && k <= Key.NumPad9) digit = k - Key.NumPad0;
            if (digit >= 0 && !_search.IsKeyboardFocusWithin)
            {
                Digit(digit);
                return true;
            }
            if (k == Key.M) { ToggleSound(); return true; }
            if (k == Key.F) { if (_expanded) CollapseVideo(); else ExpandVideo(); return true; }
            if (!panel)
            {
                switch (k)
                {
                    case Key.Up:
                    case Key.PageUp:
                    case Key.MediaPreviousTrack:
                        Zap(-1);
                        return true;
                    case Key.Down:
                    case Key.PageDown:
                    case Key.MediaNextTrack:
                        Zap(1);
                        return true;
                    case Key.Enter:
                    case Key.Space:
                    case Key.Right:
                        ShowEdgeButtons();
                        return true;
                    case Key.Left:
                        CollapseVideo();
                        return true;
                    case Key.I:
                        ShowBanner();
                        return true;
                }
                return false;
            }
            bool inCats = _cats.IsKeyboardFocusWithin, inCh = _channels.IsKeyboardFocusWithin;
            if (inCats)
            {
                if (k == Key.Enter || k == Key.Space) { ApplyCat(_cats.SelectedItem as CatEntry); return true; }
                if (k == Key.Right) { FocusChannel(Math.Max(0, _channels.SelectedIndex)); return true; }
                if (k == Key.Left) return true;
            }
            else if (inCh)
            {
                if (k == Key.Enter || k == Key.Space) { Play(_channels.SelectedItem as Item, true); return true; }
                if (k == Key.Left) { FocusCat(); return true; }
                if (k == Key.Right) return true;
                if (k == Key.Up && _channels.SelectedIndex <= 0) { _search.Focus(); return true; }
                if (k == Key.F2 && _channels.SelectedItem is Item fit)
                {
                    bool on = Library.ToggleFav(fit);
                    Main.Toast(on ? "Agregado a Mis canales" : "Quitado de Mis canales");
                    return true;
                }
            }
            else if (_search.IsKeyboardFocusWithin)
            {
                if (k == Key.Down || k == Key.Enter) { FocusChannel(0); return true; }
            }
            else if (k == Key.Enter || k == Key.Space) { ExpandVideo(); return true; }
            return false;
        }

        private void Digit(int d)
        {
            if (_digitBuf.Length >= 4) _digitBuf = "";
            _digitBuf += d.ToString();
            _digits.Text = _digitBuf;
            _digitsBox.Visibility = Visibility.Visible;
            _digitTimer?.Stop();
            _digitTimer = UiThread.After(1400, () =>
            {
                _digitsBox.Visibility = Visibility.Collapsed;
                int n = J.ToInt(_digitBuf);
                _digitBuf = "";
                var s = Catalog.Snap;
                var it = s?.Live.FirstOrDefault(x => x.Num == n);
                if (it != null) Play(it, false);
                else Main.Toast("No existe el canal " + n);
            });
        }
    }

    /// <summary>Oculta un elemento cuando su texto está vacío.</summary>
    public sealed class EmptyToCollapsed : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
            string.IsNullOrEmpty(value as string) ? Visibility.Collapsed : Visibility.Visible;

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => System.Windows.Data.Binding.DoNothing;
    }
}
