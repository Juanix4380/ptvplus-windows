using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PTVPlus.Core;

namespace PTVPlus.UI.Pages
{
    /// <summary>Entrada de la lista de categorías (la elegida lleva barra morada).</summary>
    public sealed class CatEntry : INotifyPropertyChanged
    {
        public string Key { get; set; } = "";
        public string Name { get; set; } = "";
        public string Count { get; set; } = "";
        public Func<List<Item>> Items;
        private bool _applied;
        public bool Applied
        {
            get { return _applied; }
            set { if (_applied != value) { _applied = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Applied))); } }
        }
        public event PropertyChangedEventHandler PropertyChanged;
    }

    /// <summary>Un renglón de la cuadrícula (se arma al aparecer en pantalla).</summary>
    public sealed class RowData
    {
        public List<Item> Items;
        public int Index;
        public double CardWidth;
        public CatalogPage Page;
    }

    public sealed class GridRow : StackPanel
    {
        public GridRow()
        {
            Orientation = Orientation.Horizontal;
            Margin = new Thickness(0, 4, 0, 14);
            DataContextChanged += (s, e) => Build();
        }

        private void Build()
        {
            Children.Clear();
            var d = DataContext as RowData;
            if (d == null || d.Items == null) return;
            for (int i = 0; i < d.Items.Count; i++)
            {
                var it = d.Items[i];
                var page = d.Page;
                var card = Ui.Poster(it, d.CardWidth, () => page.Open(it), page.PercentOf(it));
                card.DataContext = null;
                card.Uid = d.Index + ":" + i;
                Children.Add(card);
            }
        }
    }

    /// <summary>
    /// Todo / Películas / Series / Anime / Niños / Especial: categorías a la izquierda, tarjetas a la
    /// derecha con el título abajo y buscador arriba. Enter elige la categoría y el foco se queda en la lista.
    /// </summary>
    public sealed class CatalogPage : Page
    {
        public const string KeySeen = "seen";
        public const string KeyAll = "all";
        public const string KeyNew = "new";
        public const string KeyTop = "top";
        public const string KeyFav = "fav";

        private readonly string _scope;
        private string _selectedKey;
        private readonly bool _startSearch;
        private readonly ListBox _cats = new ListBox();
        private readonly ListBox _grid = new ListBox();
        private readonly TextBox _search = new TextBox();
        private readonly TextBlock _catTitle = Ui.T("", 24, Ui.B("Text"), FontWeights.Bold);
        private readonly TextBlock _catCount = Ui.T("", 14, Ui.B("Text3"));
        private readonly TextBlock _empty = Ui.T("", 16, Ui.B("Text2"));
        private readonly Grid _gridHost = new Grid();
        private List<CatEntry> _entries = new List<CatEntry>();
        private List<Item> _shown = new List<Item>();
        private List<RowData> _rows = new List<RowData>();
        private int _columns = 6;
        private double _cardW = 160;
        private int _builtVersion = -1;
        private string _query = "";
        private DispatcherTimer _searchTimer;
        private Dictionary<string, int> _progress = new Dictionary<string, int>();

        public CatalogPage(string scope, string startKey = null, bool search = false)
        {
            _scope = scope ?? Scopes.All;
            _selectedKey = startKey ?? KeyAll;
            _startSearch = search;
            Background = Ui.B("Bg");
            RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // Arriba: atrás, título y buscador
            var top = new Grid { Margin = new Thickness(40, 22, 40, 12) };
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var left = new StackPanel { Orientation = Orientation.Horizontal };
            left.Children.Add(Ui.Round(G.Back, () => Main.Back(), "Atrás"));
            var t = Ui.T(Scopes.Title(_scope), 28, Ui.B("Text"), FontWeights.Bold);
            t.VerticalAlignment = VerticalAlignment.Center;
            t.Margin = new Thickness(16, 0, 0, 0);
            left.Children.Add(t);
            top.Children.Add(left);
            var sbox = new Grid { Width = 460 };
            _search.Style = Ui.S("Field");
            _search.Padding = new Thickness(44, 0, 14, 0);
            sbox.Children.Add(_search);
            var sicon = Ui.Icon(G.Search, 16, Ui.B("Text3"));
            sicon.HorizontalAlignment = HorizontalAlignment.Left;
            sicon.Margin = new Thickness(16, 0, 0, 0);
            sicon.IsHitTestVisible = false;
            sbox.Children.Add(sicon);
            var hint = Ui.T("Buscar títulos", 16, Ui.B("Text3"));
            hint.Margin = new Thickness(46, 0, 0, 0);
            hint.VerticalAlignment = VerticalAlignment.Center;
            hint.IsHitTestVisible = false;
            sbox.Children.Add(hint);
            _search.TextChanged += (s, e) =>
            {
                hint.Visibility = _search.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
                _searchTimer?.Stop();
                _searchTimer = UiThread.After(260, RunSearch);
            };
            _search.KeyDown += (s, e) =>
            {
                if (e.Key == Key.Down || e.Key == Key.Enter) { e.Handled = true; FocusCard(0, 0); }
            };
            Grid.SetColumn(sbox, 2);
            top.Children.Add(sbox);
            Children.Add(top);

            // Abajo: categorías | tarjetas
            var body = new Grid { Margin = new Thickness(40, 6, 24, 0) };
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(300) });
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetRow(body, 1);

            var side = new Border { Background = Ui.Hex("#B3120D1C"), CornerRadius = new CornerRadius(18), Padding = new Thickness(10), Margin = new Thickness(0, 0, 0, 24) };
            var sideStack = new DockPanel();
            var ct = Ui.T("CATEGORÍAS", 12.5, Ui.B("Text3"), FontWeights.Bold);
            ct.Margin = new Thickness(12, 6, 0, 8);
            DockPanel.SetDock(ct, Dock.Top);
            sideStack.Children.Add(ct);
            _cats.Style = Ui.S("PlainList");
            _cats.ItemContainerStyle = Ui.S("RowItem");
            _cats.ItemTemplate = (DataTemplate)Application.Current.Resources["CatTemplate"];
            sideStack.Children.Add(_cats);
            side.Child = sideStack;
            body.Children.Add(side);

            var right = new Grid { Margin = new Thickness(26, 0, 0, 0) };
            right.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            right.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            var head = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
            head.Children.Add(_catTitle);
            _catCount.VerticalAlignment = VerticalAlignment.Bottom;
            _catCount.Margin = new Thickness(12, 0, 0, 4);
            head.Children.Add(_catCount);
            right.Children.Add(head);
            _grid.Style = Ui.S("PlainList");
            _grid.ItemContainerStyle = Ui.S("GridRowItem");
            _grid.ItemTemplate = new DataTemplate { VisualTree = new FrameworkElementFactory(typeof(GridRow)) };
            _grid.Padding = new Thickness(8, 8, 8, 40);
            KeyboardNavigation.SetDirectionalNavigation(_grid, KeyboardNavigationMode.None);
            _gridHost.Children.Add(_grid);
            _empty.HorizontalAlignment = HorizontalAlignment.Center;
            _empty.VerticalAlignment = VerticalAlignment.Center;
            _empty.TextWrapping = TextWrapping.Wrap;
            _gridHost.Children.Add(_empty);
            Grid.SetRow(_gridHost, 1);
            right.Children.Add(_gridHost);
            Grid.SetColumn(right, 1);
            body.Children.Add(right);
            Children.Add(body);

            _cats.PreviewKeyDown += OnCatsKey;
            _cats.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var item = ItemsControl.ContainerFromElement(_cats, e.OriginalSource as DependencyObject) as ListBoxItem;
                if (item?.DataContext is CatEntry ce) Apply(ce, false);
            };
            _gridHost.SizeChanged += (s, e) => Relayout();
        }

        public override void OnShow()
        {
            Catalog.Changed += Reload;
            Library.Changed += OnLibrary;
            Reload();
        }

        public override void OnHide()
        {
            Catalog.Changed -= Reload;
            Library.Changed -= OnLibrary;
        }

        public override void FocusFirst()
        {
            if (_startSearch) { _search.Focus(); return; }
            FocusSelectedCat();
        }

        private bool Kids => Profiles.Current()?.Kids ?? false;

        // ------------------------------------------------------------------ datos

        private void Reload()
        {
            var s = Catalog.Snap;
            if (s == null)
            {
                _empty.Text = Catalog.Error ?? "Cargando contenido…";
                return;
            }
            if (_builtVersion == Catalog.Version && _entries.Count > 0) return;
            _builtVersion = Catalog.Version;
            BuildProgress();
            bool kids = Kids;
            var scopeItems = Scopes.Items(s, _scope, kids);
            var keys = new HashSet<string>(scopeItems.Select(i => i.Key));
            var list = new List<CatEntry>();
            Func<List<Item>> seen = () => Library.History()
                .Select(h => h.Kind == Kind.Movie ? s.Find(Kind.Movie, J.ToInt(h.Id)) : s.Find(Kind.Series, h.SeriesId))
                .Where(i => i != null && keys.Contains(i.Key)).GroupBy(i => i.Key).Select(g => g.First()).ToList();
            list.Add(new CatEntry { Key = KeySeen, Name = "Recién visto", Items = seen });
            list.Add(new CatEntry { Key = KeyAll, Name = "Todo", Count = scopeItems.Count.ToString(), Items = () => scopeItems });
            list.Add(new CatEntry { Key = KeyNew, Name = "Recién agregadas", Items = () => scopeItems.OrderByDescending(i => i.Added).Take(300).ToList() });
            list.Add(new CatEntry { Key = KeyTop, Name = "Mejor calificadas", Items = () => scopeItems.Where(i => i.Rating >= 7.5f && i.Rating <= 10f).OrderByDescending(i => i.Rating).Take(300).ToList() });
            list.Add(new CatEntry
            {
                Key = KeyFav, Name = "Mi lista",
                Items = () => Library.Favorites().Where(f => f.Kind != Kind.Live).Select(f => s.Find(f.Kind, f.Id)).Where(i => i != null && keys.Contains(i.Key)).ToList()
            });
            foreach (var c in Scopes.Cats(s, _scope, kids))
            {
                var cat = c;
                int n = s.ItemsOf(c.Kind, c.Id).Count;
                string prefix = _scope == Scopes.All || _scope == Scopes.Anime || _scope == Scopes.Kids || _scope == Scopes.Special
                    ? (c.Kind == Kind.Movie ? "Películas · " : "Series · ") : "";
                list.Add(new CatEntry
                {
                    Key = "c:" + c.Kind + ":" + c.Id, Name = prefix + c.Name, Count = n.ToString(),
                    Items = () => s.ItemsOf(cat.Kind, cat.Id).OrderByDescending(i => i.Added).ToList()
                });
            }
            _entries = list;
            _cats.ItemsSource = _entries;
            var start = _entries.FirstOrDefault(e => e.Key == _selectedKey) ?? _entries[1];
            Apply(start, false);
            _cats.SelectedItem = start;
            _cats.ScrollIntoView(start);
            if (_startSearch) _search.Focus();
        }

        private void OnLibrary()
        {
            BuildProgress();
            var cur = _entries.FirstOrDefault(e => e.Applied);
            if (cur != null && (cur.Key == KeySeen || cur.Key == KeyFav) && _query.Length == 0) Apply(cur, false);
        }

        private void BuildProgress()
        {
            _progress = new Dictionary<string, int>();
            foreach (var h in Library.History())
            {
                string key = h.Kind == Kind.Movie ? Kind.Movie + ":" + h.Id : Kind.Series + ":" + h.SeriesId;
                if (!_progress.ContainsKey(key)) _progress[key] = h.Percent;
            }
        }

        public int PercentOf(Item it)
        {
            int p;
            return _progress.TryGetValue(it.Key, out p) ? p : -1;
        }

        private void Apply(CatEntry e, bool focusGrid)
        {
            if (e == null) return;
            foreach (var x in _entries) x.Applied = x == e;
            _selectedKey = e.Key;
            _query = "";
            if (_search.Text.Length > 0) _search.Text = "";
            Show(e.Name, e.Items());
            if (focusGrid) FocusCard(0, 0);
        }

        private void RunSearch()
        {
            var s = Catalog.Snap;
            if (s == null) return;
            string q = TextUtil.Norm(_search.Text.Trim());
            _query = q;
            if (q.Length == 0)
            {
                var cur = _entries.FirstOrDefault(e => e.Applied);
                if (cur != null) Show(cur.Name, cur.Items());
                return;
            }
            var words = q.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var results = Scopes.Items(s, _scope, Kids).Where(i => words.All(w => i.Norm.Contains(w)))
                .OrderByDescending(i => i.Norm.StartsWith(q)).ThenByDescending(i => i.Added).Take(400).ToList();
            Show("Resultados", results);
        }

        private void Show(string title, List<Item> items)
        {
            _shown = items ?? new List<Item>();
            _catTitle.Text = title;
            _catCount.Text = _shown.Count == 1 ? "1 título" : _shown.Count + " títulos";
            _empty.Text = _shown.Count == 0 ? (_query.Length > 0 ? "No se encontró nada con esa búsqueda" : "Aquí no hay títulos todavía") : "";
            Relayout(true);
        }

        private void Relayout(bool force = false)
        {
            double w = _gridHost.ActualWidth - 16;
            if (w <= 0) return;
            double target = w > 1500 ? 190 : w > 1100 ? 170 : 150;
            int cols = Math.Max(2, (int)(w / (target + 18)));
            double cardW = Math.Floor(w / cols) - 18;
            if (!force && cols == _columns && Math.Abs(cardW - _cardW) < 1 && _rows.Count > 0) return;
            _columns = cols;
            _cardW = cardW;
            var rows = new List<RowData>();
            for (int i = 0; i < _shown.Count; i += cols)
                rows.Add(new RowData { Items = _shown.Skip(i).Take(cols).ToList(), Index = rows.Count, CardWidth = cardW, Page = this });
            _rows = rows;
            _grid.ItemsSource = _rows;
            if (_rows.Count > 0) _grid.ScrollIntoView(_rows[0]);
        }

        public void Open(Item it) => Main.Go(new DetailPage(it));

        // ----------------------------------------------------------------- teclado

        private void FocusSelectedCat()
        {
            var cur = _cats.SelectedItem ?? _entries.FirstOrDefault(e => e.Applied);
            if (cur == null) return;
            _cats.ScrollIntoView(cur);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                var c = _cats.ItemContainerGenerator.ContainerFromItem(cur) as ListBoxItem;
                c?.Focus();
            }), DispatcherPriority.Loaded);
        }

        private void OnCatsKey(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter || e.Key == Key.Space)
            {
                Apply(_cats.SelectedItem as CatEntry, false);
                e.Handled = true;
            }
            else if (e.Key == Key.Right)
            {
                FocusCard(0, 0);
                e.Handled = true;
            }
        }

        private void FocusCard(int row, int col)
        {
            if (_rows.Count == 0) return;
            row = Math.Max(0, Math.Min(row, _rows.Count - 1));
            col = Math.Max(0, Math.Min(col, _rows[row].Items.Count - 1));
            _grid.ScrollIntoView(_rows[row]);
            int r = row, c = col;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                var container = _grid.ItemContainerGenerator.ContainerFromIndex(r) as ListBoxItem;
                var gr = Ui.FindChild<GridRow>(container);
                if (gr != null && c < gr.Children.Count) ((UIElement)gr.Children[c]).Focus();
            }), DispatcherPriority.Loaded);
        }

        private bool CardPos(out int row, out int col)
        {
            row = col = -1;
            var el = Keyboard.FocusedElement as FrameworkElement;
            if (el == null || string.IsNullOrEmpty(el.Uid) || !el.Uid.Contains(":")) return false;
            var parts = el.Uid.Split(':');
            row = J.ToInt(parts[0], -1);
            col = J.ToInt(parts[1], -1);
            return row >= 0 && col >= 0 && _grid.IsKeyboardFocusWithin;
        }

        public override bool OnKey(KeyEventArgs e)
        {
            int row, col;
            if (!CardPos(out row, out col)) return false;
            switch (e.Key)
            {
                case Key.Down:
                    if (row + 1 < _rows.Count) FocusCard(row + 1, col);
                    return true;
                case Key.Up:
                    if (row > 0) FocusCard(row - 1, col);
                    else _search.Focus();
                    return true;
                case Key.Left:
                    if (col > 0) FocusCard(row, col - 1);
                    else FocusSelectedCat();
                    return true;
                case Key.Right:
                    if (col + 1 < _rows[row].Items.Count) FocusCard(row, col + 1);
                    return true;
                case Key.PageDown:
                    FocusCard(Math.Min(_rows.Count - 1, row + 4), col);
                    return true;
                case Key.PageUp:
                    FocusCard(Math.Max(0, row - 4), col);
                    return true;
            }
            return false;
        }
    }
}
