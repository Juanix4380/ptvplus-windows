using System.Collections.Generic;
using System.Linq;

namespace PTVPlus.Core
{
    /// <summary>Apartados (Películas, Series, Anime, Niños, Especial, Eventos) por palabras de las categorías.</summary>
    public static class Scopes
    {
        public const string All = "all";
        public const string Movies = "movies";
        public const string Series = "series";
        public const string Anime = "anime";
        public const string Kids = "kids";
        public const string Special = "special";

        public static readonly string[] AnimeWords = { "anime", "manga", "crunchyroll", "otaku", "japones", "japon" };
        public static readonly string[] KidsWords =
        {
            "infantil", "nino", "kids", "disney junior", "nick", "cartoon", "animad", "familia", "familiar",
            "preescolar", "pre-escolar", "pre escolar", "dibujo", "pixar", "dreamworks", "junior", "baby", "bebe", "princes"
        };
        public static readonly string[] EventWords = { "evento", "ppv", "pay per view", "deporte", "sport", "futbol", "ufc", "wwe", "boxeo", "nfl", "nba", "liga" };

        public sealed class Group
        {
            public string Name;
            public string[] Keys;
            public Group(string name, params string[] keys) { Name = name; Keys = keys; }
        }

        public static readonly Group[] Platforms =
        {
            new Group("Netflix", "netflix"), new Group("Disney", "disney"), new Group("Apple TV", "apple"),
            new Group("Max", "hbo", " max", "max "), new Group("Prime Video", "prime", "amazon"),
            new Group("Star+", "star+", "star plus"), new Group("Paramount+", "paramount"), new Group("ViX", "vix"),
            new Group("Universal+", "universal"), new Group("Crunchyroll", "crunchyroll")
        };

        public static readonly Group[] Themes =
        {
            new Group("Estrenos", "estreno", "en cines", "cine 20", "taquilla"),
            new Group("Documentales", "documental", "docu"),
            new Group("Superhéroes", "superhero", "super hero", "superheroe", "marvel", "dc comics", " dc"),
            new Group("Sagas y colecciones", "saga", "coleccion", "collection", "trilog"),
            new Group("Conciertos y música", "concierto", "musical", "music"),
            new Group("Terror", "terror", "horror", "miedo"),
            new Group("Navidad", "navidad", "christmas", "navideñ"),
            new Group("Deportes", "deporte", "futbol", "ufc", "wwe", "boxeo", "box ", "nfl", "nba", "formula"),
            new Group("4K Ultra HD", "4k", "uhd")
        };

        public static bool Matches(Category c, IEnumerable<string> keys) => keys.Any(k => c.Norm.Contains(k));

        public static string Title(string scope)
        {
            switch (scope)
            {
                case Movies: return "Películas";
                case Series: return "Series";
                case Anime: return "Anime";
                case Kids: return "Niños";
                case Special: return "Especial";
                default: return "Todo";
            }
        }

        /// <summary>Categorías de películas y series que entran en el apartado.</summary>
        public static List<Category> Cats(Snapshot s, string scope, bool kidsProfile)
        {
            IEnumerable<Category> cats;
            switch (scope)
            {
                case Movies: cats = s.MovieCats; break;
                case Series: cats = s.SeriesCats; break;
                case Anime: cats = s.MovieCats.Concat(s.SeriesCats).Where(c => Matches(c, AnimeWords)); break;
                case Kids: cats = s.MovieCats.Concat(s.SeriesCats).Where(c => Matches(c, KidsWords)); break;
                case Special:
                    cats = s.MovieCats.Concat(s.SeriesCats).Where(c => Platforms.Any(p => Matches(c, p.Keys)) || Themes.Any(t => Matches(c, t.Keys)));
                    break;
                default: cats = s.MovieCats.Concat(s.SeriesCats); break;
            }
            if (kidsProfile && scope != Kids && scope != Anime) cats = cats.Where(c => Matches(c, KidsWords) || Matches(c, AnimeWords));
            bool adult = Prefs.S.ShowAdult && !kidsProfile;
            return cats.Where(c => (adult || !c.Adult) && s.ItemsOf(c.Kind, c.Id).Count > 0).ToList();
        }

        public static List<Item> Items(Snapshot s, string scope, bool kidsProfile)
        {
            if ((scope == All || scope == Movies || scope == Series) && !kidsProfile)
            {
                bool adult = Prefs.S.ShowAdult;
                IEnumerable<Item> src = scope == Movies ? s.Movies : scope == Series ? s.Series : s.Movies.Concat(s.Series);
                return src.Where(i => adult || !s.IsAdultItem(i)).ToList();
            }
            var list = new List<Item>();
            foreach (var c in Cats(s, scope, kidsProfile)) list.AddRange(s.ItemsOf(c.Kind, c.Id));
            return list;
        }

        /// <summary>Canales de eventos: categorías de eventos/PPV o nombres con "vs".</summary>
        public static List<Item> Events(Snapshot s)
        {
            var cats = new HashSet<string>(s.LiveCats.Where(c => !c.Adult && Matches(c, EventWords)).Select(c => c.Id));
            return s.Live.Where(i => (cats.Contains(i.CatId) && !i.Norm.Contains("sin evento")) || i.Norm.Contains(" vs ") || i.Norm.Contains(" vs."))
                .Where(i => !s.IsAdultItem(i)).ToList();
        }
    }
}
