using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;

namespace PTVPlus.Core
{
    /// <summary>Carpetas de la app en %LocalAppData%\PTVPlus.</summary>
    public static class Paths
    {
        public static readonly string Root = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PTVPlus");

        public static string File(string name)
        {
            Directory.CreateDirectory(Root);
            return Path.Combine(Root, name);
        }

        public static string Dir(string name)
        {
            string d = Path.Combine(Root, name);
            Directory.CreateDirectory(d);
            return d;
        }

        /// <summary>Escribe completo o nada (no deja archivos a medias si se apaga la PC).</summary>
        public static void WriteAtomic(string path, string text)
        {
            string tmp = path + ".tmp";
            System.IO.File.WriteAllText(tmp, text, new UTF8Encoding(false));
            if (System.IO.File.Exists(path)) System.IO.File.Replace(tmp, path, null, true);
            else System.IO.File.Move(tmp, path);
        }

        public static string Hash(string s)
        {
            byte[] b = SHA1.HashData(Encoding.UTF8.GetBytes(s ?? ""));
            var sb = new StringBuilder(40);
            foreach (byte x in b) sb.Append(x.ToString("x2", CultureInfo.InvariantCulture));
            return sb.ToString();
        }
    }

    /// <summary>Registro de errores (log.txt), sin datos de la cuenta.</summary>
    public static class Log
    {
        private static readonly object Gate = new object();
        private static string _file;

        public static void Init()
        {
            try
            {
                _file = Paths.File("log.txt");
                var fi = new FileInfo(_file);
                if (fi.Exists && fi.Length > 1_000_000) fi.Delete();
                Write("Inicio PTV PLUS " + typeof(Log).Assembly.GetName().Version);
            }
            catch { }
        }

        public static void Write(string msg)
        {
            if (_file == null) return;
            try
            {
                lock (Gate) System.IO.File.AppendAllText(_file, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ", CultureInfo.InvariantCulture) + msg + Environment.NewLine);
            }
            catch { }
        }

        public static void Error(Exception e, string where = "")
        {
            if (e == null) return;
            Write("ERROR " + where + ": " + e.GetType().Name + ": " + e.Message + Environment.NewLine + e.StackTrace);
        }
    }

    /// <summary>La pantalla no se apaga ni la PC se suspende mientras la app está abierta.</summary>
    public static class Power
    {
        private const uint ES_CONTINUOUS = 0x80000000;
        private const uint ES_SYSTEM_REQUIRED = 0x00000001;
        private const uint ES_DISPLAY_REQUIRED = 0x00000002;

        [DllImport("kernel32.dll")]
        private static extern uint SetThreadExecutionState(uint flags);

        public static void Apply()
        {
            try
            {
                if (Prefs.S.KeepAwake) SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED);
                else SetThreadExecutionState(ES_CONTINUOUS);
            }
            catch { }
        }

        public static void Release()
        {
            try { SetThreadExecutionState(ES_CONTINUOUS); } catch { }
        }
    }

    /// <summary>Contraseña y sesión cifradas con la cuenta de Windows (DPAPI): solo este usuario las lee.</summary>
    public static class Secret
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct DataBlob
        {
            public int cbData;
            public IntPtr pbData;
        }

        [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool CryptProtectData(ref DataBlob dataIn, string description, IntPtr entropy,
            IntPtr reserved, IntPtr prompt, int flags, ref DataBlob dataOut);

        [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool CryptUnprotectData(ref DataBlob dataIn, IntPtr description, IntPtr entropy,
            IntPtr reserved, IntPtr prompt, int flags, ref DataBlob dataOut);

        [DllImport("kernel32.dll")]
        private static extern IntPtr LocalFree(IntPtr mem);

        private const int UiForbidden = 0x1;

        public static string Protect(string plain)
        {
            if (string.IsNullOrEmpty(plain)) return "";
            byte[] data = Encoding.UTF8.GetBytes(plain);
            byte[] result = Run(data, true);
            return result == null ? "" : Convert.ToBase64String(result);
        }

        public static string Unprotect(string stored)
        {
            if (string.IsNullOrEmpty(stored)) return "";
            try
            {
                byte[] result = Run(Convert.FromBase64String(stored), false);
                return result == null ? "" : Encoding.UTF8.GetString(result);
            }
            catch
            {
                return "";
            }
        }

        private static byte[] Run(byte[] data, bool protect)
        {
            IntPtr buf = Marshal.AllocHGlobal(data.Length);
            try
            {
                Marshal.Copy(data, 0, buf, data.Length);
                var input = new DataBlob { cbData = data.Length, pbData = buf };
                var output = new DataBlob();
                bool ok = protect
                    ? CryptProtectData(ref input, "PTVPlus", IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, UiForbidden, ref output)
                    : CryptUnprotectData(ref input, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, UiForbidden, ref output);
                if (!ok || output.pbData == IntPtr.Zero) return null;
                var bytes = new byte[output.cbData];
                Marshal.Copy(output.pbData, bytes, 0, output.cbData);
                LocalFree(output.pbData);
                return bytes;
            }
            finally
            {
                Marshal.FreeHGlobal(buf);
            }
        }
    }

    /// <summary>Lectura tolerante de JSON (las APIs mandan números como texto y viceversa).</summary>
    public static class J
    {
        public static JsonNode Parse(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            try { return JsonNode.Parse(s); }
            catch { return null; }
        }

        public static JsonObject Obj(string s) => Parse(s) as JsonObject;

        public static string Text(JsonNode v, string def = "")
        {
            if (v == null) return def;
            if (v is JsonValue jv)
            {
                if (jv.TryGetValue(out string s)) return s ?? def;
                if (jv.TryGetValue(out long l)) return l.ToString(CultureInfo.InvariantCulture);
                if (jv.TryGetValue(out double d)) return d.ToString(CultureInfo.InvariantCulture);
                if (jv.TryGetValue(out bool b)) return b ? "true" : "false";
                return jv.ToJsonString().Trim('"');
            }
            return def;
        }

        public static string Str(JsonNode n, string key, string def = "")
        {
            if (!(n is JsonObject o)) return def;
            JsonNode v;
            if (!o.TryGetPropertyValue(key, out v) || v == null) return def;
            string t = Text(v, def);
            return t ?? def;
        }

        public static long Long(JsonNode n, string key, long def = 0)
        {
            string s = Str(n, key, "");
            if (long.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out long l)) return l;
            if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out double d)) return (long)d;
            return def;
        }

        public static int Int(JsonNode n, string key, int def = 0) => (int)Long(n, key, def);

        public static bool Bool(JsonNode n, string key, bool def = false)
        {
            string s = Str(n, key, "").Trim().ToLowerInvariant();
            if (s.Length == 0) return def;
            return s == "true" || s == "1" || s == "yes";
        }

        public static JsonObject ObjOf(JsonNode n, string key) => (n as JsonObject)?[key] as JsonObject;
        public static JsonArray ArrOf(JsonNode n, string key) => (n as JsonObject)?[key] as JsonArray;

        public static long ToLong(string s, long def = 0)
        {
            if (long.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out long l)) return l;
            return def;
        }

        public static int ToInt(string s, int def = 0)
        {
            if (int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out int i)) return i;
            return def;
        }

        public static float ToFloat(string s, float def = 0f)
        {
            if (string.IsNullOrWhiteSpace(s)) return def;
            if (float.TryParse(s.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out float f)) return f;
            return def;
        }

        public static long NowMs() => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
    }
}
