using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace PTVPlus.Core
{
    /// <summary>
    /// Panel Premium Cloud (el mismo de la app de Android): inicio de sesión, autorización de cada
    /// reproducción, perfiles y datos de cada perfil. El servidor Xtream solo lo entrega Cloud.
    /// </summary>
    public static class Cloud
    {
        public const string Api = "https://martineztvxtream.com/cloud";
        private static readonly Regex TokenRx = new Regex("^[a-fA-F0-9]{64}$", RegexOptions.Compiled);

        public sealed class Resp
        {
            public int Code;
            public JsonObject Json;
            public string Raw = "";
            public bool Ok => Code >= 200 && Code <= 299;
        }

        public sealed class LoginResult
        {
            public string AccountId = "";
            public string Server = "";
            public string Username = "";
            public string Token = "";
        }

        public sealed class Decision
        {
            public bool Allowed;
            public string Message = "";
            public string Reason = "";
        }

        public static async Task<Resp> Request(string path, JsonObject payload, string token = "", int timeoutMs = 15000)
        {
            if (path.Contains("..") || !path.StartsWith("/")) throw new ArgumentException("Ruta no válida");
            using (var req = new HttpRequestMessage(HttpMethod.Post, Api + path))
            using (var cts = new CancellationTokenSource(timeoutMs))
            {
                req.Content = new StringContent(payload.ToJsonString(), Encoding.UTF8, "application/json");
                req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                if (!string.IsNullOrEmpty(token)) req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                using (var resp = await Net.Client.SendAsync(req, cts.Token).ConfigureAwait(false))
                {
                    string raw = await resp.Content.ReadAsStringAsync(cts.Token).ConfigureAwait(false);
                    var json = J.Obj(raw);
                    if (json == null)
                    {
                        Log.Write("Cloud " + path + " HTTP " + (int)resp.StatusCode + " sin JSON: " + Cut(raw));
                        throw new IOException("El servicio respondió algo inesperado (código " + (int)resp.StatusCode + ")");
                    }
                    return new Resp { Code = (int)resp.StatusCode, Json = json, Raw = raw };
                }
            }
        }

        private static bool Active(JsonNode info)
        {
            string auth = J.Str(info, "auth");
            bool verified = auth == "1" || auth.Equals("true", StringComparison.OrdinalIgnoreCase);
            string status = J.Str(info, "status", "active").ToLowerInvariant();
            long exp = J.Long(info, "exp_date");
            var bad = new[] { "expired", "disabled", "banned", "suspended", "inactive" };
            return verified && !bad.Contains(status) && (exp <= 0 || exp * 1000L > J.NowMs());
        }

        public static async Task<LoginResult> Login(string username, string password)
        {
            // Misma petición que la app de Android (el panel ya la acepta).
            var r = await LoginRequest(username, password).ConfigureAwait(false);
            var data = r.Json;
            if (!r.Ok || !J.Bool(data, "success"))
            {
                string msg = J.Str(data, "message").Trim();
                if (msg.Length == 0) msg = J.Str(data, "error").Trim();
                if (msg.Length == 0) msg = J.Str(data, "reason").Trim();
                if (msg.Length == 0) msg = "No se pudo validar la cuenta";
                Log.Write("Cloud login HTTP " + r.Code + ": " + Cut(r.Raw));
                throw new IOException(msg + " (código " + r.Code + ")");
            }
            string token = J.Str(data, "sessionToken");
            string accountId = J.Str(J.ObjOf(data, "account"), "accountKey");
            string server = J.Str(data, "serverUrl").TrimEnd('/');
            var info = J.ObjOf(J.ObjOf(data, "data"), "user_info") ?? new JsonObject();
            if (!TokenRx.IsMatch(token) || accountId.Length == 0 || !Active(info) ||
                !(server.StartsWith("https://", StringComparison.OrdinalIgnoreCase) || server.StartsWith("http://", StringComparison.OrdinalIgnoreCase)))
                throw new IOException("Cloud no autorizó la sesión o el servidor");
            return new LoginResult { AccountId = accountId, Server = server, Username = username, Token = token };
        }

        private static Task<Resp> LoginRequest(string username, string password)
        {
            string name = "Windows " + Environment.MachineName;
            if (name.Length > 40) name = name.Substring(0, 40);
            return Request("/login", new JsonObject
            {
                ["username"] = username,
                ["password"] = password,
                ["deviceId"] = Prefs.S.DeviceId,
                ["deviceName"] = name,
                ["deviceType"] = "android"
            });
        }

        private static string Cut(string s)
        {
            s = (s ?? "").Replace("\r", " ").Replace("\n", " ");
            s = System.Text.RegularExpressions.Regex.Replace(s, @"""(serverUrl|sessionToken|password|accountKey)""\s*:\s*""[^""]*""", @"""$1"":""…""");
            return s.Length > 400 ? s.Substring(0, 400) : s;
        }

        /// <summary>
        /// Autorización obligatoria antes de reproducir, al cambiar de canal y cada 25 s.
        /// Sin respuesta de Cloud no se reproduce (sin respaldo local).
        /// </summary>
        public static async Task<Decision> Verify()
        {
            if (!Prefs.S.Logged || string.IsNullOrEmpty(Prefs.Token) || string.IsNullOrEmpty(Prefs.Pass) || string.IsNullOrEmpty(Prefs.S.AccountId))
                return new Decision { Allowed = false, Message = "Inicia sesión para continuar", Reason = "session_required" };
            string token = Prefs.Token;
            string account = Prefs.S.AccountId;
            // Reintentar únicamente errores de red / HTTP temporal.
            // No autorizar reproducción si el servidor no ha confirmado la sesión.
            for (int intento = 0; intento < 3; intento++)
            {
                try
                {
                    var r = await Request("/session/status", new JsonObject { ["password"] = Prefs.Pass }, token, 12000).ConfigureAwait(false);
                    if (Prefs.Token != token || Prefs.S.AccountId != account)
                        return new Decision { Allowed = false, Message = "La sesión cambió. Vuelve a iniciar sesión", Reason = "session_changed" };
                    // Errores de infraestructura son temporales, NO vencimiento de cuenta.
                    if (r.Code == 408 || r.Code == 429 || r.Code >= 500)
                        throw new IOException("Estado del panel HTTP " + r.Code);
                    var json = r.Json;
                    if (r.Ok && J.Bool(json, "success") && J.Bool(json, "active"))
                        return new Decision { Allowed = true, Reason = "ok" };
                    string msg = J.Str(json, "message");
                    string reason = J.Str(json, "reason", "not_authorized");
                    if (msg.Length == 0)
                    {
                        switch (reason)
                        {
                            case "server_removed": msg = "Tu servicio no está disponible"; break;
                            case "account_expired": msg = "Tu servicio está vencido"; break;
                            case "account_inactive": msg = "Tu cuenta está suspendida o inactiva"; break;
                            default: msg = "El panel rechazó la sesión (HTTP " + r.Code + "). Vuelve a iniciar sesión"; break;
                        }
                    }
                    Log.Write("Cloud Verify rechazado: HTTP " + r.Code + " / " + reason);
                    return new Decision { Allowed = false, Message = msg, Reason = reason };
                }
                catch (Exception e)
                {
                    // El log permite identificar DNS / TLS / espera / fallo HTTP.
                    // No contiene contraseñas ni tokens del request.
                    Log.Write("Cloud Verify error " + (intento + 1) + "/3: " + e.GetType().Name + " " + Cut(e.Message));
                    if (intento < 2) await Task.Delay(650 * (intento + 1)).ConfigureAwait(false);
                }
            }
            return new Decision
            {
                Allowed = false,
                Message = "No hubo respuesta del panel para verificar tu cuenta. Revisa internet e intenta de nuevo (sin cambiar tu cuenta).",
                Reason = "cloud_unavailable"
            };
        }

        // ------------------------------------------------------------------ API con sesión

        public static async Task<JsonObject> Post(string path, JsonObject payload)
        {
            if (!Prefs.CloudReady) throw new IOException("Inicia sesión en el panel Cloud");
            string account = Prefs.S.AccountId;
            string token = Prefs.Token;
            var r = await Request(path, payload, token).ConfigureAwait(false);
            if (account != Prefs.S.AccountId || token != Prefs.Token) throw new IOException("La cuenta cambió");
            if (!r.Ok && !J.Bool(r.Json, "conflict"))
                throw new IOException(J.Str(r.Json, "message", "Error de Cloud (HTTP " + r.Code + ")"));
            return r.Json;
        }

        public sealed class RemoteSync
        {
            public JsonObject Data;
            public long Revision;
            public bool HasData;
        }

        public static async Task<RemoteSync> Download(string uuid)
        {
            var reply = await Post("/sync/download", new JsonObject { ["profileUuid"] = uuid }).ConfigureAwait(false);
            if (!J.Bool(reply, "success")) throw new IOException(J.Str(reply, "message", "No se descargó el perfil"));
            long rev = J.Long(reply, "revision");
            var data = J.ObjOf(reply, "syncData");
            data = data == null ? new JsonObject() : (JsonObject)data.DeepClone();
            return new RemoteSync { Data = data, Revision = rev, HasData = J.Bool(reply, "hasData", rev > 0) };
        }

        /// <summary>Cambia datos del perfil sin pisar lo que guardaron otros equipos (reintenta si hubo conflicto).</summary>
        public static async Task<JsonObject> Change(string uuid, Action<JsonObject> change)
        {
            for (int attempt = 0; attempt < 3; attempt++)
            {
                var previous = await Download(uuid).ConfigureAwait(false);
                var merged = (JsonObject)previous.Data.DeepClone();
                change(merged);
                var payload = new JsonObject
                {
                    ["profileUuid"] = uuid,
                    ["deviceId"] = Prefs.S.DeviceId,
                    ["revision"] = previous.Revision,
                    ["syncData"] = merged.DeepClone()
                };
                if (J.Str(previous.Data, "__profile_pin_hash") != J.Str(merged, "__profile_pin_hash"))
                    payload["accountPassword"] = Prefs.Pass;
                var result = await Post("/sync/upload", payload).ConfigureAwait(false);
                if (J.Bool(result, "success")) return merged;
                if (!J.Bool(result, "conflict"))
                    throw new IOException(J.Str(result, "message", "No se guardaron los cambios en Cloud"));
            }
            throw new IOException("Conflicto de sincronización con Cloud");
        }
    }

    /// <summary>Perfiles del panel Cloud: posición, UUID, avatar (0..12), infantil y huella del PIN.</summary>
    public static class Profiles
    {
        public const int Max = 10;
        public static readonly string[] AvatarNames =
        {
            "León", "Lobo", "Tigre", "Zorro", "Panda", "Puma", "Caballo", "Águila", "Avatar 9", "Avatar 10",
            "Infantil 1", "Infantil 2", "Infantil 3"
        };

        private static string FilePath => Paths.File("profiles_" + Paths.Hash(Prefs.S.AccountId) + ".json");

        public static string HashPin(string pin, int index)
        {
            byte[] b = SHA256.HashData(Encoding.UTF8.GetBytes("ptv|" + index + "|" + pin));
            var sb = new StringBuilder(64);
            foreach (byte x in b) sb.Append(x.ToString("x2", CultureInfo.InvariantCulture));
            return sb.ToString();
        }

        public static bool PinMatches(Profile p, string value) =>
            !p.HasPin || string.Equals(HashPin(value, p.Index), p.Pin, StringComparison.OrdinalIgnoreCase);

        public static List<Profile> List()
        {
            try
            {
                if (!File.Exists(FilePath)) return new List<Profile>();
                var list = System.Text.Json.JsonSerializer.Deserialize<List<Profile>>(File.ReadAllText(FilePath)) ?? new List<Profile>();
                return list.Where(p => p.Index >= 0 && p.Index < Max).OrderBy(p => p.Index).ToList();
            }
            catch
            {
                return new List<Profile>();
            }
        }

        private static void Cache(List<Profile> list)
        {
            if (string.IsNullOrEmpty(Prefs.S.AccountId)) return;
            try { Paths.WriteAtomic(FilePath, System.Text.Json.JsonSerializer.Serialize(list.OrderBy(p => p.Index).ToList())); }
            catch (Exception e) { Log.Error(e, "Profiles.Cache"); }
        }

        public static async Task<List<Profile>> Refresh()
        {
            if (!Prefs.CloudReady) return List();
            var r = await Cloud.Post("/profiles/list", new JsonObject()).ConfigureAwait(false);
            if (!J.Bool(r, "success")) throw new IOException("Cloud no devolvió los perfiles");
            var cached = List().ToDictionary(p => p.Id, p => p);
            var remote = new List<Profile>();
            var arr = J.ArrOf(r, "profiles") ?? new JsonArray();
            for (int i = 0; i < arr.Count; i++)
            {
                var o = arr[i];
                int index = J.Int(o, "positionOrder", i);
                if (index < 0 || index >= Max) continue;
                string id = index.ToString(CultureInfo.InvariantCulture);
                string uid = J.Str(o, "profileUuid");
                if (uid.Length == 0) uid = Guid.NewGuid().ToString();
                Profile old;
                cached.TryGetValue(id, out old);
                string pin = old != null && old.Uuid == uid ? old.Pin : "";
                remote.Add(new Profile
                {
                    Id = id,
                    Name = J.Str(o, "profileName", "Perfil " + (index + 1)),
                    Kids = J.Bool(o, "isKids"),
                    Pin = pin,
                    Avatar = Math.Max(0, Math.Min(12, J.ToInt(J.Str(o, "avatar", "0")))),
                    Uuid = uid
                });
            }
            Cache(remote);
            return remote;
        }

        /// <summary>El PIN se comprueba en Cloud en cada entrada (igual que en Android).</summary>
        public static async Task<Profile> RefreshPin(Profile p)
        {
            if (!Prefs.CloudReady) return p;
            var cloud = await Cloud.Download(p.Uuid).ConfigureAwait(false);
            string hash = J.Str(cloud.Data, "__profile_pin_hash");
            if (hash.Length > 0 && !Regex.IsMatch(hash, "^[A-Fa-f0-9]{64}$")) throw new IOException("El PIN remoto no es válido");
            p.Pin = hash;
            var list = List();
            foreach (var x in list) if (x.Id == p.Id && x.Uuid == p.Uuid) x.Pin = hash;
            Cache(list);
            return p;
        }

        public static Profile NewProfile(string name, int avatar, string pin, bool kids)
        {
            var used = new HashSet<int>(List().Select(p => p.Index));
            int next = -1;
            for (int i = 0; i < Max; i++) if (!used.Contains(i)) { next = i; break; }
            if (next < 0) throw new IOException("Máximo 10 perfiles");
            return new Profile
            {
                Id = next.ToString(CultureInfo.InvariantCulture), Name = (name ?? "").Trim(), Kids = kids,
                Pin = string.IsNullOrEmpty(pin) ? "" : HashPin(pin, next), Avatar = Math.Max(0, Math.Min(12, avatar)),
                Uuid = Guid.NewGuid().ToString()
            };
        }

        public static async Task<List<Profile>> Save(Profile p, bool updatePin)
        {
            if (string.IsNullOrWhiteSpace(p.Name)) throw new IOException("Escribe el nombre del perfil");
            var existing = List();
            if (existing.All(x => x.Id != p.Id) && existing.Count >= Max) throw new IOException("Máximo 10 perfiles");
            var reply = await Cloud.Post("/profiles/save", new JsonObject
            {
                ["profileUuid"] = p.Uuid,
                ["profileName"] = p.Name,
                ["avatar"] = p.Avatar.ToString(CultureInfo.InvariantCulture),
                ["positionOrder"] = p.Index,
                ["isKids"] = p.Kids
            }).ConfigureAwait(false);
            if (!J.Bool(reply, "success")) throw new IOException("Cloud no confirmó el perfil");
            if (updatePin)
            {
                string hash = p.Pin ?? "";
                await Cloud.Change(p.Uuid, d =>
                {
                    d["__profile_pin_hash"] = hash;
                    d["__profile_pin_changed_at"] = J.NowMs();
                    d["__profile_pin_checked"] = true;
                }).ConfigureAwait(false);
            }
            var result = existing.Where(x => x.Id != p.Id).ToList();
            result.Add(p);
            result = result.OrderBy(x => x.Index).ToList();
            Cache(result);
            return result;
        }

        public static async Task<List<Profile>> Delete(Profile p)
        {
            var reply = await Cloud.Post("/profiles/delete", new JsonObject
            {
                ["profileUuid"] = p.Uuid,
                ["accountPassword"] = Prefs.Pass
            }).ConfigureAwait(false);
            if (!J.Bool(reply, "success")) throw new IOException("Cloud no confirmó la eliminación");
            var result = List().Where(x => x.Id != p.Id).ToList();
            Cache(result);
            return result;
        }

        public static Profile Current()
        {
            return List().FirstOrDefault(p => p.Id == Prefs.S.ProfileId);
        }
    }
}
