using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PTVPlus.Core
{
    /// <summary>API de Xtream Codes (player_api.php). El servidor lo entrega Cloud al iniciar sesión.</summary>
    public static class Xtream
    {
        private static readonly Regex RelImg = new Regex("^/[A-Za-z0-9_/-]+\\.(jpg|jpeg|png|webp)$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public static string NormalizeServer(string raw)
        {
            string s = (raw ?? "").Trim();
            if (s.Length == 0) return s;
            if (!s.StartsWith("http://", StringComparison.OrdinalIgnoreCase) && !s.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                s = "http://" + s;
            foreach (var cut in new[] { "/player_api.php", "/get.php", "/panel_api.php", "/xmltv.php", "/live/", "/movie/", "/series/" })
            {
                int i = s.IndexOf(cut, StringComparison.OrdinalIgnoreCase);
                if (i > 0) s = s.Substring(0, i);
            }
            return s.TrimEnd('/');
        }

        private static string E(string s) => Uri.EscapeDataString(s ?? "");

        public static string Api(Account a, string action, string extra = "")
        {
            var b = new StringBuilder(a.Server.TrimEnd('/'));
            b.Append("/player_api.php?username=").Append(E(a.User)).Append("&password=").Append(E(a.Pass));
            if (action != null) b.Append("&action=").Append(action);
            b.Append(extra);
            return b.ToString();
        }

        public static string LiveUrl(Account a, int id, string format) =>
            a.Server.TrimEnd('/') + "/live/" + E(a.User) + "/" + E(a.Pass) + "/" + id + "." + (string.IsNullOrEmpty(format) ? "ts" : format);

        public static string MovieUrl(Account a, int id, string ext) =>
            a.Server.TrimEnd('/') + "/movie/" + E(a.User) + "/" + E(a.Pass) + "/" + id + "." + (string.IsNullOrEmpty(ext) ? "mp4" : ext);

        public static string EpisodeUrl(Account a, string id, string ext) =>
            a.Server.TrimEnd('/') + "/series/" + E(a.User) + "/" + E(a.Pass) + "/" + id + "." + (string.IsNullOrEmpty(ext) ? "mp4" : ext);

        // ------------------------------------------------------------------ login

        public static async Task<UserInfo> Login(Account a)
        {
            string txt = await Net.GetString(Api(a, null), 15000).ConfigureAwait(false);
            var o = J.Obj(txt);
            if (o == null) throw new IOException("El servidor no respondió como Xtream");
            var ui = J.ObjOf(o, "user_info");
            if (ui == null || J.Str(ui, "auth", "1") == "0") throw new IOException("Usuario o contraseña incorrectos");
            string status = J.Str(ui, "status");
            if (status.Length > 0 && !status.Equals("Active", StringComparison.OrdinalIgnoreCase))
            {
                switch (status.ToLowerInvariant())
                {
                    case "expired": throw new IOException("Tu cuenta venció. Renueva para seguir viendo.");
                    case "banned": throw new IOException("Tu cuenta está bloqueada.");
                    case "disabled": throw new IOException("Tu cuenta está desactivada.");
                    default: throw new IOException("Cuenta " + status);
                }
            }
            return new UserInfo
            {
                Username = J.Str(ui, "username"),
                Status = status,
                ExpDate = J.Long(ui, "exp_date"),
                MaxConnections = J.Int(ui, "max_connections", 1),
                ActiveCons = J.Int(ui, "active_cons"),
                Trial = J.Str(ui, "is_trial") == "1"
            };
        }

        // ------------------------------------------------------------- categorías

        public static async Task<List<Category>> Categories(Account a, int kind)
        {
            string action = kind == Kind.Live ? "get_live_categories" : kind == Kind.Movie ? "get_vod_categories" : "get_series_categories";
            string txt = await Net.GetString(Api(a, action), 25000).ConfigureAwait(false);
            var arr = J.Parse(txt) as JsonArray;
            var outList = new List<Category>();
            if (arr == null) return outList;
            foreach (var n in arr)
            {
                string id = J.Str(n, "category_id");
                if (id.Length == 0) continue;
                var c = new Category { Id = id, Name = J.Str(n, "category_name").Trim(), Kind = kind };
                c.Prepare();
                outList.Add(c);
            }
            return outList;
        }

        // --------------------------------------------------------------- listas

        public static Task<List<Item>> Streams(Account a, int kind)
        {
            string action = kind == Kind.Live ? "get_live_streams" : kind == Kind.Movie ? "get_vod_streams" : "get_series";
            return Net.WithStream(Api(a, action), 180000, async s =>
            {
                var list = new List<Item>(8192);
                using (var doc = await JsonDocument.ParseAsync(s, new JsonDocumentOptions { AllowTrailingCommas = true }).ConfigureAwait(false))
                {
                    if (doc.RootElement.ValueKind != JsonValueKind.Array) return list;
                    foreach (var el in doc.RootElement.EnumerateArray())
                    {
                        if (el.ValueKind != JsonValueKind.Object) continue;
                        var it = ReadItem(el, kind);
                        if (it != null) list.Add(it);
                    }
                }
                return list;
            });
        }

        private static string S(JsonElement v)
        {
            switch (v.ValueKind)
            {
                case JsonValueKind.String: return v.GetString() ?? "";
                case JsonValueKind.Number: return v.GetRawText();
                case JsonValueKind.True: return "true";
                case JsonValueKind.False: return "false";
                case JsonValueKind.Array:
                    foreach (var x in v.EnumerateArray())
                    {
                        string t = S(x);
                        if (!string.IsNullOrWhiteSpace(t)) return t;
                    }
                    return "";
                default: return "";
            }
        }

        private static Item ReadItem(JsonElement el, int kind)
        {
            int id = 0, num = 0;
            string name = "", title = "", icon = "", cat = "", ext = "", backdrop = "", year = "", epg = "";
            long added = 0;
            float rating = 0, rating5 = 0;
            foreach (var p in el.EnumerateObject())
            {
                switch (p.Name)
                {
                    case "stream_id":
                    case "series_id":
                        { int v = J.ToInt(S(p.Value)); if (v != 0) id = v; }
                        break;
                    case "name": name = S(p.Value); break;
                    case "title": title = S(p.Value); break;
                    case "stream_icon":
                    case "cover":
                    case "cover_big":
                    case "movie_image":
                    case "poster_path":
                    case "thumbnail":
                        { string v = S(p.Value); if (!string.IsNullOrWhiteSpace(v) && v != "null" && icon.Length == 0) icon = v; }
                        break;
                    case "category_id": cat = S(p.Value); break;
                    case "added":
                    case "last_modified":
                        { long v = J.ToLong(S(p.Value)); if (v > added) added = v; }
                        break;
                    case "rating": rating = J.ToFloat(S(p.Value)); break;
                    case "rating_5based": rating5 = J.ToFloat(S(p.Value)); break;
                    case "container_extension": ext = S(p.Value); break;
                    case "backdrop_path":
                    case "backdrop":
                    case "background":
                    case "fanart":
                        { string v = CleanBackdrop(S(p.Value)); if (v.Length > 0 && backdrop.Length == 0) backdrop = v; }
                        break;
                    case "year": year = TextUtil.Year(S(p.Value)); break;
                    case "releaseDate":
                    case "release_date":
                    case "releasedate":
                        { string v = TextUtil.Year(S(p.Value)); if (year.Length == 0) year = v; }
                        break;
                    case "num": num = J.ToInt(S(p.Value)); break;
                    case "epg_channel_id": epg = S(p.Value); break;
                }
            }
            if (name.Length == 0) name = title;
            if (id == 0 || string.IsNullOrWhiteSpace(name)) return null;
            if (rating <= 0 && rating5 > 0) rating = rating5 * 2f;
            var it = new Item
            {
                Kind = kind, Id = id, Name = name.Trim(), Icon = CleanPoster(icon), CatId = cat, Added = added,
                Rating = rating, Ext = ext, Backdrop = backdrop, Year = year, Num = num, EpgId = epg
            };
            it.Prepare();
            return it;
        }

        private static string Clean(string u)
        {
            string t = (u ?? "").Trim();
            if (t.StartsWith("https://", StringComparison.OrdinalIgnoreCase) || t.StartsWith("http://", StringComparison.OrdinalIgnoreCase)) return t;
            if (t.StartsWith("//")) return "https:" + t;
            return "";
        }

        public static string CleanPoster(string u)
        {
            string abs = Clean(u);
            if (abs.Length > 0) return abs;
            string rel = (u ?? "").Trim();
            return RelImg.IsMatch(rel) ? "https://image.tmdb.org/t/p/w500" + rel : "";
        }

        public static string CleanBackdrop(string u)
        {
            string abs = Clean(u);
            if (abs.Length > 0) return abs;
            string rel = (u ?? "").Trim();
            return RelImg.IsMatch(rel) ? "https://image.tmdb.org/t/p/w1280" + rel : "";
        }

        private static List<string> Strings(JsonNode v)
        {
            var list = new List<string>();
            if (v is JsonArray arr)
            {
                foreach (var x in arr)
                {
                    string c = CleanBackdrop(J.Text(x));
                    if (c.Length > 0) list.Add(c);
                }
            }
            else if (v != null)
            {
                string c = CleanBackdrop(J.Text(v));
                if (c.Length > 0) list.Add(c);
            }
            return list;
        }

        // ------------------------------------------------------------ información

        public static async Task<VodInfo> GetVodInfo(Account a, int id)
        {
            var o = J.Obj(await Net.GetString(Api(a, "get_vod_info", "&vod_id=" + id), 20000).ConfigureAwait(false)) ?? new JsonObject();
            var info = J.ObjOf(o, "info") ?? new JsonObject();
            var md = J.ObjOf(o, "movie_data") ?? new JsonObject();
            string name = J.Str(info, "name");
            if (name.Length == 0) name = J.Str(md, "name");
            string plot = J.Str(info, "plot");
            if (plot.Length == 0) plot = J.Str(info, "description");
            string cast = J.Str(info, "cast");
            if (cast.Length == 0) cast = J.Str(info, "actors");
            string poster = Clean(J.Str(info, "movie_image"));
            if (poster.Length == 0) poster = Clean(J.Str(info, "cover_big"));
            string released = J.Str(info, "releasedate");
            if (released.Length == 0) released = J.Str(info, "release_date");
            return new VodInfo
            {
                Id = id, Name = name, Plot = plot, Cast = cast, Director = J.Str(info, "director"), Genre = J.Str(info, "genre"),
                Released = released, Duration = J.Str(info, "duration"), DurationSecs = J.Int(info, "duration_secs"),
                Rating = J.Str(info, "rating"), Poster = poster, Backdrops = Strings(info["backdrop_path"]),
                Ext = J.Str(md, "container_extension")
            };
        }

        public static async Task<SeriesInfo> GetSeriesInfo(Account a, int id)
        {
            var o = J.Obj(await Net.GetString(Api(a, "get_series_info", "&series_id=" + id), 25000).ConfigureAwait(false)) ?? new JsonObject();
            var info = J.ObjOf(o, "info") ?? new JsonObject();
            string cover = Clean(J.Str(info, "cover"));
            var eps = new Dictionary<int, List<Episode>>();

            void AddEp(JsonNode e, int fallbackSeason)
            {
                var inf = J.ObjOf(e, "info") ?? new JsonObject();
                int season = J.Int(e, "season", J.Int(inf, "season", fallbackSeason));
                if (season == 0 && J.Str(e, "season").Length == 0 && J.Str(inf, "season").Length == 0) season = fallbackSeason;
                string img = Clean(J.Str(inf, "movie_image"));
                if (img.Length == 0) img = Clean(J.Str(inf, "cover_big"));
                string title = J.Str(e, "title");
                if (title.Length == 0) title = J.Str(inf, "name");
                var ep = new Episode
                {
                    Id = J.Str(e, "id"), Num = J.Int(e, "episode_num"), Season = season, Title = title,
                    Ext = J.Str(e, "container_extension"), Image = img, Plot = J.Str(inf, "plot"),
                    DurationSecs = J.Int(inf, "duration_secs"), Duration = J.Str(inf, "duration"), Rating = J.Str(inf, "rating")
                };
                if (ep.Id.Length == 0) return;
                List<Episode> list;
                if (!eps.TryGetValue(season, out list)) { list = new List<Episode>(); eps[season] = list; }
                list.Add(ep);
            }

            var episodes = o["episodes"];
            if (episodes is JsonObject eo)
            {
                foreach (var kv in eo)
                {
                    int sn = J.ToInt(kv.Key, 1);
                    if (kv.Value is JsonArray arr) foreach (var x in arr) if (x is JsonObject) AddEp(x, sn);
                }
            }
            else if (episodes is JsonArray ea)
            {
                for (int i = 0; i < ea.Count; i++)
                {
                    var x = ea[i];
                    if (x is JsonArray inner) { foreach (var y in inner) if (y is JsonObject) AddEp(y, i + 1); }
                    else if (x is JsonObject) AddEp(x, 1);
                }
            }
            foreach (var list in eps.Values) list.Sort((p, q) => p.Num.CompareTo(q.Num));

            var seasonMeta = new Dictionary<int, JsonNode>();
            if (o["seasons"] is JsonArray sa)
            {
                foreach (var s in sa)
                {
                    string n = J.Str(s, "season_number");
                    if (n.Length == 0) continue;
                    seasonMeta[J.ToInt(n)] = s;
                }
            }
            var numbers = eps.Keys.OrderBy(k => k).ToList();
            if (numbers.Count > 1 && numbers[0] == 0) { numbers.RemoveAt(0); numbers.Add(0); }
            var info2 = new SeriesInfo
            {
                Id = id, Name = J.Str(info, "name"), Plot = J.Str(info, "plot"), Cast = J.Str(info, "cast"),
                Director = J.Str(info, "director"), Genre = J.Str(info, "genre"),
                Released = J.Str(info, "releaseDate").Length > 0 ? J.Str(info, "releaseDate") : J.Str(info, "release_date"),
                Rating = J.Str(info, "rating"), Cover = cover, Backdrops = Strings(info["backdrop_path"]), Episodes = eps
            };
            foreach (int n in numbers)
            {
                JsonNode m;
                seasonMeta.TryGetValue(n, out m);
                string mc = Clean(J.Str(m, "cover_big"));
                if (mc.Length == 0) mc = Clean(J.Str(m, "cover"));
                string metaName = J.Str(m, "name");
                info2.Seasons.Add(new Season
                {
                    Number = n,
                    Name = n == 0 ? (metaName.Length > 0 ? metaName : "Especiales") : "Temporada " + n,
                    Cover = mc.Length > 0 ? mc : cover,
                    EpisodeCount = eps[n].Count
                });
            }
            return info2;
        }

        // -------------------------------------------------------------------- EPG

        private static string B64(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            try { return Encoding.UTF8.GetString(Convert.FromBase64String(s)); }
            catch { return s; }
        }

        public static async Task<List<EpgEntry>> ShortEpg(Account a, int streamId, int limit = 4)
        {
            var o = J.Obj(await Net.GetString(Api(a, "get_short_epg", "&stream_id=" + streamId + "&limit=" + limit), 12000).ConfigureAwait(false));
            var list = new List<EpgEntry>();
            var arr = J.ArrOf(o, "epg_listings");
            if (arr == null) return list;
            foreach (var e in arr)
            {
                long start = J.Long(e, "start_timestamp") * 1000;
                long end = J.Long(e, "stop_timestamp") * 1000;
                if (start <= 0) start = ParseUtc(J.Str(e, "start"));
                if (end <= 0) end = ParseUtc(J.Str(e, "end"));
                list.Add(new EpgEntry { Title = B64(J.Str(e, "title")).Trim(), Desc = B64(J.Str(e, "description")).Trim(), Start = start, End = end });
            }
            long now = J.NowMs();
            return list.Where(x => x.End == 0 || x.End > now).OrderBy(x => x.Start).ToList();
        }

        private static long ParseUtc(string s)
        {
            DateTime d;
            if (DateTime.TryParseExact(s, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture,
                    DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out d))
                return new DateTimeOffset(d, TimeSpan.Zero).ToUnixTimeMilliseconds();
            return 0;
        }
    }
}
