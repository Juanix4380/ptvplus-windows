using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;

namespace PTVPlus.Core
{
    /// <summary>Configuración guardada (settings.json). La contraseña y la sesión van cifradas.</summary>
    public sealed class Settings
    {
        // Cuenta (el servidor solo lo entrega Cloud; nunca se muestra en la app)
        public bool Logged { get; set; }
        public string Server { get; set; } = "";
        public string User { get; set; } = "";
        public string PassEnc { get; set; } = "";
        public string TokenEnc { get; set; } = "";
        public string AccountId { get; set; } = "";
        public string ProfileId { get; set; } = "0";
        public bool ProfileChosen { get; set; }
        public string DeviceId { get; set; } = "";
        public string Status { get; set; } = "";
        public long ExpDate { get; set; }
        public int MaxConnections { get; set; }

        // Reproducción
        /// <summary>0 normal, 1 alto (recomendado), 2 máximo.</summary>
        public int Buffer { get; set; } = 1;
        /// <summary>0 automático (tarjeta de video), 1 software.</summary>
        public int Decoder { get; set; }
        /// <summary>0 alta calidad, 1 rendimiento (PCs sencillas).</summary>
        public int Quality { get; set; }
        public string LiveFormat { get; set; } = "ts";
        public string AudioLang { get; set; } = "es";
        public string SubLang { get; set; } = "off";
        public int Volume { get; set; } = 100;
        public bool PlayerStats { get; set; }
        public bool AutoNext { get; set; } = true;

        // Ventana
        public bool KeepAwake { get; set; } = true;
        public bool StartFullscreen { get; set; }
        public bool ShowAdult { get; set; }

        // TV en vivo y multipantalla
        public int LastLiveId { get; set; }
        public string LastLiveCat { get; set; } = "";
        public int MultiCount { get; set; } = 4;
        public List<int> MultiIds { get; set; } = new List<int>();
    }

    public static class Prefs
    {
        public static Settings S { get; private set; } = new Settings();
        private static string _pass;
        private static string _token;
        private static Timer _saveTimer;
        private static readonly object Gate = new object();

        private static string FilePath => Paths.File("settings.json");

        public static void Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var loaded = JsonSerializer.Deserialize<Settings>(File.ReadAllText(FilePath));
                    if (loaded != null) S = loaded;
                }
            }
            catch (Exception e)
            {
                Log.Error(e, "Prefs.Load");
            }
            if (!IsDeviceId(S.DeviceId)) S.DeviceId = NewDeviceId();
            if (S.MultiIds == null) S.MultiIds = new List<int>();
            _pass = null;
            _token = null;
        }

        private static bool IsDeviceId(string id)
        {
            if (string.IsNullOrEmpty(id) || id.Length != 16) return false;
            foreach (char c in id) if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
            return true;
        }

        /// <summary>Identificador del equipo con el mismo formato que Android (16 hex), fijo para esta PC.</summary>
        private static string NewDeviceId()
        {
            string seed = "";
            try
            {
                using (var k = Microsoft.Win32.RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, Microsoft.Win32.RegistryView.Registry64))
                using (var c = k.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography"))
                    seed = c?.GetValue("MachineGuid") as string ?? "";
            }
            catch { }
            if (seed.Length == 0) seed = Guid.NewGuid().ToString("N");
            using (var sha = System.Security.Cryptography.SHA256.Create())
            {
                var h = sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes("ptvplus|" + seed));
                var sb = new System.Text.StringBuilder();
                for (int i = 0; i < 8; i++) sb.Append(h[i].ToString("x2"));
                return sb.ToString();
            }
        }

        /// <summary>Guarda en 1 s (junta varios cambios seguidos en una sola escritura).</summary>
        public static void Save()
        {
            lock (Gate)
            {
                if (_saveTimer == null) _saveTimer = new Timer(_ => SaveNow(), null, 1000, Timeout.Infinite);
                else _saveTimer.Change(1000, Timeout.Infinite);
            }
        }

        public static void SaveNow()
        {
            try
            {
                string json;
                lock (Gate) json = JsonSerializer.Serialize(S, new JsonSerializerOptions { WriteIndented = true });
                Paths.WriteAtomic(FilePath, json);
            }
            catch (Exception e)
            {
                Log.Error(e, "Prefs.Save");
            }
        }

        public static string Pass
        {
            get { return _pass ?? (_pass = Secret.Unprotect(S.PassEnc)); }
            set { _pass = value ?? ""; S.PassEnc = Secret.Protect(_pass); Save(); }
        }

        public static string Token
        {
            get { return _token ?? (_token = Secret.Unprotect(S.TokenEnc)); }
            set { _token = value ?? ""; S.TokenEnc = Secret.Protect(_token); Save(); }
        }

        public static bool CloudReady => S.Logged && !string.IsNullOrEmpty(Token) && !string.IsNullOrEmpty(S.AccountId);

        public static Account Account() => new Account(S.Server, S.User, Pass);

        public static void Logout()
        {
            S.Logged = false;
            S.Server = "";
            S.User = "";
            S.PassEnc = "";
            S.TokenEnc = "";
            S.AccountId = "";
            S.ProfileId = "0";
            S.ProfileChosen = false;
            _pass = "";
            _token = "";
            SaveNow();
        }
    }

    /// <summary>Cuentas guardadas para entrar con un clic (contraseña cifrada con Windows).</summary>
    public static class SavedAccounts
    {
        public sealed class Saved
        {
            public string User { get; set; } = "";
            public string PassEnc { get; set; } = "";
            public long ExpDate { get; set; }
            public long Time { get; set; }
        }

        private static string FilePath => Paths.File("accounts.json");

        public static List<Saved> List()
        {
            try
            {
                if (!File.Exists(FilePath)) return new List<Saved>();
                var list = JsonSerializer.Deserialize<List<Saved>>(File.ReadAllText(FilePath)) ?? new List<Saved>();
                return list.Where(a => !string.IsNullOrWhiteSpace(a.User)).OrderByDescending(a => a.Time).ToList();
            }
            catch
            {
                return new List<Saved>();
            }
        }

        public static void Save(string user, string pass, long exp)
        {
            var list = List().Where(a => !string.Equals(a.User, user, StringComparison.OrdinalIgnoreCase)).ToList();
            list.Insert(0, new Saved { User = user, PassEnc = Secret.Protect(pass), ExpDate = exp, Time = J.NowMs() });
            Write(list.Take(8).ToList());
        }

        public static void Remove(string user)
        {
            Write(List().Where(a => !string.Equals(a.User, user, StringComparison.OrdinalIgnoreCase)).ToList());
        }

        private static void Write(List<Saved> list)
        {
            try { Paths.WriteAtomic(FilePath, JsonSerializer.Serialize(list)); }
            catch (Exception e) { Log.Error(e, "SavedAccounts"); }
        }
    }
}
