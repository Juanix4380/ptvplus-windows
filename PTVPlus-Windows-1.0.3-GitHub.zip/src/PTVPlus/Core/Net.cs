using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace PTVPlus.Core
{
    /// <summary>
    /// Un solo cliente HTTP para toda la app: conexiones reutilizadas (catálogo, guía, imágenes y
    /// validación Cloud sin repetir el saludo TLS), descompresión y tiempos de espera cortos.
    /// </summary>
    public static class Net
    {
        /// <summary>El mismo agente que la app de Android (los servidores ya lo aceptan).</summary>
        public const string UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

        public static readonly HttpClient Client = Create();

        private static HttpClient Create()
        {
            var handler = new SocketsHttpHandler
            {
                AutomaticDecompression = DecompressionMethods.All,
                PooledConnectionLifetime = TimeSpan.FromMinutes(5),
                PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2),
                MaxConnectionsPerServer = 16,
                ConnectTimeout = TimeSpan.FromSeconds(10),
                AllowAutoRedirect = true,
                MaxAutomaticRedirections = 8,
                UseCookies = false
            };
            var c = new HttpClient(handler) { Timeout = Timeout.InfiniteTimeSpan };
            c.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", UA);
            c.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "*/*");
            return c;
        }

        public static async Task<string> GetString(string url, int timeoutMs = 20000, CancellationToken ct = default(CancellationToken))
        {
            using (var cts = CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                cts.CancelAfter(timeoutMs);
                using (var resp = await Client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cts.Token).ConfigureAwait(false))
                {
                    if (!resp.IsSuccessStatusCode) throw new IOException("HTTP " + (int)resp.StatusCode);
                    return await resp.Content.ReadAsStringAsync(cts.Token).ConfigureAwait(false);
                }
            }
        }

        public static async Task<byte[]> GetBytes(string url, int timeoutMs = 20000, CancellationToken ct = default(CancellationToken))
        {
            using (var cts = CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                cts.CancelAfter(timeoutMs);
                using (var resp = await Client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cts.Token).ConfigureAwait(false))
                {
                    if (!resp.IsSuccessStatusCode) throw new IOException("HTTP " + (int)resp.StatusCode);
                    return await resp.Content.ReadAsByteArrayAsync(cts.Token).ConfigureAwait(false);
                }
            }
        }

        /// <summary>Lee una respuesta grande por partes (listas del catálogo) sin cargarla dos veces.</summary>
        public static async Task<T> WithStream<T>(string url, int timeoutMs, Func<Stream, Task<T>> read)
        {
            using (var cts = new CancellationTokenSource(timeoutMs))
            using (var resp = await Client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cts.Token).ConfigureAwait(false))
            {
                if (!resp.IsSuccessStatusCode) throw new IOException("HTTP " + (int)resp.StatusCode);
                using (var s = await resp.Content.ReadAsStreamAsync(cts.Token).ConfigureAwait(false))
                    return await read(s).ConfigureAwait(false);
            }
        }
    }
}
