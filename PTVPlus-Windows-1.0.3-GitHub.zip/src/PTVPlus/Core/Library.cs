using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;

namespace PTVPlus.Core
{
    public sealed class FavEntry
    {
        public string Key { get; set; } = "";
        public int Kind { get; set; }
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Icon { get; set; } = "";
        public long Time { get; set; }
    }

    public sealed class LibraryData
    {
        public List<HistoryEntry> History { get; set; } = new List<HistoryEntry>();
        public List<FavEntry> Favorites { get; set; } = new List<FavEntry>();
        public List<int> RecentLive { get; set; } = new List<int>();
        public Dictionary<string, long> Removed { get; set; } = new Dictionary<string, long>();
        public Dictionary<string, long[]> EpProgress { get; set; } = new Dictionary<string, long[]>();
    }

    /// <summary>
    /// Historial (continuar viendo), Mi lista y canales recientes de cada perfil. Se guarda en la PC y
    /// en la cuenta Cloud (lo visto en el teléfono o la TV aparece aquí y al revés).
    /// </summary>
    public static class Library
    {
        private static readonly object Gate = new object();
        private static LibraryData _d = new LibraryData();
        private static string _acc = "";
        private static string _pid = "";
        private static Timer _saveTimer;
        public static int Version { get; private set; }
        public static event Action Changed;

        private static string FilePath(string acc, string pid) => Paths.File("lib_" + Paths.Hash(acc).Substring(0, 16) + "_" + pid + ".json");

        private static void Fire()
        {
            Version++;
            var h = Changed;
            if (h != null) UiThread.Post(() => h());
        }

        public static void Bind(string account, string profile)
        {
            lock (Gate)
            {
                if (_acc == account && _pid == profile) return;
                SaveNow();
                _acc = account ?? "";
                _pid = profile ?? "0";
                _d = new LibraryData();
                try
                {
                    string f = FilePath(_acc, _pid);
                    if (File.Exists(f)) _d = JsonSerializer.Deserialize<LibraryData>(File.ReadAllText(f)) ?? new LibraryData();
                }
                catch (Exception e) { Log.Error(e, "Library.Bind"); }
                if (_d.History == null) _d.History = new List<HistoryEntry>();
                if (_d.Favorites == null) _d.Favorites = new List<FavEntry>();
                if (_d.RecentLive == null) _d.RecentLive = new List<int>();
                if (_d.Removed == null) _d.Removed = new Dictionary<string, long>();
                if (_d.EpProgress == null) _d.EpProgress = new Dictionary<string, long[]>();
            }
            Fire();
        }

        private static void Save()
        {
            lock (Gate)
            {
                if (_saveTimer == null) _saveTimer = new Timer(_ => SaveNow(), null, 2000, Timeout.Infinite);
                else _saveTimer.Change(2000, Timeout.Infinite);
            }
        }

        public static void SaveNow()
        {
            string json, f;
            lock (Gate)
            {
                if (_acc.Length == 0) return;
                json = JsonSerializer.Serialize(_d);
                f = FilePath(_acc, _pid);
            }
            try { Paths.WriteAtomic(f, json); }
            catch (Exception e) { Log.Error(e, "Library.Save"); }
        }

        // ------------------------------------------------------------- historial

        /// <summary>Guarda el punto exacto (cada 10 s viendo, al pausar y al salir).</summary>
        public static HistoryEntry SaveProgress(HistoryEntry e)
        {
            if (e == null || e.Kind == Kind.Live) return null;
            lock (Gate)
            {
                e.Time = J.NowMs();
                _d.History.RemoveAll(x => x.Key == e.Key);
                _d.History.Insert(0, e);
                if (_d.History.Count > 80) _d.History.RemoveRange(80, _d.History.Count - 80);
                if (e.Kind == Kind.Episode) _d.EpProgress[e.Id] = new[] { e.Pos, e.Dur };
                if (_d.EpProgress.Count > 1500)
                    foreach (var k in _d.EpProgress.Keys.Take(_d.EpProgress.Count - 1500).ToList()) _d.EpProgress.Remove(k);
                _d.Removed.Remove(e.Key);
            }
            Save();
            Fire();
            HistorySync.Progress(e.Copy());
            return e;
        }

        public static List<HistoryEntry> ContinueWatching(int max = 30)
        {
            lock (Gate)
                return _d.History.Where(h => !h.Finished || h.Kind == Kind.Episode).OrderByDescending(h => h.Time).Take(max).Select(h => h.Copy()).ToList();
        }

        public static List<HistoryEntry> History()
        {
            lock (Gate) return _d.History.OrderByDescending(h => h.Time).Select(h => h.Copy()).ToList();
        }

        public static HistoryEntry Of(string key)
        {
            lock (Gate) return _d.History.FirstOrDefault(h => h.Key == key)?.Copy();
        }

        public static long[] EpisodeProgress(string episodeId)
        {
            lock (Gate)
            {
                long[] v;
                return _d.EpProgress.TryGetValue(episodeId ?? "", out v) ? v : null;
            }
        }

        public static void Remove(string key)
        {
            HistoryEntry removed;
            lock (Gate)
            {
                removed = _d.History.FirstOrDefault(h => h.Key == key);
                _d.History.RemoveAll(h => h.Key == key);
                _d.Removed[key] = J.NowMs();
            }
            Save();
            Fire();
            if (removed != null) HistorySync.Removed(removed.Copy());
        }

        // -------------------------------------------------------------- Mi lista

        public static bool IsFav(int kind, int id)
        {
            string k = kind + ":" + id;
            lock (Gate) return _d.Favorites.Any(f => f.Key == k);
        }

        public static bool ToggleFav(Item it)
        {
            bool on;
            lock (Gate)
            {
                on = !_d.Favorites.Any(f => f.Key == it.Key);
                if (on) _d.Favorites.Insert(0, new FavEntry { Key = it.Key, Kind = it.Kind, Id = it.Id, Name = it.Name, Icon = it.Icon, Time = J.NowMs() });
                else _d.Favorites.RemoveAll(f => f.Key == it.Key);
            }
            Save();
            Fire();
            HistorySync.Favorite(it.Kind, it.Id, on);
            return on;
        }

        public static List<FavEntry> Favorites()
        {
            lock (Gate) return _d.Favorites.ToList();
        }

        // ------------------------------------------------------- canales recientes

        public static void AddRecentLive(int id)
        {
            if (id <= 0) return;
            lock (Gate)
            {
                _d.RecentLive.Remove(id);
                _d.RecentLive.Insert(0, id);
                if (_d.RecentLive.Count > 30) _d.RecentLive.RemoveRange(30, _d.RecentLive.Count - 30);
            }
            Save();
            HistorySync.Live(id);
        }

        public static List<int> RecentLive()
        {
            lock (Gate) return _d.RecentLive.ToList();
        }

        // ------------------------------------------------------------ desde Cloud

        internal static long RemovalTime(string key)
        {
            lock (Gate)
            {
                long t;
                return _d.Removed.TryGetValue(key, out t) ? t : 0;
            }
        }

        internal static void MergeRemote(string acc, string pid, List<HistoryEntry> entries, List<FavEntry> favs, List<int> lives)
        {
            bool changed = false;
            lock (Gate)
            {
                if (acc != _acc || pid != _pid) return;
                foreach (var e in entries)
                {
                    var local = _d.History.FirstOrDefault(h => h.Key == e.Key);
                    if (local == null || e.Time > local.Time + 2000)
                    {
                        _d.History.RemoveAll(h => h.Key == e.Key);
                        _d.History.Add(e);
                        changed = true;
                    }
                    if (e.Kind == Kind.Episode && !string.IsNullOrEmpty(e.Id))
                    {
                        long[] p;
                        if (!_d.EpProgress.TryGetValue(e.Id, out p) || local == null || e.Time > local.Time)
                            _d.EpProgress[e.Id] = new[] { e.Pos, e.Dur };
                    }
                }
                _d.History = _d.History.OrderByDescending(h => h.Time).Take(80).ToList();
                if (favs != null)
                {
                    _d.Favorites = favs;
                    changed = true;
                }
                if (lives != null && lives.Count > 0)
                {
                    _d.RecentLive = lives.Distinct().Take(30).ToList();
                    changed = true;
                }
            }
            if (changed)
            {
                Save();
                Fire();
            }
        }
    }

    /// <summary>
    /// Historial, Mi lista y canales recientes en la CUENTA (mismos campos que la app de Android):
    /// historial_movie/series, item_movie_ID, favoritos_tv/movie/series y recientes_tv.
    /// Nunca se suben enlaces ni contraseñas.
    /// </summary>
    public static class HistorySync
    {
        private abstract class Change { }
        private sealed class ProgressChange : Change { public HistoryEntry E; }
        private sealed class RemoveChange : Change { public HistoryEntry E; }
        private sealed class FavChange : Change { public int Kind; public int Id; public bool On; }
        private sealed class LiveChange : Change { public int Id; }

        private static readonly object Gate = new object();
        private static readonly List<Change> Queue = new List<Change>();
        private static Timer _timer;
        private static readonly SemaphoreSlim Busy = new SemaphoreSlim(1, 1);

        private static string Uuid() => Profiles.Current()?.Uuid ?? "";

        public static void Progress(HistoryEntry e) => Add(new ProgressChange { E = e }, 30000);
        public static void Removed(HistoryEntry e) => Add(new RemoveChange { E = e }, 1500);
        public static void Favorite(int kind, int id, bool on) => Add(new FavChange { Kind = kind, Id = id, On = on }, 1500);
        public static void Live(int id) => Add(new LiveChange { Id = id }, 30000);

        private static void Add(Change c, int delayMs)
        {
            if (!Prefs.CloudReady || !Prefs.S.ProfileChosen) return;
            lock (Gate)
            {
                if (c is ProgressChange pc) Queue.RemoveAll(x => x is ProgressChange p && p.E.Key == pc.E.Key);
                if (c is FavChange fc) Queue.RemoveAll(x => x is FavChange f && f.Kind == fc.Kind && f.Id == fc.Id);
                if (c is LiveChange lc) Queue.RemoveAll(x => x is LiveChange l && l.Id == lc.Id);
                Queue.Add(c);
                if (_timer == null) _timer = new Timer(_ => { var t = FlushAsync(); }, null, delayMs, Timeout.Infinite);
                else _timer.Change(delayMs, Timeout.Infinite);
            }
        }

        /// <summary>Sube lo pendiente ya (al pausar, salir o cerrar).</summary>
        public static async Task FlushAsync()
        {
            List<Change> pending;
            lock (Gate)
            {
                if (Queue.Count == 0) return;
                pending = Queue.ToList();
            }
            string uuid = Uuid();
            if (uuid.Length == 0 || !Prefs.CloudReady) return;
            await Busy.WaitAsync().ConfigureAwait(false);
            try
            {
                await Cloud.Change(uuid, d => { foreach (var c in pending) Apply(d, c); }).ConfigureAwait(false);
                lock (Gate) foreach (var c in pending) Queue.Remove(c);
            }
            catch (Exception e)
            {
                Log.Error(e, "HistorySync.Flush");
            }
            finally
            {
                Busy.Release();
            }
        }

        private static List<string> Ids(JsonObject d, string key)
        {
            return J.Str(d, key).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(s => s.Trim()).Where(s => s.Length > 0).ToList();
        }

        private static void Apply(JsonObject d, Change c)
        {
            if (c is ProgressChange pc)
            {
                var e = pc.E;
                string type = e.Kind == Kind.Movie ? "movie" : "series";
                string id = type == "movie" ? e.Id : e.SeriesId.ToString(CultureInfo.InvariantCulture);
                if (string.IsNullOrEmpty(id) || id == "0") return;
                var old = J.Obj(J.Str(d, "item_" + type + "_" + id)) ?? new JsonObject();
                if (J.Long(old, "fecha") > e.Time) return;
                var ids = Ids(d, "historial_" + type).Where(x => x != id).ToList();
                ids.Insert(0, id);
                while (ids.Count > 50)
                {
                    d.Remove("item_" + type + "_" + ids[ids.Count - 1]);
                    ids.RemoveAt(ids.Count - 1);
                }
                var row = new JsonObject
                {
                    ["id"] = id,
                    ["titulo"] = e.Title,
                    ["posicion"] = e.Pos,
                    ["duracion"] = e.Dur,
                    ["episodio_id"] = type == "series" ? e.Id : "",
                    ["temporada"] = type == "series" ? e.Season : 0,
                    ["numero_episodio"] = type == "series" ? e.Episode : 0,
                    ["fecha"] = e.Time
                };
                d["historial_" + type] = string.Join(",", ids);
                d["item_" + type + "_" + id] = row.ToJsonString();
                d["ultimo_tipo"] = type;
                d["ultimo_id"] = id;
                d["ultimo_titulo"] = e.Title;
                d["ultimo_posicion"] = e.Pos;
                d["ultimo_duracion"] = e.Dur;
            }
            else if (c is RemoveChange rc)
            {
                string type = rc.E.Kind == Kind.Movie ? "movie" : "series";
                string id = type == "movie" ? rc.E.Id : rc.E.SeriesId.ToString(CultureInfo.InvariantCulture);
                d["historial_" + type] = string.Join(",", Ids(d, "historial_" + type).Where(x => x != id));
                d.Remove("item_" + type + "_" + id);
            }
            else if (c is FavChange fc)
            {
                string type = fc.Kind == Kind.Live ? "tv" : fc.Kind == Kind.Movie ? "movie" : "series";
                string key = "favoritos_" + type;
                var values = new List<string>();
                if (d[key] is JsonArray arr) foreach (var x in arr) values.Add(J.Text(x));
                else values = Ids(d, key);
                string sid = fc.Id.ToString(CultureInfo.InvariantCulture);
                values.RemoveAll(v => v == sid || v.Length == 0);
                if (fc.On) values.Add(sid);
                var outArr = new JsonArray();
                foreach (var v in values.Distinct()) outArr.Add(v);
                d[key] = outArr;
            }
            else if (c is LiveChange lc)
            {
                string sid = lc.Id.ToString(CultureInfo.InvariantCulture);
                var ids = Ids(d, "recientes_tv").Where(x => x != sid).ToList();
                ids.Insert(0, sid);
                d["recientes_tv"] = string.Join(",", ids.Take(30));
                d["ultimo_tv_id"] = sid;
                d["ultimo_tv_fecha"] = J.NowMs();
            }
        }

        /// <summary>Trae de la cuenta lo visto en otros equipos (al elegir perfil y cada minuto en Inicio).</summary>
        public static async Task PullAsync()
        {
            string uuid = Uuid();
            if (uuid.Length == 0 || !Prefs.CloudReady) return;
            string acc = Prefs.S.AccountId, pid = Prefs.S.ProfileId;
            try
            {
                var remote = await Cloud.Download(uuid).ConfigureAwait(false);
                var data = remote.Data;
                var snap = Catalog.Snap;
                var entries = new List<HistoryEntry>();
                foreach (var type in new[] { "movie", "series" })
                {
                    foreach (var id in Ids(data, "historial_" + type).Take(60))
                    {
                        var o = J.Obj(J.Str(data, "item_" + type + "_" + id));
                        if (o == null) continue;
                        int n = J.ToInt(id);
                        if (n <= 0) continue;
                        long date = J.Long(o, "fecha");
                        bool movie = type == "movie";
                        string key = movie ? "m:" + id : "s:" + id;
                        if (date <= Library.RemovalTime(key)) continue;
                        var item = snap?.Find(movie ? Kind.Movie : Kind.Series, n);
                        string epId = J.Str(o, "episodio_id");
                        if (epId.Length == 0) epId = id;
                        entries.Add(new HistoryEntry
                        {
                            Key = key,
                            Kind = movie ? Kind.Movie : Kind.Episode,
                            Id = movie ? id : epId,
                            SeriesId = movie ? 0 : n,
                            Season = J.Int(o, "temporada"),
                            Episode = J.Int(o, "numero_episodio"),
                            Title = item?.Name ?? J.Str(o, "titulo", "Contenido"),
                            Image = item != null ? (string.IsNullOrEmpty(item.Backdrop) ? item.Icon : item.Backdrop) : "",
                            Wide = item != null && !string.IsNullOrEmpty(item.Backdrop),
                            Ext = item?.Ext ?? "",
                            Pos = Math.Max(0, J.Long(o, "posicion")),
                            Dur = Math.Max(0, J.Long(o, "duracion")),
                            Time = date
                        });
                    }
                }
                List<FavEntry> favs = null;
                if (data.ContainsKey("favoritos_tv") || data.ContainsKey("favoritos_movie") || data.ContainsKey("favoritos_series"))
                {
                    favs = new List<FavEntry>();
                    var local = Library.Favorites().ToDictionary(f => f.Key, f => f);
                    foreach (var pair in new[] { Tuple.Create("tv", Kind.Live), Tuple.Create("movie", Kind.Movie), Tuple.Create("series", Kind.Series) })
                    {
                        var values = new List<string>();
                        if (data[pair.Item1 == "tv" ? "favoritos_tv" : "favoritos_" + pair.Item1] is JsonArray arr)
                            foreach (var x in arr) values.Add(J.Text(x));
                        else values = Ids(data, "favoritos_" + pair.Item1);
                        foreach (var v in values)
                        {
                            int fid = J.ToInt(v);
                            if (fid <= 0) continue;
                            string k = pair.Item2 + ":" + fid;
                            var it = snap?.Find(pair.Item2, fid);
                            FavEntry existing;
                            if (it != null) favs.Add(new FavEntry { Key = k, Kind = pair.Item2, Id = fid, Name = it.Name, Icon = it.Icon, Time = J.NowMs() });
                            else if (local.TryGetValue(k, out existing)) favs.Add(existing);
                        }
                    }
                    // Lo que se tocó aquí y aún no sube.
                    lock (Gate)
                    {
                        foreach (var c in Queue.OfType<FavChange>())
                        {
                            string k = c.Kind + ":" + c.Id;
                            favs.RemoveAll(f => f.Key == k);
                            if (c.On)
                            {
                                var it = snap?.Find(c.Kind, c.Id);
                                if (it != null) favs.Insert(0, new FavEntry { Key = k, Kind = c.Kind, Id = c.Id, Name = it.Name, Icon = it.Icon, Time = J.NowMs() });
                            }
                        }
                    }
                }
                var lives = Ids(data, "recientes_tv").Select(s => J.ToInt(s)).Where(i => i > 0).ToList();
                Library.MergeRemote(acc, pid, entries, favs, lives);
            }
            catch (Exception e)
            {
                Log.Error(e, "HistorySync.Pull");
            }
        }
    }
}
