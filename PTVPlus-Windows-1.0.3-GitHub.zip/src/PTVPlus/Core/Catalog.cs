using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using PTVPlus.Player;

namespace PTVPlus.Core
{
    /// <summary>Catálogo en memoria con índices por categoría y por id.</summary>
    public sealed class Snapshot
    {
        public List<Item> Live = new List<Item>();
        public List<Item> Movies = new List<Item>();
        public List<Item> Series = new List<Item>();
        public List<Category> LiveCats = new List<Category>();
        public List<Category> MovieCats = new List<Category>();
        public List<Category> SeriesCats = new List<Category>();

        private readonly Dictionary<int, Item>[] _byId = { new Dictionary<int, Item>(), new Dictionary<int, Item>(), new Dictionary<int, Item>() };
        private readonly Dictionary<string, List<Item>>[] _byCat = { new Dictionary<string, List<Item>>(), new Dictionary<string, List<Item>>(), new Dictionary<string, List<Item>>() };
        private readonly Dictionary<string, Category>[] _cat = { new Dictionary<string, Category>(), new Dictionary<string, Category>(), new Dictionary<string, Category>() };

        public List<Item> RecentMovies = new List<Item>();
        public List<Item> RecentSeries = new List<Item>();
        public List<Item> TopRated = new List<Item>();

        public bool IsEmpty => Live.Count == 0 && Movies.Count == 0 && Series.Count == 0;

        public List<Item> Items(int kind) => kind == Kind.Live ? Live : kind == Kind.Movie ? Movies : Series;
        public List<Category> Cats(int kind) => kind == Kind.Live ? LiveCats : kind == Kind.Movie ? MovieCats : SeriesCats;

        public void Index()
        {
            for (int k = 0; k < 3; k++)
            {
                _byId[k].Clear();
                _byCat[k].Clear();
                _cat[k].Clear();
                foreach (var c in Cats(k)) { c.Prepare(); _cat[k][c.Id] = c; }
                foreach (var it in Items(k))
                {
                    it.Prepare();
                    _byId[k][it.Id] = it;
                    List<Item> list;
                    if (!_byCat[k].TryGetValue(it.CatId ?? "", out list)) { list = new List<Item>(); _byCat[k][it.CatId ?? ""] = list; }
                    list.Add(it);
                }
            }
            // En vivo: por número de canal (si lo hay).
            foreach (var list in _byCat[Kind.Live].Values) list.Sort((a, b) => a.Num.CompareTo(b.Num));
            RecentMovies = Movies.Where(i => !IsAdultItem(i)).OrderByDescending(i => i.Added).Take(400).ToList();
            RecentSeries = Series.Where(i => !IsAdultItem(i)).OrderByDescending(i => i.Added).Take(400).ToList();
            TopRated = Movies.Concat(Series).Where(i => i.Rating >= 7.5f && i.Rating <= 10f && !string.IsNullOrEmpty(i.Icon) && !IsAdultItem(i))
                .OrderByDescending(i => i.Added).Take(200).ToList();
        }

        public Item Find(int kind, int id)
        {
            if (kind < 0 || kind > 2) return null;
            Item it;
            return _byId[kind].TryGetValue(id, out it) ? it : null;
        }

        public List<Item> ItemsOf(int kind, string catId)
        {
            List<Item> list;
            return _byCat[kind].TryGetValue(catId ?? "", out list) ? list : new List<Item>();
        }

        public Category CategoryOf(int kind, string id)
        {
            Category c;
            return _cat[kind].TryGetValue(id ?? "", out c) ? c : null;
        }

        public bool IsAdultItem(Item it)
        {
            var c = CategoryOf(it.Kind, it.CatId);
            return (c != null && c.Adult) || TextUtil.IsAdult(it.Norm);
        }
    }

    /// <summary>
    /// Catálogo: se abre del disco al instante y se actualiza por internet si tiene más de 8 h
    /// (esperando a que no se esté viendo nada, para no trabar el video).
    /// </summary>
    public static class Catalog
    {
        private const long MaxAgeMs = 8L * 3600_000L;
        public static Snapshot Snap { get; private set; }
        public static int Version { get; private set; }
        public static string Status { get; private set; } = "";
        public static string Error { get; private set; }
        public static bool Loading { get; private set; }
        public static event Action Changed;
        private static CancellationTokenSource _wait;

        private static string Dir()
        {
            return Paths.Dir("catalog_" + Paths.Hash(Prefs.S.Server + "|" + Prefs.S.User).Substring(0, 16));
        }

        private static void Fire()
        {
            var h = Changed;
            if (h != null) UiThread.Post(() => h());
        }

        public static void Clear()
        {
            Snap = null;
            Version++;
            Fire();
        }

        public static void Ensure()
        {
            if (Snap != null || Loading || !Prefs.S.Logged) return;
            Loading = true;
            Task.Run(async () =>
            {
                try
                {
                    Error = null;
                    string d = Dir();
                    var cached = ReadDisk(d);
                    if (cached != null && !cached.IsEmpty)
                    {
                        Publish(cached);
                        long age = J.NowMs() - ReadTime(d);
                        if (age > MaxAgeMs)
                        {
                            Loading = false;
                            _wait = new CancellationTokenSource();
                            var token = _wait.Token;
                            // No compite por internet con lo que se está viendo.
                            while (Playback.Busy && !token.IsCancellationRequested)
                                await Task.Delay(20000, token).ContinueWith(_ => { }).ConfigureAwait(false);
                            if (!token.IsCancellationRequested) await Download(d).ConfigureAwait(false);
                        }
                    }
                    else
                    {
                        await Download(d).ConfigureAwait(false);
                    }
                }
                catch (Exception e)
                {
                    Log.Error(e, "Catalog.Ensure");
                    if (Snap == null) Error = "No se pudo cargar el contenido. Revisa tu internet.";
                }
                finally
                {
                    Loading = false;
                    Status = "";
                    Fire();
                }
            });
        }

        /// <summary>Configuración > Actualizar catálogo.</summary>
        public static Task<bool> Refresh()
        {
            if (_wait != null) _wait.Cancel();
            if (Loading) return Task.FromResult(false);
            Loading = true;
            return Task.Run(async () =>
            {
                try { return await Download(Dir()).ConfigureAwait(false); }
                catch (Exception e) { Log.Error(e, "Catalog.Refresh"); return false; }
                finally { Loading = false; Status = ""; Fire(); }
            });
        }

        private static void Publish(Snapshot s)
        {
            Snap = s;
            Version++;
            Fire();
        }

        private static async Task<bool> Download(string d)
        {
            var a = Prefs.Account();
            Status = "Cargando canales, películas y series…";
            Fire();
            var liveC = Safe(Xtream.Categories(a, Kind.Live));
            var movieC = Safe(Xtream.Categories(a, Kind.Movie));
            var seriesC = Safe(Xtream.Categories(a, Kind.Series));
            var live = Safe(Xtream.Streams(a, Kind.Live));
            var movies = Safe(Xtream.Streams(a, Kind.Movie));
            var series = Safe(Xtream.Streams(a, Kind.Series));
            await Task.WhenAll(liveC, movieC, seriesC, live, movies, series).ConfigureAwait(false);
            if (live.Result == null && movies.Result == null && series.Result == null)
            {
                if (Snap == null) Error = "No se pudo cargar el contenido (sin conexión con el servidor).";
                return false;
            }
            var old = Snap;
            var s = new Snapshot
            {
                Live = live.Result ?? old?.Live ?? new List<Item>(),
                Movies = movies.Result ?? old?.Movies ?? new List<Item>(),
                Series = series.Result ?? old?.Series ?? new List<Item>(),
                LiveCats = NonEmpty(liveC.Result) ?? old?.LiveCats ?? new List<Category>(),
                MovieCats = NonEmpty(movieC.Result) ?? old?.MovieCats ?? new List<Category>(),
                SeriesCats = NonEmpty(seriesC.Result) ?? old?.SeriesCats ?? new List<Category>()
            };
            s.Index();
            Publish(s);
            try { WriteDisk(d, s); } catch (Exception e) { Log.Error(e, "Catalog.WriteDisk"); }
            return true;
        }

        private static List<Category> NonEmpty(List<Category> l) => l != null && l.Count > 0 ? l : null;

        private static async Task<T> Safe<T>(Task<T> t) where T : class
        {
            try { return await t.ConfigureAwait(false); }
            catch (Exception e) { Log.Error(e, "Catalog.Download"); return null; }
        }

        // ----------------------------------------------------------------- disco

        public sealed class Disk
        {
            public List<Category> LiveCats { get; set; }
            public List<Category> MovieCats { get; set; }
            public List<Category> SeriesCats { get; set; }
        }

        private static void WriteDisk(string d, Snapshot s)
        {
            Paths.WriteAtomic(Path.Combine(d, "cats.json"), JsonSerializer.Serialize(new Disk { LiveCats = s.LiveCats, MovieCats = s.MovieCats, SeriesCats = s.SeriesCats }));
            Paths.WriteAtomic(Path.Combine(d, "live.json"), JsonSerializer.Serialize(s.Live));
            Paths.WriteAtomic(Path.Combine(d, "movies.json"), JsonSerializer.Serialize(s.Movies));
            Paths.WriteAtomic(Path.Combine(d, "series.json"), JsonSerializer.Serialize(s.Series));
            Paths.WriteAtomic(Path.Combine(d, "time.txt"), J.NowMs().ToString(CultureInfo.InvariantCulture));
        }

        private static long ReadTime(string d)
        {
            try { return J.ToLong(File.ReadAllText(Path.Combine(d, "time.txt")).Trim()); }
            catch { return 0; }
        }

        private static Snapshot ReadDisk(string d)
        {
            try
            {
                if (!File.Exists(Path.Combine(d, "time.txt"))) return null;
                var cats = JsonSerializer.Deserialize<Disk>(File.ReadAllText(Path.Combine(d, "cats.json")));
                var t1 = Task.Run(() => Load(Path.Combine(d, "live.json")));
                var t2 = Task.Run(() => Load(Path.Combine(d, "movies.json")));
                var t3 = Task.Run(() => Load(Path.Combine(d, "series.json")));
                Task.WaitAll(t1, t2, t3);
                var s = new Snapshot
                {
                    Live = t1.Result, Movies = t2.Result, Series = t3.Result,
                    LiveCats = cats?.LiveCats ?? new List<Category>(),
                    MovieCats = cats?.MovieCats ?? new List<Category>(),
                    SeriesCats = cats?.SeriesCats ?? new List<Category>()
                };
                s.Index();
                return s;
            }
            catch (Exception e)
            {
                Log.Error(e, "Catalog.ReadDisk");
                return null;
            }
        }

        private static List<Item> Load(string f)
        {
            if (!File.Exists(f)) return new List<Item>();
            using (var fs = File.OpenRead(f))
                return JsonSerializer.Deserialize<List<Item>>(fs) ?? new List<Item>();
        }
    }
}
