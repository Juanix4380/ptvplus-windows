using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace PTVPlus.Core
{
    public static class Kind
    {
        public const int Live = 0;
        public const int Movie = 1;
        public const int Series = 2;
        public const int Episode = 3;
    }

    public sealed class Account
    {
        public string Server { get; }
        public string User { get; }
        public string Pass { get; }

        public Account(string server, string user, string pass)
        {
            Server = server ?? "";
            User = user ?? "";
            Pass = pass ?? "";
        }
    }

    public sealed class UserInfo
    {
        public string Username { get; set; } = "";
        public string Status { get; set; } = "";
        public long ExpDate { get; set; }
        public int MaxConnections { get; set; }
        public int ActiveCons { get; set; }
        public bool Trial { get; set; }
    }

    public sealed class Category
    {
        public string Id { get; set; } = "";
        public string Name { get; set; } = "";
        public int Kind { get; set; }
        [JsonIgnore] public string Norm { get; private set; } = "";
        [JsonIgnore] public bool Adult { get; private set; }

        public void Prepare()
        {
            Norm = TextUtil.Norm(Name);
            Adult = TextUtil.IsAdult(Norm);
        }
    }

    public sealed class Item
    {
        public int Kind { get; set; }
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Icon { get; set; } = "";
        public string CatId { get; set; } = "";
        public long Added { get; set; }
        public float Rating { get; set; }
        public string Ext { get; set; } = "";
        public string Backdrop { get; set; } = "";
        public string Year { get; set; } = "";
        public int Num { get; set; }
        public string EpgId { get; set; } = "";

        [JsonIgnore] public string Norm { get; private set; } = "";
        [JsonIgnore] public string Key => Kind + ":" + Id;
        [JsonIgnore] public string Title => TextUtil.DisplayTitle(Name);
        [JsonIgnore] public string YearOrName => string.IsNullOrEmpty(Year) ? TextUtil.Year(Name) : Year;
        [JsonIgnore] public string NumText => Num > 0 ? Num.ToString(CultureInfo.InvariantCulture) : "";
        [JsonIgnore] public string RatingText => Rating > 0 ? "★ " + Rating.ToString("0.0", CultureInfo.InvariantCulture) : "";

        public void Prepare() { Norm = TextUtil.Norm(Name); }
    }

    public sealed class Episode
    {
        public string Id = "";
        public int Num;
        public int Season;
        public string Title = "";
        public string Ext = "";
        public string Image = "";
        public string Plot = "";
        public int DurationSecs;
        public string Duration = "";
        public string Rating = "";
    }

    public sealed class Season
    {
        public int Number;
        public string Name = "";
        public string Cover = "";
        public int EpisodeCount;
    }

    public sealed class SeriesInfo
    {
        public int Id;
        public string Name = "";
        public string Plot = "";
        public string Cast = "";
        public string Director = "";
        public string Genre = "";
        public string Released = "";
        public string Rating = "";
        public string Cover = "";
        public List<string> Backdrops = new List<string>();
        public List<Season> Seasons = new List<Season>();
        public Dictionary<int, List<Episode>> Episodes = new Dictionary<int, List<Episode>>();

        public Episode FindEpisode(string id)
        {
            foreach (var list in Episodes.Values)
                foreach (var e in list)
                    if (e.Id == id) return e;
            return null;
        }

        /// <summary>Todos los episodios en orden (temporada 0 / especiales al final).</summary>
        public List<Episode> Ordered()
        {
            var keys = Episodes.Keys.OrderBy(k => k == 0 ? int.MaxValue : k).ToList();
            var all = new List<Episode>();
            foreach (int k in keys) all.AddRange(Episodes[k]);
            return all;
        }
    }

    public sealed class VodInfo
    {
        public int Id;
        public string Name = "";
        public string Plot = "";
        public string Cast = "";
        public string Director = "";
        public string Genre = "";
        public string Released = "";
        public string Duration = "";
        public int DurationSecs;
        public string Rating = "";
        public string Poster = "";
        public List<string> Backdrops = new List<string>();
        public string Ext = "";
    }

    public sealed class EpgEntry
    {
        public string Title = "";
        public string Desc = "";
        public long Start;
        public long End;

        public double Progress(long now)
        {
            if (End <= Start || now < Start) return 0;
            return Math.Min(1.0, (now - Start) / (double)(End - Start));
        }

        public string Hours => TextUtil.Clock(Start) + " – " + TextUtil.Clock(End);
    }

    public sealed class HistoryEntry
    {
        public string Key { get; set; } = "";
        public int Kind { get; set; }
        public string Id { get; set; } = "";
        public int SeriesId { get; set; }
        public int Season { get; set; }
        public int Episode { get; set; }
        public string Title { get; set; } = "";
        public string Subtitle { get; set; } = "";
        public string Image { get; set; } = "";
        public bool Wide { get; set; }
        public string Ext { get; set; } = "";
        public long Pos { get; set; }
        public long Dur { get; set; }
        public long Time { get; set; }

        [JsonIgnore] public int Percent => Dur > 0 ? (int)Math.Max(0, Math.Min(100, Pos * 100 / Dur)) : 0;
        [JsonIgnore] public bool Finished => Dur > 0 && Pos >= Dur - 60_000;

        public HistoryEntry Copy() => (HistoryEntry)MemberwiseClone();
    }

    public sealed class Profile
    {
        public string Id { get; set; } = "0";
        public string Name { get; set; } = "";
        public bool Kids { get; set; }
        public string Pin { get; set; } = "";
        public int Avatar { get; set; }
        public string Uuid { get; set; } = "";

        [JsonIgnore] public int Index => J.ToInt(Id, 0);
        [JsonIgnore] public string DisplayName => string.IsNullOrWhiteSpace(Name) ? "Perfil " + (Index + 1) : Name;
        [JsonIgnore] public bool HasPin => !string.IsNullOrWhiteSpace(Pin);
    }

    /// <summary>Texto: normalizar para buscar, años, títulos limpios y horas.</summary>
    public static class TextUtil
    {
        private static readonly Regex YearRx = new Regex("(19[2-9]\\d|20[0-4]\\d)", RegexOptions.Compiled);
        private static readonly Regex PrefixRx = new Regex("^[A-Za-z]{2,3}\\s*[-:|]\\s+", RegexOptions.Compiled);
        private static readonly Regex YearTailRx = new Regex("\\s*\\((19|20)\\d{2}\\)\\s*$", RegexOptions.Compiled);
        private static readonly Regex BracketRx = new Regex("\\[[^\\]]*\\]", RegexOptions.Compiled);
        private static readonly Regex SpacesRx = new Regex("\\s+", RegexOptions.Compiled);
        private static readonly string[] AdultWords = { "adult", "xxx", "+18", "18+", "porn", "erotic", "hentai", "playboy", "for adults" };

        public static string Norm(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            bool ascii = true;
            foreach (char c in s) if (c >= 128) { ascii = false; break; }
            string lower = s.ToLowerInvariant();
            if (ascii) return lower;
            string d = lower.Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder(d.Length);
            foreach (char c in d)
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
            return sb.ToString().Normalize(NormalizationForm.FormC);
        }

        public static bool IsAdult(string norm)
        {
            foreach (var w in AdultWords) if (norm.Contains(w)) return true;
            return false;
        }

        public static string Year(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            var m = YearRx.Match(s);
            return m.Success ? m.Value : "";
        }

        /// <summary>Quita prefijos de idioma ("ES - ", "LAT | ") y etiquetas [4K] para mostrar.</summary>
        public static string DisplayTitle(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "";
            string t = PrefixRx.Replace(s.Trim(), "");
            t = BracketRx.Replace(t, " ");
            t = SpacesRx.Replace(t, " ").Trim();
            return t.Length == 0 ? s.Trim() : t;
        }

        public static string WithoutYear(string s) => YearTailRx.Replace(s ?? "", "");

        public static string Clock(long ms)
        {
            if (ms <= 0) return "--:--";
            return DateTimeOffset.FromUnixTimeMilliseconds(ms).ToLocalTime().ToString("h:mm tt", new CultureInfo("es-MX"));
        }

        public static string Time(double secs)
        {
            if (double.IsNaN(secs) || secs < 0) secs = 0;
            var t = TimeSpan.FromSeconds(secs);
            return t.TotalHours >= 1
                ? ((int)t.TotalHours).ToString(CultureInfo.InvariantCulture) + ":" + t.Minutes.ToString("00") + ":" + t.Seconds.ToString("00")
                : t.Minutes.ToString("0") + ":" + t.Seconds.ToString("00");
        }

        public static string Minutes(int totalMin)
        {
            if (totalMin <= 0) return "";
            int h = totalMin / 60, m = totalMin % 60;
            return h > 0 ? h + " h " + m + " min" : m + " min";
        }

        public static string Initials(string name)
        {
            var parts = (name ?? "").Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) return "?";
            if (parts.Length == 1) return parts[0].Substring(0, 1).ToUpperInvariant();
            return (parts[0].Substring(0, 1) + parts[1].Substring(0, 1)).ToUpperInvariant();
        }

        public static string ExpText(long exp)
        {
            if (exp <= 0) return "Sin vencimiento";
            var d = DateTimeOffset.FromUnixTimeSeconds(exp).ToLocalTime();
            return d.ToString("d 'de' MMMM yyyy", new CultureInfo("es-MX"));
        }
    }
}
