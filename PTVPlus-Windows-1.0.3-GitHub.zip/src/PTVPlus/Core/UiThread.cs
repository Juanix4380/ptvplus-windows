using System;
using System.Windows;
using System.Windows.Threading;

namespace PTVPlus.Core
{
    /// <summary>Pasar trabajo al hilo de la interfaz desde cualquier hilo.</summary>
    public static class UiThread
    {
        public static Dispatcher D => Application.Current?.Dispatcher;

        public static void Post(Action a)
        {
            var d = D;
            if (d == null || d.HasShutdownStarted) return;
            d.BeginInvoke(DispatcherPriority.Normal, new Action(() =>
            {
                try { a(); }
                catch (Exception e) { Log.Error(e, "UiThread.Post"); }
            }));
        }

        public static DispatcherTimer Every(int ms, Action tick)
        {
            var t = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(ms) };
            t.Tick += (s, e) =>
            {
                try { tick(); }
                catch (Exception ex) { Log.Error(ex, "Timer"); }
            };
            t.Start();
            return t;
        }

        public static DispatcherTimer After(int ms, Action run)
        {
            var t = new DispatcherTimer(DispatcherPriority.Normal) { Interval = TimeSpan.FromMilliseconds(ms) };
            t.Tick += (s, e) =>
            {
                t.Stop();
                try { run(); }
                catch (Exception ex) { Log.Error(ex, "After"); }
            };
            t.Start();
            return t;
        }
    }
}
