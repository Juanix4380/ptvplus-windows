using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using PTVPlus.Core;

namespace PTVPlus
{
    public static class Program
    {
        private const string MutexName = "PTVPlus.Windows.Single";
        private const string ShowEventName = "PTVPlus.Windows.Show";

        [STAThread]
        public static void Main(string[] args)
        {
            // Una sola ventana: si ya está abierta, se trae al frente en vez de abrir otra.
            bool first;
            using (var mutex = new Mutex(true, MutexName, out first))
            {
                if (!first)
                {
                    try
                    {
                        using (var ev = EventWaitHandle.OpenExisting(ShowEventName)) ev.Set();
                    }
                    catch { }
                    return;
                }
                using (var show = new EventWaitHandle(false, EventResetMode.AutoReset, ShowEventName))
                {
                    Log.Init();
                    AppDomain.CurrentDomain.UnhandledException += (s, e) => Log.Error(e.ExceptionObject as Exception, "AppDomain");
                    System.Threading.Tasks.TaskScheduler.UnobservedTaskException += (s, e) =>
                    {
                        Log.Error(e.Exception, "Task");
                        e.SetObserved();
                    };
                    Prefs.Load();
                    Power.Apply();

                    var app = new App();
                    app.InitializeComponent();
                    app.DispatcherUnhandledException += OnUiError;
                    var win = new MainWindow();
                    var waiter = new Thread(() =>
                    {
                        try
                        {
                            while (show.WaitOne())
                                win.Dispatcher.BeginInvoke(new Action(win.BringToFront));
                        }
                        catch { }
                    })
                    { IsBackground = true, Name = "single-instance" };
                    waiter.Start();
                    app.Run(win);
                    Power.Release();
                    Prefs.SaveNow();
                }
                GC.KeepAlive(mutex);
            }
        }

        private static void OnUiError(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            // Un error en una pantalla no cierra la app: se registra y se sigue.
            Log.Error(e.Exception, "UI");
            e.Handled = true;
        }
    }
}
