using System.Windows;

namespace PTVPlus
{
    public partial class App : Application
    {
    }
}
