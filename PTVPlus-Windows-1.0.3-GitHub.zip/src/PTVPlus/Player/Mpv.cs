using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using PTVPlus.Core;

namespace PTVPlus.Player
{
    /// <summary>API de libmpv (libmpv-2.dll).</summary>
    internal static class MpvNative
    {
        public const string Lib = "libmpv-2.dll";

        public const int FormatNone = 0;
        public const int FormatString = 1;
        public const int FormatFlag = 3;
        public const int FormatInt64 = 4;
        public const int FormatDouble = 5;

        public const int EventShutdown = 1;
        public const int EventStartFile = 6;
        public const int EventEndFile = 7;
        public const int EventFileLoaded = 8;
        public const int EventVideoReconfig = 17;
        public const int EventPlaybackRestart = 21;
        public const int EventPropertyChange = 22;

        public const int EndEof = 0;
        public const int EndStop = 2;
        public const int EndQuit = 3;
        public const int EndError = 4;

        [StructLayout(LayoutKind.Sequential)]
        public struct Event
        {
            public int event_id;
            public int error;
            public ulong reply_userdata;
            public IntPtr data;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct EventProperty
        {
            public IntPtr name;
            public int format;
            public IntPtr data;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct EndFileData
        {
            public int reason;
            public int error;
        }

        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern IntPtr mpv_create();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern int mpv_initialize(IntPtr ctx);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern void mpv_terminate_destroy(IntPtr ctx);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern int mpv_set_option_string(IntPtr ctx, byte[] name, byte[] data);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern int mpv_set_property_string(IntPtr ctx, byte[] name, byte[] data);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern IntPtr mpv_get_property_string(IntPtr ctx, byte[] name);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern int mpv_command(IntPtr ctx, IntPtr[] args);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern int mpv_command_async(IntPtr ctx, ulong reply_userdata, IntPtr[] args);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern void mpv_free(IntPtr data);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern IntPtr mpv_wait_event(IntPtr ctx, double timeout);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern void mpv_wakeup(IntPtr ctx);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern int mpv_observe_property(IntPtr ctx, ulong reply, byte[] name, int format);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] public static extern IntPtr mpv_error_string(int error);

        public static byte[] U8(string s) => Encoding.UTF8.GetBytes((s ?? "") + "\0");

        private static bool _resolver;

        /// <summary>Busca libmpv-2.dll junto al .exe (o donde el .exe único lo extrae).</summary>
        public static void InstallResolver()
        {
            if (_resolver) return;
            _resolver = true;
            try
            {
                NativeLibrary.SetDllImportResolver(typeof(MpvNative).Assembly, (name, asm, path) =>
                {
                    if (!string.Equals(name, Lib, StringComparison.OrdinalIgnoreCase)) return IntPtr.Zero;
                    foreach (var dir in new[] { AppContext.BaseDirectory, Path.GetDirectoryName(Environment.ProcessPath ?? "") ?? "" })
                    {
                        if (string.IsNullOrEmpty(dir)) continue;
                        string f = Path.Combine(dir, Lib);
                        IntPtr h;
                        if (File.Exists(f) && NativeLibrary.TryLoad(f, out h)) return h;
                    }
                    return IntPtr.Zero;
                });
            }
            catch (Exception e)
            {
                Log.Error(e, "mpv resolver");
            }
        }
    }

    public sealed class MpvTrack
    {
        public string Id = "";
        public string Type = "";
        public string Lang = "";
        public string Title = "";
        public string Codec = "";
        public bool Selected;

        public string Label
        {
            get
            {
                var parts = new List<string>();
                if (Title.Length > 0) parts.Add(Title);
                if (Lang.Length > 0) parts.Add(LangName(Lang));
                if (Codec.Length > 0 && Type == "audio") parts.Add(Codec.ToUpperInvariant());
                return parts.Count == 0 ? "Pista " + Id : string.Join(" · ", parts);
            }
        }

        private static string LangName(string l)
        {
            switch (l.ToLowerInvariant())
            {
                case "es": case "spa": case "esp": return "Español";
                case "lat": return "Español latino";
                case "en": case "eng": return "Inglés";
                case "pt": case "por": return "Portugués";
                case "fr": case "fre": case "fra": return "Francés";
                case "it": case "ita": return "Italiano";
                case "de": case "ger": case "deu": return "Alemán";
                case "ja": case "jpn": return "Japonés";
                default: return l;
            }
        }
    }

    /// <summary>
    /// Un reproductor mpv dibujando en una ventana (HWND). Decodifica con la tarjeta de video,
    /// junta búfer según la configuración y se reconecta solo a cortes del servidor.
    /// </summary>
    public sealed class MpvPlayer : IDisposable
    {
        private IntPtr _ctx;
        private Thread _loop;
        private volatile bool _alive;
        private readonly object _gate = new object();

        public double Position { get; private set; }
        public double Duration { get; private set; }
        public double CacheSecs { get; private set; }
        public bool Paused { get; private set; }
        public bool Buffering { get; private set; }
        public bool CoreIdle { get; private set; } = true;
        public bool Seeking { get; private set; }
        public bool HasVideo { get; private set; }
        public bool Disposed => !_alive;

        /// <summary>Llegan en el hilo de mpv: quien escuche debe pasar a la interfaz.</summary>
        public event Action FileLoaded;
        public event Action PlaybackRestart;
        public event Action<int, int> EndFile;
        public event Action StateChanged;

        public static bool Available
        {
            get
            {
                try
                {
                    MpvNative.InstallResolver();
                    IntPtr h = MpvNative.mpv_create();
                    if (h == IntPtr.Zero) return false;
                    MpvNative.mpv_terminate_destroy(h);
                    return true;
                }
                catch (Exception e)
                {
                    Log.Error(e, "mpv no disponible");
                    return false;
                }
            }
        }

        /// <param name="light">Ventanas de multipantalla: menos búfer y escalado rápido.</param>
        public static MpvPlayer Create(IntPtr hwnd, bool light = false)
        {
            MpvNative.InstallResolver();
            var p = new MpvPlayer();
            p._ctx = MpvNative.mpv_create();
            if (p._ctx == IntPtr.Zero) throw new InvalidOperationException("No se pudo iniciar el motor de video");
            p.Configure(hwnd, light);
            int r = MpvNative.mpv_initialize(p._ctx);
            if (r < 0) throw new InvalidOperationException("mpv: " + Error(r));
            foreach (var prop in new[] { "pause", "paused-for-cache", "core-idle", "seeking" })
                MpvNative.mpv_observe_property(p._ctx, 0, MpvNative.U8(prop), MpvNative.FormatFlag);
            foreach (var prop in new[] { "time-pos", "duration", "demuxer-cache-duration" })
                MpvNative.mpv_observe_property(p._ctx, 0, MpvNative.U8(prop), MpvNative.FormatDouble);
            p._alive = true;
            p._loop = new Thread(p.Loop) { IsBackground = true, Name = "mpv-events" };
            p._loop.Start();
            return p;
        }

        private static string Error(int code)
        {
            try { return Marshal.PtrToStringUTF8(MpvNative.mpv_error_string(code)) ?? code.ToString(CultureInfo.InvariantCulture); }
            catch { return code.ToString(CultureInfo.InvariantCulture); }
        }

        private void Opt(string k, string v)
        {
            int r = MpvNative.mpv_set_option_string(_ctx, MpvNative.U8(k), MpvNative.U8(v));
            if (r < 0) Log.Write("mpv opción " + k + "=" + v + ": " + Error(r));
        }

        private void Configure(IntPtr hwnd, bool light)
        {
            var s = Prefs.S;
            Opt("wid", hwnd.ToInt64().ToString(CultureInfo.InvariantCulture));
            Opt("config", "no");
            Opt("terminal", "no");
            Opt("msg-level", "all=error");
            Opt("load-scripts", "no");
            Opt("ytdl", "no");
            Opt("osc", "no");
            Opt("osd-level", "0");
            Opt("input-default-bindings", "no");
            Opt("input-vo-keyboard", "no");
            Opt("input-cursor", "no");
            Opt("cursor-autohide", "no");
            Opt("idle", "yes");
            Opt("force-window", "yes");
            Opt("keep-open", "no");
            Opt("keepaspect", "yes");
            Opt("stop-screensaver", "yes");
            // Video: tarjeta de video (D3D11) y decodificación por hardware.
            Opt("vo", "gpu-next,gpu");
            Opt("gpu-api", "d3d11");
            Opt("hwdec", s.Decoder == 1 ? "no" : "auto-safe");
            Opt("hwdec-codecs", "all");
            if (s.Quality == 1 || light) Opt("profile", "fast");
            // Red: el mismo agente que Android, reconexión automática del flujo y tiempo límite.
            Opt("user-agent", Net.UA);
            Opt("network-timeout", "15");
            Opt("stream-lavf-o", "reconnect=1,reconnect_streamed=1,reconnect_on_network_error=1,reconnect_delay_max=4");
            // Arranque rápido de canales: no analizar de más el flujo.
            Opt("demuxer-lavf-analyzeduration", "1.5");
            Opt("demuxer-lavf-probesize", "1500000");
            Opt("hls-bitrate", "max");
            // Búfer según Configuración (Normal / Alto / Máximo).
            Opt("cache", "yes");
            int b = light ? 0 : s.Buffer;
            switch (b)
            {
                case 0:
                    Opt("demuxer-readahead-secs", "12");
                    Opt("demuxer-max-bytes", "96MiB");
                    Opt("cache-pause-wait", "1.5");
                    Opt("cache-pause-initial", "no");
                    break;
                case 2:
                    Opt("demuxer-readahead-secs", "90");
                    Opt("demuxer-max-bytes", "512MiB");
                    Opt("cache-pause-wait", "6");
                    Opt("cache-pause-initial", "yes");
                    break;
                default:
                    Opt("demuxer-readahead-secs", "30");
                    Opt("demuxer-max-bytes", "256MiB");
                    Opt("cache-pause-wait", "3");
                    Opt("cache-pause-initial", "yes");
                    break;
            }
            Opt("demuxer-max-back-bytes", light ? "16MiB" : "64MiB");
            // Audio y subtítulos preferidos.
            string al = s.AudioLang == "en" ? "en,eng" : s.AudioLang == "es" ? "es,spa,lat,esp,es-419,es-MX" : "";
            if (al.Length > 0) Opt("alang", al);
            if (s.SubLang == "off") Opt("sid", "no");
            else Opt("slang", s.SubLang == "en" ? "en,eng" : "es,spa,lat,esp");
            Opt("sub-auto", "no");
            Opt("audio-file-auto", "no");
            Opt("volume-max", "150");
            Opt("volume", Math.Max(0, Math.Min(100, s.Volume)).ToString(CultureInfo.InvariantCulture));
            Opt("audio-pitch-correction", "yes");
        }

        /// <summary>Aplica al momento lo cambiado en Configuración (búfer, decodificador, idiomas).</summary>
        public void Reapply()
        {
            var s = Prefs.S;
            Set("hwdec", s.Decoder == 1 ? "no" : "auto-safe");
            switch (s.Buffer)
            {
                case 0:
                    Set("demuxer-readahead-secs", "12");
                    Set("demuxer-max-bytes", "96MiB");
                    Set("cache-pause-wait", "1.5");
                    Set("cache-pause-initial", "no");
                    break;
                case 2:
                    Set("demuxer-readahead-secs", "90");
                    Set("demuxer-max-bytes", "512MiB");
                    Set("cache-pause-wait", "6");
                    Set("cache-pause-initial", "yes");
                    break;
                default:
                    Set("demuxer-readahead-secs", "30");
                    Set("demuxer-max-bytes", "256MiB");
                    Set("cache-pause-wait", "3");
                    Set("cache-pause-initial", "yes");
                    break;
            }
            string al = s.AudioLang == "en" ? "en,eng" : s.AudioLang == "es" ? "es,spa,lat,esp,es-419,es-MX" : "";
            Set("alang", al);
            if (s.SubLang == "off") Set("sid", "no");
            else
            {
                Set("slang", s.SubLang == "en" ? "en,eng" : "es,spa,lat,esp");
                Set("sid", "auto");
            }
        }

        // ------------------------------------------------------------ comandos

        public void Command(params string[] args)
        {
            if (!_alive) return;
            var ptrs = new IntPtr[args.Length + 1];
            try
            {
                for (int i = 0; i < args.Length; i++) ptrs[i] = Marshal.StringToCoTaskMemUTF8(args[i] ?? "");
                ptrs[args.Length] = IntPtr.Zero;
                // mpv_command es sincrónico: al cambiar canal podía congelar WPF.
                // La variante async devuelve enseguida y mpv ejecuta el cambio.
                int r = MpvNative.mpv_command_async(_ctx, 0, ptrs);
                if (r < 0 && args.Length > 0 && args[0] != "stop") Log.Write("mpv " + args[0] + ": " + Error(r));
            }
            finally
            {
                for (int i = 0; i < args.Length; i++) if (ptrs[i] != IntPtr.Zero) Marshal.FreeCoTaskMem(ptrs[i]);
            }
        }

        public void Set(string prop, string value)
        {
            if (!_alive) return;
            MpvNative.mpv_set_property_string(_ctx, MpvNative.U8(prop), MpvNative.U8(value));
        }

        public string Get(string prop)
        {
            if (!_alive) return "";
            IntPtr p = MpvNative.mpv_get_property_string(_ctx, MpvNative.U8(prop));
            if (p == IntPtr.Zero) return "";
            try { return Marshal.PtrToStringUTF8(p) ?? ""; }
            finally { MpvNative.mpv_free(p); }
        }

        public double GetDouble(string prop)
        {
            double d;
            return double.TryParse(Get(prop), NumberStyles.Float, CultureInfo.InvariantCulture, out d) ? d : 0;
        }

        /// <summary>Abre el enlace; películas y episodios desde el segundo indicado.</summary>
        public void Load(string url, double startSecs = 0)
        {
            Position = 0;
            Duration = 0;
            CacheSecs = 0;
            HasVideo = false;
            Set("start", startSecs > 1 ? "+" + startSecs.ToString("0.###", CultureInfo.InvariantCulture) : "none");
            Set("pause", "no");
            Command("loadfile", url, "replace");
        }

        public void Stop() => Command("stop");
        public void SetPause(bool p) => Set("pause", p ? "yes" : "no");
        public void TogglePause() => Command("cycle", "pause");
        public void SeekRelative(double secs) => Command("seek", secs.ToString("0.###", CultureInfo.InvariantCulture), "relative");
        public void SeekAbsolute(double secs) => Command("seek", Math.Max(0, secs).ToString("0.###", CultureInfo.InvariantCulture), "absolute");
        public void SetVolume(int v) => Set("volume", Math.Max(0, Math.Min(150, v)).ToString(CultureInfo.InvariantCulture));
        public void SetMute(bool m) => Set("mute", m ? "yes" : "no");
        public bool Muted => Get("mute") == "yes";
        public void SetAspect(string a) => Set("video-aspect-override", a);
        public void SetPanscan(double v) => Set("panscan", v.ToString("0.##", CultureInfo.InvariantCulture));

        public List<MpvTrack> Tracks(string type)
        {
            var list = new List<MpvTrack>();
            int n = (int)GetDouble("track-list/count");
            for (int i = 0; i < n; i++)
            {
                string t = Get("track-list/" + i + "/type");
                if (t != type) continue;
                list.Add(new MpvTrack
                {
                    Id = Get("track-list/" + i + "/id"),
                    Type = t,
                    Lang = Get("track-list/" + i + "/lang"),
                    Title = Get("track-list/" + i + "/title"),
                    Codec = Get("track-list/" + i + "/codec"),
                    Selected = Get("track-list/" + i + "/selected") == "yes"
                });
            }
            return list;
        }

        /// <summary>Datos de reproducción (Configuración): búfer, video, audio y cuadros perdidos.</summary>
        public string Stats()
        {
            var sb = new StringBuilder();
            sb.Append("Búfer ").Append(CacheSecs.ToString("0.0", CultureInfo.InvariantCulture)).Append(" s");
            double speed = GetDouble("cache-speed");
            if (speed > 0) sb.Append("  ·  Internet ").Append((speed * 8 / 1_000_000).ToString("0.0", CultureInfo.InvariantCulture)).Append(" Mb/s");
            sb.AppendLine();
            string w = Get("video-params/w"), h = Get("video-params/h");
            if (w.Length > 0)
            {
                sb.Append("Video ").Append(w).Append("×").Append(h);
                double fps = GetDouble("container-fps");
                if (fps > 0) sb.Append("  ·  ").Append(fps.ToString("0.##", CultureInfo.InvariantCulture)).Append(" fps");
                string vc = Get("video-codec-name");
                if (vc.Length == 0) vc = Get("video-format");
                if (vc.Length > 0) sb.Append("  ·  ").Append(vc.ToUpperInvariant());
                double br = GetDouble("video-bitrate");
                if (br > 0) sb.Append("  ·  ").Append((br / 1_000_000).ToString("0.0", CultureInfo.InvariantCulture)).Append(" Mb/s");
                sb.AppendLine();
            }
            string ac = Get("audio-codec-name");
            if (ac.Length > 0) sb.Append("Audio ").Append(ac.ToUpperInvariant()).Append("  ·  ").Append(Get("audio-params/channel-count")).AppendLine(" canales");
            string hw = Get("hwdec-current");
            sb.Append("Decodificador ").Append(hw.Length == 0 || hw == "no" ? "software" : "tarjeta de video (" + hw + ")").AppendLine();
            sb.Append("Cuadros perdidos ").Append(Get("frame-drop-count")).Append("  ·  Retrasados ").Append(Get("decoder-frame-drop-count"));
            return sb.ToString();
        }

        // -------------------------------------------------------------- eventos

        private void Loop()
        {
            while (_alive)
            {
                IntPtr evPtr;
                try { evPtr = MpvNative.mpv_wait_event(_ctx, 0.5); }
                catch { break; }
                if (!_alive || evPtr == IntPtr.Zero) continue;
                var ev = Marshal.PtrToStructure<MpvNative.Event>(evPtr);
                try
                {
                    switch (ev.event_id)
                    {
                        case MpvNative.EventShutdown:
                            _alive = false;
                            break;
                        case MpvNative.EventFileLoaded:
                            FileLoaded?.Invoke();
                            break;
                        case MpvNative.EventPlaybackRestart:
                            PlaybackRestart?.Invoke();
                            break;
                        case MpvNative.EventVideoReconfig:
                            HasVideo = true;
                            break;
                        case MpvNative.EventEndFile:
                            if (ev.data != IntPtr.Zero)
                            {
                                var ef = Marshal.PtrToStructure<MpvNative.EndFileData>(ev.data);
                                EndFile?.Invoke(ef.reason, ef.error);
                            }
                            break;
                        case MpvNative.EventPropertyChange:
                            if (ev.data != IntPtr.Zero) OnProperty(Marshal.PtrToStructure<MpvNative.EventProperty>(ev.data));
                            break;
                    }
                }
                catch (Exception e)
                {
                    Log.Error(e, "mpv evento");
                }
            }
        }

        private void OnProperty(MpvNative.EventProperty p)
        {
            string name = Marshal.PtrToStringUTF8(p.name) ?? "";
            bool flag = false;
            double num = 0;
            bool has = p.data != IntPtr.Zero && p.format != MpvNative.FormatNone;
            if (has && p.format == MpvNative.FormatFlag) flag = Marshal.ReadInt32(p.data) != 0;
            if (has && p.format == MpvNative.FormatDouble)
            {
                var buf = new double[1];
                Marshal.Copy(p.data, buf, 0, 1);
                num = buf[0];
            }
            switch (name)
            {
                case "pause": Paused = flag; break;
                case "paused-for-cache": Buffering = flag; break;
                case "core-idle": CoreIdle = !has || flag; break;
                case "seeking": Seeking = flag; break;
                case "time-pos": Position = has ? num : 0; return;
                case "duration": Duration = has ? num : 0; return;
                case "demuxer-cache-duration": CacheSecs = has ? num : 0; return;
            }
            StateChanged?.Invoke();
        }

        public void Dispose()
        {
            if (_ctx == IntPtr.Zero) return;
            _alive = false;
            try { MpvNative.mpv_wakeup(_ctx); } catch { }
            try { _loop?.Join(1500); } catch { }
            try { MpvNative.mpv_terminate_destroy(_ctx); } catch (Exception e) { Log.Error(e, "mpv destroy"); }
            _ctx = IntPtr.Zero;
        }
    }
}
