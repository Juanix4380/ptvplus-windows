# Pruebas para PTV Plus 1.0.3 en Windows

- [ ] GitHub Actions terminó en verde y contiene PTVPlus.exe.
- [ ] Login con usuario y contraseña válidos.
- [ ] Verificación Cloud responde: no aparece cuadro modal al fallar red. En `log.txt` se registra tipo de error.
- [ ] TV en vivo: guía a la izquierda, preview a la derecha; controles no se montan.
- [ ] TV pantalla ampliada: botón Atrás superior izquierdo siempre disponible; Esc regresa.
- [ ] TV: nombre del canal largo no invade otra categoría ni los botones.
- [ ] Películas y series: controles al borde inferior en 1920x1080 y 1280x720, con escala Windows 100%, 125% y 150%.
- [ ] Multipantalla: 2/3/4 mosaicos y nombres dentro de sus marcos.
- [ ] Navegación nunca lanza una ventana de reproductor externa.
- [ ] Cuenta vencida/bloqueada o servidor eliminado sigue siendo denegado.
