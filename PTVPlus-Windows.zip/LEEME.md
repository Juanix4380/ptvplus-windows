# PTV PLUS para Windows 1.0 (modo TV)

App de escritorio para Windows 10/11 de 64 bits. Es un solo `PTVPlus.exe`, sin instalador y sin tener que instalar .NET. Se maneja con el control remoto, el teclado o el mouse, y todo pasa en **una sola ventana**.

## Compilar en GitHub (sin PC)

1. En el repositorio, ve a **Add file → Upload files**. Sube `PTVPlus-Windows.zip` tal cual, sin descomprimir, y luego **Commit changes**.
2. Ve a **Add file → Create new file**. En el nombre escribe `.github/workflows/build.yml`, pega el texto del flujo y luego **Commit changes**.
3. Abre la pestaña **Actions**. La compilación tarda entre 6 y 10 minutos.
4. Ve a **Releases** y descarga `PTVPlus.exe`.

Si ya subiste la app antes, haz lo mismo: sube el zip nuevo con el mismo nombre y GitHub vuelve a compilar solo. También puedes compilar a mano con **Actions → Compilar PTV PLUS Windows → Run workflow**.

## Qué trae

**Interfaz**
- La misma app de TV que en Android:
  - Inicio con vista previa en vivo, carrusel destacado y accesos rápidos.
  - Películas, Series, Anime, Niños, Especial, Multi, Eventos y Mi lista.
- Perfiles con PIN, perfil de niños y avatares, sincronizados con Cloud. Funcionan igual que en Android.
- Continuar viendo, favoritos y canales recientes. Se comparten con la app de Android por Cloud.

**Reproducción**
- Motor de video mpv (libmpv) con decodificación por hardware D3D11 y paso automático a software si el video falla.
- Búfer por niveles para que no se trabe.
- Reconexión automática y cambio de formato (`.ts` ↔ `.m3u8`) cuando un canal falla.
- Vigilancia de congelamientos.

**TV en vivo**
- Guía EPG ahora y siguiente.
- Cambio de canal con las flechas o escribiendo el número.
- Panel de categorías con buscador.

**Multipantalla**
- 2, 3 o 4 canales a la vez.
- El audio se escucha del cuadro activo.

**Reproductor**
- Barra de tiempo.
- Adelantar y retroceder 10 s.
- Siguiente episodio automático.
- Audio, subtítulos y formato de pantalla.
- Datos de reproducción.

**Ventana y equipo**
- Pantalla completa con F11 o F.
- La pantalla no se apaga mientras ves algo.
- Si abres la app otra vez, se trae al frente la que ya estaba abierta.

## Seguridad

- Cada reproducción, cambio de canal y reanudación se valida en Cloud. Si Cloud no autoriza, no se reproduce.
- El servidor nunca se muestra en la app: solo lo entrega Cloud al iniciar sesión.
- La contraseña y el token se guardan cifrados con DPAPI de Windows en `%LocalAppData%\PTVPlus`.
- En Cloud el equipo aparece como `Windows - <nombre del PC>` con tipo `windows`. Si el panel todavía no acepta ese tipo, la app entra como los otros equipos.

## Teclas

| Tecla | Acción |
|---|---|
| Flechas / Enter | Moverse / abrir |
| Esc o Retroceso | Atrás |
| F11 o F | Pantalla completa |
| M | Silencio |
| Espacio | Pausa |
| J / L | −10 s / +10 s |
| N | Siguiente episodio |
| F2 (TV en vivo) | Favorito |
| Números (TV en vivo) | Ir al canal |

## Si algo falla

- **La compilación falla:** abre **Actions**, entra a la ejecución en rojo, abre el paso que falló y manda una captura del error.
- **La app falla:** el registro está en `%LocalAppData%\PTVPlus\log.txt`.
