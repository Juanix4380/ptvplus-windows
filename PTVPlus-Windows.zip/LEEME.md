# PTV PLUS para Windows 1.0 (modo TV)

App de escritorio para Windows 10/11 de 64 bits. Es un solo `PTVPlus.exe`, sin instalador y sin tener que instalar .NET. Se maneja con el control remoto, el teclado o el mouse, y todo pasa en **una sola ventana**.

## Compilar en GitHub (sin PC)

1. En el repositorio, ve a **Add file → Upload files**. Sube `PTVPlus-Windows.zip` tal cual, sin descomprimir, y luego **Commit changes**.
2. Ve a **Add file → Create new file**. En el nombre escribe `.github/workflows/build.yml`, pega el texto del flujo y luego **Commit changes**.
3. Abre la pestaña **Actions**. La compilación tarda entre 6 y 10 minutos.
4. Ve a **Releases** y descarga `PTVPlus.exe`.

Si ya subiste la app antes, haz lo mismo: sube el zip nuevo con el mismo nombre y GitHub vuelve a compilar solo. También puedes compilar a mano con **Actions → Compilar PTV PLUS Windows → Run workflow**.

## Qué trae

**Interfaz**
- La misma app de TV que en Android:
  - Inicio con vista previa en vivo, carrusel destacado y accesos rápidos.
  - Películas, Series, Anime, Niños, Especial, Multi, Eventos y Mi lista.
- Perfiles con PIN, perfil de niños y avatares, sincronizados con Cloud. Funcionan igual que en Android.
- Continuar viendo, favoritos y canales recientes. Se comparten con la app de Android por Cloud.

**Reproducción**
- Motor de video mpv (libmpv) con decodificación por hardware D3D11 y paso automático a software si el video falla.
- Búfer por niveles para que no se trabe.
- Reconexión automática y cambio de formato (`.ts` ↔ `.m3u8`) cuando un canal falla.
- Vigilancia de congelamientos.

**TV en vivo**
- Guía EPG ahora y siguiente.
- Cambio de canal con las flechas o escribiendo el número.
- Panel de categorías con buscador.

**Multipantalla**
- 2, 3 o 4 canales a la vez.
- El audio se escucha del cuadro activo.

**Reproductor**
- Barra de tiempo.
- Adelantar y retroceder 10 s.
- Siguiente episodio automático.
- Audio, subtítulos y formato de pantalla.
- Datos de reproducción.

**Ventana y equipo**
- Pantalla completa con F11 o F.
- La pantalla no se apaga mientras ves algo.
- Si abres la app otra vez, se trae al frente la que ya estaba abierta.

## Seguridad

- Cada reproducción, cambio de canal y reanudación se valida en Cloud. Si Cloud no autoriza, no se reproduce.
- El servidor nunca se muestra en la app: solo lo entrega Cloud al iniciar sesión.
- La contraseña y el token se guardan cifrados con DPAPI de Windows en `%LocalAppData%\PTVPlus`.
- En Cloud el equipo se registra igual que la app de Android, con el nombre `Windows <nombre del PC>` y un identificador fijo para esa PC.
- Si el inicio de sesión falla, el mensaje indica el motivo y el código. El detalle queda en `%LocalAppData%\PTVPlus\log.txt`.

## Controles del reproductor

TV en vivo y películas/series tienen los mismos controles que la app de Android. Un clic en el video los muestra y otro los quita; también aparecen al mover el mouse o al pulsar Enter, y se ocultan solos a los 5 segundos. La pausa y la pantalla completa van solo en sus botones (sin doble clic).

- **Arriba:** regresar, inicio, canal o título, hora, Mis canales (en vivo) y sonido.
- **Al centro:**
  - En vivo: canal anterior, pausa y canal siguiente.
  - Películas y series: −10 s, pausa y +10 s.
- **Abajo, en vivo:** EN VIVO con la guía (ahora y después), Canales, Multipantalla, Audio, Formato de pantalla y Pantalla completa.
- **Abajo, películas y series:** barra de avance, Episodios (lista por temporada con lo visto y lo que falta), Siguiente episodio, Audio, Subtítulos, Formato de pantalla y Pantalla completa.
- **Multipantalla:** la ventana 1 empieza con el canal que estabas viendo y las demás vacías para elegir (clic → buscador por nombre o número). Se escucha la ventana elegida. Cada ventana tiene botones para cambiar canal y verla en grande. Muestra solo las pantallas que permite tu cuenta (conexiones a la vez).
- **Eventos (igual que Android):** los partidos del día de ESPN (Liga MX, Champions, NFL, NBA, MLB, NHL, UFC y más) junto con TODOS los "A vs B" del panel, solo los que tienen canal. Por partido, por liga o por región, con días antes y después y actualización cada minuto. Al entrar a un partido: video arriba con el canal, los canales que lo pasan, marcador e incidencias.
- **Pantalla completa sincronizada:** la vista previa del inicio, el video de un partido y las ventanas de multipantalla se agrandan con el mismo reproductor, sin cortes ni recarga.
- **Inicio:** solo la parte grande de arriba (vista previa en vivo grande con canal, guía y sonido, destacado e información) y los accesos. Lo que estabas viendo está en **Recién visto** dentro de Películas y Series.

## Teclas

| Tecla | TV en vivo | Películas y series |
|---|---|---|
| Enter | Mostrar controles | Mostrar controles |
| ▲ / ▼ | Canal anterior / siguiente | Volumen / controles |
| ◄ / ► | Lista de categorías / canales | −10 s / +10 s |
| Flechas con controles abiertos | Moverse entre botones | Moverse entre botones |
| Espacio | Pausa | Pausa |
| Esc o Retroceso | Ocultar controles / salir | Ocultar controles / salir |
| M · + · − · rueda del mouse | Silencio · volumen | Silencio · volumen |
| F o F11 | Pantalla completa | Pantalla completa |
| F2 | Mis canales | — |
| Números | Ir al canal | — |
| J / L / N | — | −10 s / +30 s / siguiente episodio |

## Si algo falla

- **La compilación falla:** abre **Actions**, entra a la ejecución en rojo, abre el paso que falló y manda una captura del error.
- **La app falla:** el registro está en `%LocalAppData%\PTVPlus\log.txt`.
