using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace PTVPlus.Core
{
    // =====================================================================================
    // Eventos deportivos, igual que la app de Android: partidos de ESPN del día + TODOS los
    // canales "A vs B" del panel; solo se muestran los partidos que tienen canal.
    // =====================================================================================

    public sealed class League
    {
        public string Slug, Sport, Name, Region;
        public League(string slug, string sport, string name, string region) { Slug = slug; Sport = sport; Name = name; Region = region; }
    }

    public sealed class Team
    {
        public string Id = "", Name = "", Short = "", Logo = "", Score = "";
        public Team() { }
        public Team(string id, string name, string shrt, string logo, string score) { Id = id ?? ""; Name = name ?? ""; Short = shrt ?? ""; Logo = logo ?? ""; Score = score ?? ""; }
    }

    public sealed class Match
    {
        public string Id = "";
        public League League;
        public string LeagueLogo = "";
        public long Start;
        /// <summary>"pre", "in" o "post".</summary>
        public string State = "pre";
        public string Detail = "";
        public string Clock = "";
        public Team Home = new Team();
        public Team Away = new Team();
        /// <summary>Cadenas que reporta ESPN (ESPN, TUDN, MSG…).</summary>
        public List<string> Tv = new List<string>();
        /// <summary>true = partido que solo tiene el panel.</summary>
        public bool Panel;
        /// <summary>Canales del panel que pasan este partido.</summary>
        public List<Item> Channels = new List<Item>();
        public long End;

        public bool Live => State == "in";
        public bool Finished => State == "post";

        public Match WithChannels(List<Item> chans)
        {
            var m = (Match)MemberwiseClone();
            m.Channels = chans ?? new List<Item>();
            return m;
        }
    }

    public sealed class KeyEvent
    {
        public string Minute = "", Text = "", Kind = "other";
        public bool Home;
    }

    /// <summary>Selecciones en español para mostrar y en inglés para buscar (y viceversa).</summary>
    public static class Selecciones
    {
        private static readonly string[] Pairs =
        {
            "Mexico", "México", "Canada", "Canadá", "United States", "Estados Unidos", "USA", "Estados Unidos",
            "Spain", "España", "Germany", "Alemania", "France", "Francia", "England", "Inglaterra",
            "Italy", "Italia", "Brazil", "Brasil", "Netherlands", "Países Bajos", "Belgium", "Bélgica",
            "Switzerland", "Suiza", "Croatia", "Croacia", "Japan", "Japón", "South Korea", "Corea del Sur",
            "Korea Republic", "Corea del Sur", "North Korea", "Corea del Norte", "Peru", "Perú", "Panama", "Panamá",
            "Haiti", "Haití", "Trinidad and Tobago", "Trinidad y Tobago", "Morocco", "Marruecos", "Egypt", "Egipto",
            "Cameroon", "Camerún", "South Africa", "Sudáfrica", "Turkey", "Turquía", "Türkiye", "Turquía",
            "Greece", "Grecia", "Scotland", "Escocia", "Wales", "Gales", "Republic of Ireland", "Irlanda",
            "Ireland", "Irlanda", "Northern Ireland", "Irlanda del Norte", "Denmark", "Dinamarca", "Sweden", "Suecia",
            "Norway", "Noruega", "Poland", "Polonia", "Ukraine", "Ucrania", "Russia", "Rusia", "Hungary", "Hungría",
            "Romania", "Rumania", "Czechia", "Chequia", "Czech Republic", "Chequia", "Slovakia", "Eslovaquia",
            "Slovenia", "Eslovenia", "Finland", "Finlandia", "Iceland", "Islandia", "Saudi Arabia", "Arabia Saudita",
            "Qatar", "Catar", "Iran", "Irán", "IR Iran", "Irán", "Iraq", "Irak", "New Zealand", "Nueva Zelanda",
            "Tunisia", "Túnez", "Algeria", "Argelia", "Ivory Coast", "Costa de Marfil", "Côte d'Ivoire", "Costa de Marfil",
            "Dominican Republic", "República Dominicana", "Suriname", "Surinam", "Curacao", "Curazao", "Curaçao", "Curazao",
            "Bosnia-Herzegovina", "Bosnia", "Bosnia and Herzegovina", "Bosnia", "North Macedonia", "Macedonia del Norte",
            "Azerbaijan", "Azerbaiyán", "Kazakhstan", "Kazajistán", "Lithuania", "Lituania", "Latvia", "Letonia",
            "Belarus", "Bielorrusia", "Luxembourg", "Luxemburgo", "Cyprus", "Chipre", "Uzbekistan", "Uzbekistán",
            "United Arab Emirates", "Emiratos Árabes Unidos", "Jordan", "Jordania", "Bahrain", "Baréin", "Oman", "Omán",
            "Syria", "Siria", "Lebanon", "Líbano", "Thailand", "Tailandia", "Philippines", "Filipinas",
            "Cape Verde", "Cabo Verde", "Cape Verde Islands", "Cabo Verde", "DR Congo", "RD Congo",
            "Equatorial Guinea", "Guinea Ecuatorial", "Gabon", "Gabón", "Benin", "Benín", "Kenya", "Kenia",
            "Ethiopia", "Etiopía", "Sudan", "Sudán", "Libya", "Libia", "Zimbabwe", "Zimbabue",
            "St. Kitts and Nevis", "San Cristóbal y Nieves", "St Kitts and Nevis", "San Cristóbal y Nieves",
            "St. Lucia", "Santa Lucía", "St Lucia", "Santa Lucía", "St. Vincent and the Grenadines", "San Vicente y las Granadinas",
            "Grenada", "Granada", "Bermuda", "Bermudas", "Antigua and Barbuda", "Antigua y Barbuda",
            "Guadeloupe", "Guadalupe", "Martinique", "Martinica", "French Guiana", "Guayana Francesa"
        };

        private static readonly Dictionary<string, string> ByEnglish = new Dictionary<string, string>();
        private static readonly Dictionary<string, string> BySpanish = new Dictionary<string, string>();

        static Selecciones()
        {
            for (int i = 0; i + 1 < Pairs.Length; i += 2)
            {
                string en = Pairs[i], es = Pairs[i + 1];
                ByEnglish[Plain(en)] = es;
                if (!BySpanish.ContainsKey(Plain(es))) BySpanish[Plain(es)] = en;
            }
            BySpanish["eeuu"] = "United States"; BySpanish["ee uu"] = "United States"; BySpanish["usa"] = "United States";
            BySpanish["holanda"] = "Netherlands"; BySpanish["arabia saudi"] = "Saudi Arabia"; BySpanish["qatar"] = "Qatar";
            BySpanish["republica checa"] = "Czech Republic"; BySpanish["corea"] = "South Korea"; BySpanish["bosnia herzegovina"] = "Bosnia-Herzegovina";
            BySpanish["rumania"] = "Romania"; BySpanish["guayana"] = "Guyana";
        }

        public static string Plain(string s) =>
            Regex.Replace(Regex.Replace(TextUtil.Norm(s ?? ""), "[^a-z0-9 ]", " "), "\\s+", " ").Trim();

        public static string Es(string name) { string v; return ByEnglish.TryGetValue(Plain(name), out v) ? v : name; }
        public static string En(string name) { string v; return BySpanish.TryGetValue(Plain(name), out v) ? v : name; }

        public static List<string> Codes(string name)
        {
            switch (Plain(En(name)))
            {
                case "united states": case "usa": return new List<string> { "usa", "eeuu", "ee uu" };
                case "united arab emirates": return new List<string> { "uae", "eau" };
                case "dr congo": return new List<string> { "rd congo", "rdc" };
                default: return new List<string>();
            }
        }

        public static List<string> Variants(string name) =>
            new[] { name, Es(name), En(name) }.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToList();
    }

    /// <summary>Marcadores y calendario desde la API pública de ESPN.</summary>
    public static class Sports
    {
        public static readonly List<League> Leagues = new List<League>
        {
            new League("mex.1", "soccer", "Liga MX", "México"),
            new League("mex.2", "soccer", "Liga de Expansión MX", "México"),
            new League("concacaf.champions", "soccer", "Concacaf Champions Cup", "Norteamérica"),
            new League("usa.1", "soccer", "MLS", "Norteamérica"),
            new League("uefa.champions", "soccer", "UEFA Champions League", "Europa"),
            new League("uefa.wchampions", "soccer", "UEFA Champions League Women", "Europa"),
            new League("uefa.europa", "soccer", "UEFA Europa League", "Europa"),
            new League("uefa.europa.conf", "soccer", "UEFA Conference League", "Europa"),
            new League("eng.1", "soccer", "Premier League", "Europa"),
            new League("esp.1", "soccer", "LaLiga", "Europa"),
            new League("ita.1", "soccer", "Serie A", "Europa"),
            new League("ger.1", "soccer", "Bundesliga", "Europa"),
            new League("fra.1", "soccer", "Ligue 1", "Europa"),
            new League("por.1", "soccer", "Liga Portugal", "Europa"),
            new League("conmebol.libertadores", "soccer", "Copa Libertadores", "Sudamérica"),
            new League("conmebol.sudamericana", "soccer", "Copa Sudamericana", "Sudamérica"),
            new League("arg.1", "soccer", "Liga Profesional Argentina", "Sudamérica"),
            new League("bra.1", "soccer", "Brasileirão", "Sudamérica"),
            new League("col.1", "soccer", "Liga BetPlay", "Sudamérica"),
            new League("bol.1", "soccer", "Copa de la División Profesional", "Sudamérica"),
            new League("fifa.friendly", "soccer", "Amistosos internacionales", "Internacional"),
            new League("concacaf.nations.league", "soccer", "Concacaf Nations League", "Norteamérica"),
            new League("concacaf.gold", "soccer", "Copa Oro Concacaf", "Norteamérica"),
            new League("concacaf.leagues.cup", "soccer", "Leagues Cup", "Norteamérica"),
            new League("fifa.worldq.concacaf", "soccer", "Eliminatorias Concacaf", "Norteamérica"),
            new League("uefa.nations", "soccer", "UEFA Nations League", "Europa"),
            new League("uefa.euro", "soccer", "Eurocopa", "Europa"),
            new League("uefa.euroq", "soccer", "Eliminatorias Eurocopa", "Europa"),
            new League("fifa.worldq.uefa", "soccer", "Eliminatorias UEFA", "Europa"),
            new League("conmebol.america", "soccer", "Copa América", "Sudamérica"),
            new League("fifa.worldq.conmebol", "soccer", "Eliminatorias Conmebol", "Sudamérica"),
            new League("caf.nations", "soccer", "Copa Africana de Naciones", "Internacional"),
            new League("fifa.world", "soccer", "Copa Mundial FIFA", "Internacional"),
            new League("fifa.cwc", "soccer", "Mundial de Clubes FIFA", "Internacional"),
            new League("esp.copa_del_rey", "soccer", "Copa del Rey", "Europa"),
            new League("eng.fa", "soccer", "FA Cup", "Europa"),
            new League("eng.league_cup", "soccer", "Carabao Cup", "Europa"),
            new League("ita.coppa_italia", "soccer", "Coppa Italia", "Europa"),
            new League("ger.dfb_pokal", "soccer", "DFB Pokal", "Europa"),
            new League("fra.coupe_de_france", "soccer", "Copa de Francia", "Europa"),
            new League("wnba", "basketball", "WNBA", "Norteamérica"),
            new League("nfl", "football", "NFL", "Norteamérica"),
            new League("nba", "basketball", "NBA", "Norteamérica"),
            new League("mlb", "baseball", "MLB", "Norteamérica"),
            new League("nhl", "hockey", "NHL", "Norteamérica"),
            new League("ufc", "mma", "UFC", "Internacional")
        };

        private const string Base = "https://site.api.espn.com/apis/site/v2/sports";
        private static readonly SemaphoreSlim Gate = new SemaphoreSlim(16);
        private static readonly ConcurrentDictionary<string, Tuple<long, List<Match>>> Cache = new ConcurrentDictionary<string, Tuple<long, List<Match>>>();

        public static int LeagueIndex(string slug)
        {
            for (int i = 0; i < Leagues.Count; i++) if (Leagues[i].Slug == slug) return i;
            return int.MaxValue;
        }

        private static string DayKey(DateTime local) => local.ToString("yyyyMMdd", CultureInfo.InvariantCulture);

        private static long ParseDate(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return 0;
            DateTime d;
            if (DateTime.TryParseExact(s, new[] { "yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.fff'Z'" },
                    CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out d))
                return new DateTimeOffset(d, TimeSpan.Zero).ToUnixTimeMilliseconds();
            DateTimeOffset o;
            if (DateTimeOffset.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out o)) return o.ToUnixTimeMilliseconds();
            return 0;
        }

        /// <summary>Todas las ligas de un día de ESPN (caché de 90 s).</summary>
        private static async Task<List<Match>> EspnDay(string key, bool force)
        {
            Tuple<long, List<Match>> c;
            if (!force && Cache.TryGetValue(key, out c) && J.NowMs() - c.Item1 < 90_000) return c.Item2;
            var tasks = Leagues.Select(async lg =>
            {
                await Gate.WaitAsync().ConfigureAwait(false);
                try { return await LeagueDay(lg, key).ConfigureAwait(false); }
                catch { return null; }
                finally { Gate.Release(); }
            }).ToList();
            var results = await Task.WhenAll(tasks).ConfigureAwait(false);
            if (results.All(r => r == null)) throw new IOException("Sin conexión");
            var all = results.Where(r => r != null).SelectMany(r => r).ToList();
            Cache[key] = Tuple.Create(J.NowMs(), all);
            return all;
        }

        /// <summary>Partidos del día (hora de la PC): se piden el día anterior, el del día y el siguiente de ESPN.</summary>
        public static async Task<List<Match>> Matches(DateTime day, bool force)
        {
            DateTime from = day.Date, to = from.AddDays(1);
            long fromMs = new DateTimeOffset(from).ToUnixTimeMilliseconds(), toMs = new DateTimeOffset(to).ToUnixTimeMilliseconds();
            string center = DayKey(from.AddHours(12));
            var keys = new[] { DayKey(from.AddHours(-12)), center, DayKey(to.AddHours(12)) }.Distinct().ToList();
            var got = await Task.WhenAll(keys.Select(async k =>
            {
                bool f = force && (k == center || (Cache.TryGetValue(k, out var cc) && cc.Item2.Any(m => m.Live)));
                try { return Tuple.Create(k, await EspnDay(k, f).ConfigureAwait(false)); }
                catch { return Tuple.Create(k, (List<Match>)null); }
            })).ConfigureAwait(false);
            if (got.All(g => g.Item2 == null)) throw new IOException("Sin conexión");
            var seen = new HashSet<string>();
            return got.SelectMany(g => (g.Item2 ?? new List<Match>()).Where(m => m.Start > 0 ? m.Start >= fromMs && m.Start < toMs : g.Item1 == center))
                .Where(m => seen.Add(m.League.Sport + ":" + m.Id) && seen.Add(DupKey(m)))
                .OrderBy(m => m.Start).ThenBy(m => LeagueIndex(m.League.Slug))
                .ToList();
        }

        private static string DupKey(Match m) => TextUtil.Norm(m.Home.Name) + "|" + TextUtil.Norm(m.Away.Name) + "|" + (m.Start / 60_000);

        private static List<string> Broadcasts(JsonNode comp)
        {
            var outList = new List<string>();
            var b = J.ArrOf(comp, "broadcasts");
            if (b != null)
                foreach (var x in b)
                {
                    var names = J.ArrOf(x, "names");
                    if (names == null) continue;
                    foreach (var n in names) { string t = J.Text(n); if (t.Length > 0 && !outList.Contains(t)) outList.Add(t); }
                }
            var g = J.ArrOf(comp, "geoBroadcasts");
            if (g != null)
                foreach (var x in g)
                {
                    string t = J.Str(J.ObjOf(x, "media"), "shortName");
                    if (t.Length > 0 && !outList.Contains(t)) outList.Add(t);
                }
            return outList;
        }

        private static async Task<List<Match>> LeagueDay(League lg, string day)
        {
            var o = J.Obj(await Net.GetString(Base + "/" + lg.Sport + "/" + lg.Slug + "/scoreboard?dates=" + day, 15000).ConfigureAwait(false));
            var outList = new List<Match>();
            if (o == null) return outList;
            var lgs = J.ArrOf(o, "leagues");
            string logo = "";
            if (lgs != null && lgs.Count > 0)
            {
                var logos = J.ArrOf(lgs[0], "logos");
                if (logos != null && logos.Count > 0) logo = J.Str(logos[0], "href");
            }
            var events = J.ArrOf(o, "events");
            if (events == null) return outList;
            foreach (var ev in events)
            {
                var comps = J.ArrOf(ev, "competitions");
                if (comps == null) continue;
                for (int c = 0; c < comps.Count; c++)
                {
                    var comp = comps[c];
                    var status = J.ObjOf(comp, "status") ?? J.ObjOf(ev, "status") ?? new JsonObject();
                    var type = J.ObjOf(status, "type") ?? new JsonObject();
                    var competitors = J.ArrOf(comp, "competitors");
                    if (competitors == null) continue;
                    Team home = null, away = null;
                    foreach (var t in competitors)
                    {
                        var team = J.ObjOf(t, "team");
                        var ath = J.ObjOf(t, "athlete");
                        string name = J.Str(team, "displayName");
                        if (name.Length == 0) name = J.Str(ath, "displayName", "?");
                        string shrt = J.Str(team, "shortDisplayName");
                        if (shrt.Length == 0) shrt = name;
                        string tlogo = J.Str(team, "logo");
                        if (tlogo.Length == 0)
                        {
                            var tl = J.ArrOf(team, "logos");
                            if (tl != null && tl.Count > 0) tlogo = J.Str(tl[0], "href");
                        }
                        if (tlogo.Length == 0) tlogo = J.Str(J.ObjOf(ath, "flag"), "href");
                        string id = J.Str(team, "id");
                        if (id.Length == 0) id = J.Str(t, "id");
                        var tm = new Team(id, Selecciones.Es(name), Selecciones.Es(shrt), tlogo, J.Str(t, "score"));
                        string ha = J.Str(t, "homeAway");
                        if (ha == "away" || (home != null && away == null && ha != "home")) away = tm; else home = tm;
                    }
                    if (home == null || away == null) continue;
                    string evId = J.Str(ev, "id");
                    string date = J.Str(comp, "date");
                    if (date.Length == 0) date = J.Str(ev, "date");
                    string detail = J.Str(type, "shortDetail");
                    if (detail.Length == 0) detail = J.Str(type, "detail");
                    outList.Add(new Match
                    {
                        Id = comps.Count > 1 ? (J.Str(comp, "id").Length > 0 ? J.Str(comp, "id") : evId + "_" + c) : evId,
                        League = lg,
                        LeagueLogo = logo,
                        Start = ParseDate(date),
                        State = J.Str(type, "state", "pre"),
                        Detail = detail,
                        Clock = J.Str(status, "displayClock"),
                        Home = home,
                        Away = away,
                        Tv = Broadcasts(comp)
                    });
                }
            }
            return outList;
        }

        // ------------------------------------------------------------- incidencias

        private static string Es(string type)
        {
            switch (type.ToLowerInvariant())
            {
                case "goal": case "goal - header": case "goal - free-kick": case "goal - volley": return "Gol";
                case "penalty - scored": return "Gol de penal";
                case "penalty - missed": case "penalty - saved": return "Penal fallado";
                case "own goal": return "Autogol";
                case "yellow card": return "Tarjeta amarilla";
                case "red card": return "Tarjeta roja";
                case "substitution": return "Cambio";
                case "kickoff": return "Inicio del partido";
                case "halftime": return "Medio tiempo";
                case "start 2nd half": return "Inicio del 2.º tiempo";
                case "end regular time": case "full time": return "Final";
                case "var": return "Revisión VAR";
                default: return type;
            }
        }

        private static string KindOf(string type)
        {
            string t = type.ToLowerInvariant();
            if (t == "own goal") return "own";
            if (t.StartsWith("goal") || t == "penalty - scored") return "goal";
            if (t.Contains("yellow")) return "yellow";
            if (t.Contains("red card")) return "red";
            if (t.Contains("substitution")) return "sub";
            if (t == "kickoff" || t == "halftime" || t.StartsWith("start ") || t.StartsWith("end ") || t == "full time") return "period";
            return "other";
        }

        /// <summary>Goles, tarjetas y cambios del partido (solo partidos de ESPN).</summary>
        public static async Task<List<KeyEvent>> Summary(Match m)
        {
            var list = new List<KeyEvent>();
            if (m.Panel) return list;
            var o = J.Obj(await Net.GetString(Base + "/" + m.League.Sport + "/" + m.League.Slug + "/summary?event=" + m.Id, 15000).ConfigureAwait(false));
            var arr = J.ArrOf(o, "keyEvents");
            if (arr == null) return list;
            foreach (var e in arr)
            {
                string type = J.Str(J.ObjOf(e, "type"), "text");
                string kind = KindOf(type);
                var names = new List<string>();
                var parts = J.ArrOf(e, "participants");
                if (parts != null) foreach (var p in parts) { string n = J.Str(J.ObjOf(p, "athlete"), "displayName"); if (n.Length > 0) names.Add(n); }
                string teamId = J.Str(J.ObjOf(e, "team"), "id");
                string label = Es(type);
                string text = kind == "sub" && names.Count >= 2 ? label + ": entra " + names[0] + " · sale " + names[1]
                    : names.Count > 0 ? label + ", " + names[0] : (label.Length > 0 ? label : J.Str(e, "text"));
                list.Add(new KeyEvent { Minute = J.Str(J.ObjOf(e, "clock"), "displayValue"), Text = text, Kind = kind, Home = teamId.Length == 0 || teamId == m.Home.Id });
            }
            return list;
        }

        // -------------------------------------------------- canales que pasan el partido

        private static readonly HashSet<string> Stop = new HashSet<string>
        {
            "fc", "cf", "club", "de", "del", "la", "el", "los", "las", "w", "women", "womens", "femenil", "fem", "the",
            "afc", "cd", "sc", "ac", "as", "ss", "sd", "ud", "rc", "real", "united", "city", "deportivo", "atletico",
            "sporting", "new", "san", "santa", "saint", "st", "fk", "sk", "if", "bk", "1", "04", "05", "09"
        };

        internal static readonly string[] SportWords =
        {
            "deporte", "sport", "futbol", "soccer", "nba", "nfl", "mlb", "nhl", "ufc", "espn", "fox", "tudn", "dazn",
            "bein", "liga", "ppv", "evento", "event", "box", "tnt", "sky", "golf", "tenis", "tennis", "match", "gol",
            "claro", "azteca", "univision", "telemundo", "tyc", "win", "directv", "movistar", "eleven", "arena",
            "sportv", "premiere", "paramount", "peacock", "vix", "tsn", "sportsnet", "msg", "bally", "fanduel",
            "marquee", "nesn", "yes", "nbc", "cbs", "abc", "prime", "apple", "max", "hbo", "caliente"
        };

        private static readonly HashSet<string> Noise = new HashSet<string>
        {
            "us", "usa", "mx", "mex", "es", "esp", "latam", "lat", "ar", "arg", "co", "col", "cl", "pe", "ec", "ve",
            "uy", "br", "ca", "uk", "hd", "fhd", "uhd", "sd", "4k", "hevc", "h265", "east", "west", "este", "oeste",
            "1080", "1080p", "720", "720p", "60fps", "fps", "backup", "alt", "tv", "channel", "canal", "network"
        };

        private static readonly Regex NonAlnum = new Regex("[^a-z0-9]+", RegexOptions.Compiled);

        private static IEnumerable<string> Toks(string s) => NonAlnum.Split(TextUtil.Norm(s ?? "")).Where(t => t.Length >= 4 && !Stop.Contains(t));

        /// <summary>Palabras que identifican al equipo (nombre corto; en futbol también el completo).</summary>
        public static List<string> TeamKeys(Team t, bool soccer)
        {
            var shrt = Toks(t.Short).ToList();
            if (shrt.Count == 0) return Toks(t.Name).Distinct().ToList();
            return soccer ? shrt.Concat(Toks(t.Name)).Distinct().ToList() : shrt.Distinct().ToList();
        }

        /// <summary>Palabras del equipo en español e inglés.</summary>
        public static List<string> KeysOf(Team t, bool soccer)
        {
            var outList = new List<string>(TeamKeys(t, soccer));
            foreach (var v in Selecciones.Variants(t.Name).Concat(Selecciones.Variants(t.Short)))
                foreach (var k in TeamKeys(new Team("", v, v, "", ""), true)) if (!outList.Contains(k)) outList.Add(k);
            foreach (var c in Selecciones.Codes(t.Name)) if (!outList.Contains(c)) outList.Add(c);
            return outList;
        }

        private static readonly ConcurrentDictionary<string, Regex> WordRx = new ConcurrentDictionary<string, Regex>();

        public static bool Has(string text, IEnumerable<string> keys)
        {
            foreach (var k in keys)
            {
                var rx = WordRx.GetOrAdd(k, x => new Regex("(^|[^a-z0-9])" + Regex.Escape(x) + "([^a-z0-9]|$)", RegexOptions.Compiled));
                if (rx.IsMatch(text)) return true;
            }
            return false;
        }

        /// <summary>Nombre del canal sin país ni calidad: "US: ESPN 2 FHD" → "espn 2".</summary>
        public static string CleanName(string name) =>
            string.Join(" ", NonAlnum.Split(TextUtil.Norm(name ?? "")).Where(t => t.Length > 0 && !Noise.Contains(t)));

        private static readonly HashSet<string> GenericLeague = new HashSet<string> { "liga", "league", "copa", "division", "profesional", "primera", "women", "cup", "championship" };
        private static readonly HashSet<string> Countries = new HashSet<string> { "usa", "mex", "eng", "esp", "ita", "ger", "fra", "por", "arg", "bra", "col", "bol", "fifa", "uefa" };

        private static List<string> LeagueKeys(Match m)
        {
            string b = m.League.Slug.Split('.')[0];
            var outList = new List<string>();
            if (b.Length >= 3 && !Countries.Contains(b)) outList.Add(b);
            foreach (var t in NonAlnum.Split(TextUtil.Norm(m.League.Name))) if (t.Length >= 4 && !GenericLeague.Contains(t) && !outList.Contains(t)) outList.Add(t);
            return outList;
        }

        private static readonly Regex VsWord = new Regex("\\b(vs|v|x)\\b\\.?", RegexOptions.Compiled);

        /// <summary>Canales que la guía puede confirmar: primero las cadenas de ESPN, luego los de la liga y los deportivos.</summary>
        public static List<Item> EpgCandidates(Match m, List<Item> live, List<Category> cats, HashSet<int> exclude)
        {
            var tv = m.Tv.Select(CleanName).Where(x => x.Length > 0).ToList();
            var lk = LeagueKeys(m);
            var sportCats = new HashSet<string>(cats.Where(c => !c.Adult && SportWords.Any(w => c.Norm.Contains(w))).Select(c => c.Id));
            var first = new List<Item>();
            var second = new List<Item>();
            var rest = new List<Item>();
            foreach (var ch in live)
            {
                if (exclude.Contains(ch.Id) || TextUtil.IsAdult(ch.Norm)) continue;
                if (VsWord.IsMatch(ch.Norm) || ch.Norm.Contains(" @ ")) continue;
                string clean = CleanName(ch.Name);
                if (tv.Any(t => t == clean || (clean.StartsWith(t + " ") && clean.Length <= t.Length + 3))) first.Add(ch);
                else if (lk.Any(k => Has(ch.Norm, new[] { k }))) second.Add(ch);
                else if (sportCats.Contains(ch.CatId) || SportWords.Take(14).Any(w => ch.Norm.Contains(w))) rest.Add(ch);
            }
            return first.Concat(second).Concat(rest).Take(120).ToList();
        }

        /// <summary>¿Este programa de la guía es el partido? Misma hora y los dos equipos en el título o la descripción.</summary>
        public static bool ProgramIs(EpgEntry e, Match m)
        {
            long start = m.Start > 0 ? m.Start : J.NowMs();
            long pEnd = e.End > 0 ? e.End : e.Start + 2 * 3600_000L;
            if (e.Start > start + 3 * 3600_000L || pEnd < start - 10 * 60_000L) return false;
            string t = TextUtil.Norm(e.Title + " " + e.Desc);
            bool soccer = m.League.Sport == "soccer";
            var hk = KeysOf(m.Home, soccer);
            var ak = KeysOf(m.Away, soccer);
            return hk.Count > 0 && ak.Count > 0 && Has(t, hk) && Has(t, ak);
        }
    }

    /// <summary>
    /// Partidos del panel: TODOS los canales "A vs B" (y los que dice la guía de los canales de
    /// eventos), aunque ESPN no los tenga. Si ESPN tiene el mismo partido, se le suman los canales.
    /// </summary>
    public static class PanelEvents
    {
        private sealed class LiveList { public string Owner; public long At; public List<Item> Items; public List<Category> Cats; }
        private sealed class Raw { public string Title, Cat; public long Start, End; public Item Ch; }

        private static LiveList _live;
        private static Tuple<string, long, List<Match>> _cache;
        private static readonly ConcurrentDictionary<int, Tuple<long, List<EpgEntry>>> Epg = new ConcurrentDictionary<int, Tuple<long, List<EpgEntry>>>();
        private static readonly ConcurrentDictionary<string, Tuple<long, List<Item>>> EpgOk = new ConcurrentDictionary<string, Tuple<long, List<Item>>>();

        private static string Owner() => (Prefs.S.Server ?? "").ToLowerInvariant() + "|" + Prefs.S.User;

        /// <summary>Canales en vivo recientes (15 min): los nombres de los eventos cambian durante el día.</summary>
        private static async Task<LiveList> Channels(bool force)
        {
            string who = Owner();
            long now = J.NowMs();
            var l = _live;
            if (!force && l != null && l.Owner == who && now - l.At < 15 * 60_000L) return l;
            var a = Prefs.Account();
            List<Item> items = null;
            List<Category> cats = null;
            try { items = await Xtream.Streams(a, Kind.Live).ConfigureAwait(false); } catch { }
            try { cats = await Xtream.Categories(a, Kind.Live).ConfigureAwait(false); } catch { }
            if (cats == null) cats = Catalog.Snap?.LiveCats ?? new List<Category>();
            if (items != null && items.Count > 0)
            {
                var adult = new HashSet<string>(cats.Where(c => c.Adult).Select(c => c.Id));
                items = items.Where(i => !adult.Contains(i.CatId) && !TextUtil.IsAdult(i.Norm)).ToList();
                return _live = new LiveList { Owner = who, At = now, Items = items, Cats = cats };
            }
            if (l != null && l.Owner == who) return l;
            var s = Catalog.Snap;
            if (s == null) return null;
            return new LiveList { Owner = who, At = now, Items = s.Live.Where(i => !s.IsAdultItem(i)).ToList(), Cats = s.LiveCats };
        }

        /// <summary>Guía de un canal (15 min en memoria).</summary>
        public static async Task<List<EpgEntry>> EpgOf(int id)
        {
            Tuple<long, List<EpgEntry>> c;
            if (Epg.TryGetValue(id, out c) && J.NowMs() - c.Item1 < 15 * 60_000L) return c.Item2;
            List<EpgEntry> list;
            try { list = await Xtream.ShortEpg(Prefs.Account(), id, 10).ConfigureAwait(false); }
            catch { list = new List<EpgEntry>(); }
            Epg[id] = Tuple.Create(J.NowMs(), list);
            return list;
        }

        // ------------------------------------------------------------ nombres

        private static readonly Regex Vs = new Regex("(?i)\\b(vs?\\.?|versus)(?=\\s|$|[^a-z0-9])|\\s@\\s", RegexOptions.Compiled);
        private static readonly Regex VsX = new Regex("(?<=\\p{L})\\s+x\\s+(?=\\p{L})", RegexOptions.Compiled);
        private static readonly Regex Split = new Regex("(?i)\\s+(?:vs?\\.?|versus|contra|@|(?-i:x))\\s+", RegexOptions.Compiled);
        private static readonly Regex CatEventos = new Regex("(?i)evento|event|deport|sport|ppv|mlb|lmb|lmp|nba|nfl|nhl|ufc|box|liga|futbol|soccer|beisbol|baseball|tenis|tennis|ncaa|f1|formula|copa|cup|champions|premier|serie a|bundesliga|ligue|concacaf|uefa|conmebol", RegexOptions.Compiled);
        private static readonly Regex CatDate = new Regex("\\b([0-3]?\\d)/([01]?\\d)\\b", RegexOptions.Compiled);
        private static readonly Regex Zone = new Regex("\\b(ET|EST|EDT|CT|CST|CDT|MT|MST|PT|PST|PDT|UK|GMT|UTC|CET|CEST|ART|BRT)\\b", RegexOptions.Compiled);
        private static readonly Regex ClockRx = new Regex("(?i)(?<![0-9])([01]?[0-9]|2[0-3])[:.]([0-5][0-9])(?:[:][0-5][0-9])?\\s*([ap]\\.?m\\.?)?(?![0-9])", RegexOptions.Compiled);
        private static readonly Regex ClockH = new Regex("(?i)(?<![0-9])([1-9]|1[0-2])\\s*([ap]\\.?m\\.?)(?![a-z])", RegexOptions.Compiled);
        private static readonly Regex TimeInTeam = new Regex("(?i)\\b(?:[01]?\\d|2[0-3])[:.]([0-5]\\d)(?:\\s*[ap]\\.?m\\.?)?\\b", RegexOptions.Compiled);
        private static readonly Regex ZoneInTeam = new Regex("\\b(?:ET|EST|EDT|CT|CST|CDT|MT|MST|PT|PST|PDT|UK|GMT|UTC|CET|CEST|MX)\\b", RegexOptions.Compiled);
        private static readonly Regex LeaguePrefix = new Regex("(?i)^(?:la\\s*liga|laliga|liga\\s*mx|premier\\s*league|bundesliga|serie\\s*a|champions(?:\\s*league)?|uefa|concacaf|copa(?:\\s+[^:|•]+)?|eventos?|partidos?|soccer|futbol|fútbol|nba|nfl|mlb|nhl)\\s*[:|•-]\\s*", RegexOptions.Compiled);
        private static readonly Regex Notes = new Regex("\\s*[\\[(][^\\])]*[\\])]\\s*", RegexOptions.Compiled);
        private static readonly Regex Tags = new Regex("(?i)\\b(?:EN VIVO|LIVE|HD|FHD|4K|1080P)\\b", RegexOptions.Compiled);
        private static readonly HashSet<string> GenericCats = new HashSet<string> { "eventos", "evento", "events", "event", "deportes", "sports", "ppv", "en vivo", "live", "" };
        private static readonly Regex OnlyTime = new Regex("(?i)^[\\s\\d:.]*(?:[ap]\\.?\\s?m\\.?)?\\s*(?:ET|EST|EDT|CT|CST|MT|PT|UK|GMT|UTC|CET|MX)?\\s*$", RegexOptions.Compiled);
        private static readonly char[] TrimChars = { ' ', '-', ':', '|', '•', '–', ',', '.' };

        private static bool NoSinEvento(string name) => !TextUtil.Norm(name).Contains("sin evento");
        public static bool IsVs(string name) => Vs.IsMatch(name ?? "") && NoSinEvento(name ?? "");
        private static bool IsVsEvent(string name) => IsVs(name) || (VsX.IsMatch(name ?? "") && NoSinEvento(name ?? ""));

        private static string CleanTeam(string source)
        {
            string r = LeaguePrefix.Replace(source.Trim(), "");
            int p = r.LastIndexOf(':');
            if (p > 1 && p < r.Length - 2 && r.Substring(0, p).Any(char.IsLetter) && !Regex.IsMatch(r.Substring(0, p), "\\d{1,2}$"))
                r = r.Substring(p + 1);
            r = TimeInTeam.Replace(r, " ");
            r = Notes.Replace(r, " ");
            r = ZoneInTeam.Replace(r, " ");
            r = Tags.Replace(r, " ");
            r = Regex.Replace(r, "\\s+", " ");
            return r.Trim(TrimChars);
        }

        /// <summary>Los dos equipos del nombre ("Liga | 08:30 PM | México vs Canadá").</summary>
        public static Tuple<string, string> Teams(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return null;
            var segs = raw.Split('|');
            string candidate = segs.LastOrDefault(x => Split.IsMatch(x)) ?? raw;
            var parts = Split.Split(candidate, 2);
            if (parts.Length != 2) return null;
            string home = CleanTeam(parts[0]);
            string away = CleanTeam(parts[1].Split('|')[0].Split('•')[0]);
            if (home.Length < 2 || away.Length < 2) return null;
            return Tuple.Create(home, away);
        }

        private static readonly HashSet<string> KeyStop = new HashSet<string> { "fc", "cf", "sc", "cd", "club", "de", "del", "the", "el" };

        private static string KeyOf(string name) =>
            string.Join(" ", NonAlnumSpace(TextUtil.Norm(CleanTeam(name))).Split(' ').Where(x => x.Length > 0 && !KeyStop.Contains(x)));

        private static string NonAlnumSpace(string s) => Regex.Replace(s, "[^a-z0-9]+", " ").Trim();

        private static TimeZoneInfo Tz(string iana, string windows)
        {
            try { return TimeZoneInfo.FindSystemTimeZoneById(iana); } catch { }
            try { return TimeZoneInfo.FindSystemTimeZoneById(windows); } catch { }
            return TimeZoneInfo.Local;
        }

        private static readonly Lazy<TimeZoneInfo> Mexico = new Lazy<TimeZoneInfo>(() => Tz("America/Mexico_City", "Central Standard Time (Mexico)"));

        private static TimeZoneInfo ZoneOf(string name)
        {
            var m = Zone.Match(name ?? "");
            if (!m.Success) return null;
            switch (m.Value)
            {
                case "ET": case "EST": case "EDT": return Tz("America/New_York", "Eastern Standard Time");
                case "CT": case "CST": case "CDT": return Tz("America/Chicago", "Central Standard Time");
                case "MT": case "MST": return Tz("America/Denver", "Mountain Standard Time");
                case "PT": case "PST": case "PDT": return Tz("America/Los_Angeles", "Pacific Standard Time");
                case "UK": return Tz("Europe/London", "GMT Standard Time");
                case "GMT": case "UTC": return TimeZoneInfo.Utc;
                case "CET": case "CEST": return Tz("Europe/Madrid", "Romance Standard Time");
                case "ART": return Tz("America/Argentina/Buenos_Aires", "Argentina Standard Time");
                case "BRT": return Tz("America/Sao_Paulo", "E. South America Standard Time");
                default: return null;
            }
        }

        private static bool ClockOf(string text, out int h, out int min)
        {
            h = 0; min = 0;
            var m = ClockRx.Match(text ?? "");
            if (m.Success)
            {
                h = int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture);
                min = int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture);
                string ap = m.Groups[3].Value.ToLowerInvariant().Replace(".", "");
                if (ap.Length > 0)
                {
                    if (h < 1 || h > 12) return false;
                    h = h % 12 + (ap == "pm" ? 12 : 0);
                }
                return true;
            }
            var m2 = ClockH.Match(text ?? "");
            if (!m2.Success) return false;
            h = int.Parse(m2.Groups[1].Value, CultureInfo.InvariantCulture) % 12 + (m2.Groups[2].Value.ToLowerInvariant().StartsWith("p") ? 12 : 0);
            return true;
        }

        /// <summary>Hora escrita en el nombre ("13:00 ET", "08:30 PM"); sin zona = hora de Ciudad de México.</summary>
        private static long StartFromName(string name, string category, long now)
        {
            int h, min;
            if (!ClockOf(name, out h, out min)) return 0;
            var tz = ZoneOf(name) ?? Mexico.Value;
            try
            {
                var local = TimeZoneInfo.ConvertTime(DateTimeOffset.FromUnixTimeMilliseconds(now), tz).DateTime;
                int y = local.Year, mo = local.Month, d = local.Day;
                var cm = CatDate.Match(category ?? "");
                if (cm.Success)
                {
                    int dd = int.Parse(cm.Groups[1].Value, CultureInfo.InvariantCulture), mm = int.Parse(cm.Groups[2].Value, CultureInfo.InvariantCulture);
                    if (dd >= 1 && dd <= 31 && mm >= 1 && mm <= 12) { d = dd; mo = mm; }
                }
                var dt = new DateTime(y, mo, d, h, min, 0, DateTimeKind.Unspecified);
                return new DateTimeOffset(dt, tz.GetUtcOffset(dt)).ToUnixTimeMilliseconds();
            }
            catch { return 0; }
        }

        private static string CleanCategory(string name)
        {
            string t = CatDate.Replace(name ?? "", " ");
            t = Regex.Replace(t, "[^\\p{L}\\p{N}+&' .:|/-]", " ");
            t = Regex.Replace(t, "(?i)\\b(eventos?|events?|en vivo|live|hd|fhd)\\b", " ");
            t = Regex.Replace(t, "\\s*[|:/-]\\s*$", "");
            t = Regex.Replace(t, "\\s+", " ").Trim(' ', '|', '-', ':', '/');
            return t.Length > 0 ? t : "Eventos";
        }

        private static string LeagueFromTitle(string title)
        {
            var parts = title.Split('|', '•').Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
            string byPart = parts.FirstOrDefault(t => !IsVsEvent(t) && !OnlyTime.IsMatch(t) && t.Any(char.IsLetter));
            string cand = byPart;
            if (cand == null)
            {
                int p = title.IndexOf(':');
                if (p > 0)
                {
                    string c = title.Substring(0, p).Trim();
                    if (c.Length >= 3 && c.Length <= 40 && !IsVsEvent(c)) cand = c;
                }
            }
            if (cand == null) return null;
            string clean = CleanCategory(cand);
            return GenericCats.Contains(TextUtil.Norm(clean)) ? null : clean;
        }

        private static string SportOf(string text)
        {
            string t = TextUtil.Norm(text);
            if (Regex.IsMatch(t, "\\b(nba|wnba|basket|basquet|baloncesto|ncaab)\\b")) return "basketball";
            if (Regex.IsMatch(t, "\\b(nfl|ncaaf|football americano|futbol americano)\\b")) return "football";
            if (Regex.IsMatch(t, "\\b(mlb|lmb|lmp|beisbol|baseball)\\b")) return "baseball";
            if (Regex.IsMatch(t, "\\b(nhl|hockey)\\b")) return "hockey";
            if (Regex.IsMatch(t, "\\b(ufc|box|boxeo|mma|wwe)\\b")) return "mma";
            return "soccer";
        }

        private static string RegionOf(string text)
        {
            string n = TextUtil.Norm(text);
            if (n.Contains("mexico") || n.Contains("liga mx") || n.Contains(" mx") || n.Contains("lmb") || n.Contains("lmp")) return "México";
            if (Regex.IsMatch(n, "\\b(nba|nfl|mlb|nhl|mls|ncaa|usa|wnba|concacaf)\\b")) return "Norteamérica";
            if (Regex.IsMatch(n, "argentina|brasil|brazil|colombia|chile|peru|ecuador|uruguay|paraguay|bolivia|venezuela|libertadores|sudamericana|conmebol")) return "Sudamérica";
            if (Regex.IsMatch(n, "premier|laliga|la liga|serie a|bundesliga|ligue|champions|europa|espana|inglaterra|italia|alemania|francia|portugal|uefa")) return "Europa";
            return "Internacional";
        }

        // ------------------------------------------------------------ partidos del panel

        public static List<Match> Cached()
        {
            var c = _cache;
            return c != null && c.Item1 == Owner() ? c.Item3 : new List<Match>();
        }

        /// <summary>Partidos "A vs B" del panel (3 min en memoria; force = volver a pedir los canales).</summary>
        public static async Task<List<Match>> Matches(bool force)
        {
            string who = Owner();
            long now = J.NowMs();
            var cached = _cache;
            if (!force && cached != null && cached.Item1 == who && now - cached.Item2 < 3 * 60_000L) return cached.Item3;
            var s = await Channels(force).ConfigureAwait(false);
            if (s == null) return Cached();
            var catName = new Dictionary<string, string>();
            foreach (var c in s.Cats) catName[c.Id] = c.Name;
            var eventCats = new HashSet<string>(s.Cats.Where(c => !c.Adult && CatEventos.IsMatch(c.Name)).Select(c => c.Id));
            var raws = new List<Raw>();
            foreach (var ch in s.Items)
            {
                if (!IsVs(ch.Name) && !(eventCats.Contains(ch.CatId) && IsVsEvent(ch.Name))) continue;
                string cat;
                catName.TryGetValue(ch.CatId ?? "", out cat);
                raws.Add(new Raw { Title = ch.Name, Cat = cat ?? "", Start = StartFromName(ch.Name, cat, now), Ch = ch });
            }
            // La guía de los canales de eventos que no traen el partido en el nombre
            var epgCands = s.Items.Where(i => eventCats.Contains(i.CatId) && !IsVsEvent(i.Name)).Take(60).ToList();
            if (epgCands.Count > 0)
            {
                var gate = new SemaphoreSlim(5);
                var work = Task.WhenAll(epgCands.Select(async ch =>
                {
                    await gate.WaitAsync().ConfigureAwait(false);
                    try
                    {
                        var epg = await EpgOf(ch.Id).ConfigureAwait(false);
                        string cat;
                        catName.TryGetValue(ch.CatId ?? "", out cat);
                        return epg.Where(e => IsVsEvent(e.Title) && (e.End == 0 || e.End > now - 6 * 3600_000L))
                            .Select(e => new Raw { Title = e.Title, Cat = cat ?? "", Start = e.Start, End = e.End, Ch = ch }).ToList();
                    }
                    catch { return new List<Raw>(); }
                    finally { gate.Release(); }
                }));
                if (await Task.WhenAny(work, Task.Delay(20000)).ConfigureAwait(false) == work)
                    foreach (var l in work.Result) raws.AddRange(l);
            }
            // Un partido por enfrentamiento y día, con todas sus señales
            var groups = new Dictionary<string, List<Raw>>();
            var order = new List<string>();
            foreach (var r in raws)
            {
                var pair = Teams(r.Title);
                if (pair == null) continue;
                string day = r.Start > 0 ? DateTimeOffset.FromUnixTimeMilliseconds(r.Start).LocalDateTime.ToString("yyyyMMdd", CultureInfo.InvariantCulture) : "hoy";
                string k = KeyOf(pair.Item1) + "|" + KeyOf(pair.Item2) + "|" + day;
                List<Raw> g;
                if (!groups.TryGetValue(k, out g)) { g = new List<Raw>(); groups[k] = g; order.Add(k); }
                g.Add(r);
            }
            var outList = new List<Match>();
            foreach (var k in order)
            {
                var g = groups[k];
                var best = g.OrderByDescending(r => r.End > 0 ? 2 : r.Start > 0 ? 1 : 0).First();
                var pair = Teams(best.Title);
                if (pair == null) continue;
                long start = best.Start;
                long end = best.End > 0 ? best.End : start > 0 ? start + 150 * 60_000L : 0;
                string state = start <= 0 || now < start ? "pre" : end > 0 && now >= end ? "post" : "in";
                string cat = g.Select(r => r.Cat).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "";
                string fromCat = CleanCategory(cat);
                string leagueName = GenericCats.Contains(TextUtil.Norm(fromCat)) ? (LeagueFromTitle(best.Title) ?? fromCat) : fromCat;
                string text = cat + " " + leagueName + " " + best.Title;
                var league = Sports.Leagues.FirstOrDefault(l => TextUtil.Norm(l.Name) == TextUtil.Norm(leagueName))
                    ?? new League("panel:" + TextUtil.Norm(leagueName), SportOf(text), leagueName, RegionOf(text));
                var chans = new List<Item>();
                foreach (var r in g) if (!chans.Any(c => c.Id == r.Ch.Id)) chans.Add(r.Ch);
                outList.Add(new Match
                {
                    Id = "p" + ((uint)k.GetHashCode()).ToString("x", CultureInfo.InvariantCulture),
                    League = league,
                    LeagueLogo = chans.Select(c => c.Icon).FirstOrDefault(u => !string.IsNullOrEmpty(u) && u.StartsWith("http")) ?? "",
                    Start = start,
                    State = state,
                    Detail = state == "in" ? "EN VIVO" : "",
                    Home = new Team("", pair.Item1, pair.Item1, "", ""),
                    Away = new Team("", pair.Item2, pair.Item2, "", ""),
                    Panel = true,
                    Channels = chans,
                    End = end
                });
            }
            var withCrests = await Crests.Fill(outList).ConfigureAwait(false);
            _cache = Tuple.Create(who, now, withCrests);
            return withCrests;
        }

        // ------------------------------------------------------------ unir con ESPN

        private static bool SameTeams(Match espn, Match p)
        {
            bool soccer = espn.League.Sport == "soccer";
            var hk = Sports.KeysOf(espn.Home, soccer);
            var ak = Sports.KeysOf(espn.Away, soccer);
            if (hk.Count == 0 || ak.Count == 0) return false;
            string ph = string.Join(" ", Selecciones.Variants(p.Home.Name).Select(TextUtil.Norm));
            string pa = string.Join(" ", Selecciones.Variants(p.Away.Name).Select(TextUtil.Norm));
            bool both = (Sports.Has(ph, hk) && Sports.Has(pa, ak)) || (Sports.Has(ph, ak) && Sports.Has(pa, hk));
            if (!both) return false;
            return !(espn.Start > 0 && p.Start > 0 && Math.Abs(espn.Start - p.Start) > 4 * 3600_000L);
        }

        private static List<Item> Dedup(IEnumerable<Item> list)
        {
            var outList = new List<Item>();
            var ids = new HashSet<int>();
            foreach (var i in list) if (i != null && ids.Add(i.Id)) outList.Add(i);
            return outList;
        }

        private static bool TimeOk(string name, string cat, long start)
        {
            if (start <= 0) return true;
            string ctx = cat + " " + name;
            long t = StartFromName(name, ctx, start);
            if (t <= 0) return true;
            long day = 24 * 3600_000L;
            long d = Math.Abs(t - start);
            if (!CatDate.IsMatch(ctx))
            {
                d %= day;
                d = Math.Min(d, day - d);
            }
            return d <= 3 * 3600_000L;
        }

        /// <summary>Canales con los dos equipos en el nombre (español o inglés) y a la misma hora.</summary>
        private static List<Item> ByName(Match m, List<Item> items, Dictionary<string, string> catName)
        {
            bool soccer = m.League.Sport == "soccer";
            var hk = Sports.KeysOf(m.Home, soccer);
            var ak = Sports.KeysOf(m.Away, soccer);
            if (hk.Count == 0 || ak.Count == 0) return new List<Item>();
            return items.Where(ch =>
            {
                string cat;
                catName.TryGetValue(ch.CatId ?? "", out cat);
                return Sports.Has(ch.Norm, hk) && Sports.Has(ch.Norm, ak) && TimeOk(ch.Name, cat ?? "", m.Start);
            }).Take(20).ToList();
        }

        private static bool Soon(Match m) => m.Live || (m.Start > 0 && m.Start - J.NowMs() < 4 * 3600_000L);

        private static Match Quick(Match m, List<Item> items, Dictionary<string, string> catName)
        {
            if (m.Panel) return Dedup(m.Channels).Count > 0 ? m : null;
            Tuple<long, List<Item>> ok;
            EpgOk.TryGetValue(m.Id, out ok);
            var chans = Dedup(m.Channels.Concat(ByName(m, items, catName)).Concat(ok?.Item2 ?? new List<Item>()));
            return chans.Count == 0 ? null : m.WithChannels(chans);
        }

        private static async Task<Match> One(Match m, List<Item> items, List<Category> cats, Dictionary<string, string> catName, bool deep)
        {
            var q = Quick(m, items, catName);
            if (q != null) return q;
            if (m.Panel || !deep || m.Finished || !Soon(m) || items.Count == 0) return null;
            long now = J.NowMs();
            Tuple<long, List<Item>> prev;
            if (EpgOk.TryGetValue(m.Id, out prev) && now - prev.Item1 < 10 * 60_000L) return prev.Item2.Count == 0 ? null : m.WithChannels(prev.Item2);
            var cands = Sports.EpgCandidates(m, items, cats, new HashSet<int>(m.Channels.Select(c => c.Id))).Take(10).ToList();
            var ok = new List<Item>();
            foreach (var ch in cands)
            {
                var epg = await EpgOf(ch.Id).ConfigureAwait(false);
                if (epg.Any(e => Sports.ProgramIs(e, m))) ok.Add(ch);
            }
            EpgOk[m.Id] = Tuple.Create(now, ok);
            return ok.Count == 0 ? null : m.WithChannels(Dedup(m.Channels.Concat(ok)));
        }

        /// <summary>Deja solo los partidos con canal (deep = también revisa la guía de los partidos cercanos).</summary>
        public static async Task<List<Match>> Confirm(List<Match> list, bool deep)
        {
            LiveList src = deep ? await Channels(false).ConfigureAwait(false) : (_live != null && _live.Owner == Owner() ? _live : null);
            var snap = Catalog.Snap;
            var items = src?.Items ?? (snap != null ? snap.Live.Where(i => !snap.IsAdultItem(i)).ToList() : new List<Item>());
            var cats = src?.Cats ?? snap?.LiveCats ?? new List<Category>();
            var catName = new Dictionary<string, string>();
            foreach (var c in cats) catName[c.Id] = c.Name;
            var gate = new SemaphoreSlim(6);
            var work = Task.WhenAll(list.Select(async m =>
            {
                await gate.WaitAsync().ConfigureAwait(false);
                try { return await One(m, items, cats, catName, deep).ConfigureAwait(false); }
                catch { return null; }
                finally { gate.Release(); }
            }));
            Match[] checkedList;
            if (await Task.WhenAny(work, Task.Delay(deep ? 25000 : 3000)).ConfigureAwait(false) == work) checkedList = work.Result;
            else checkedList = list.Select(m => { try { return Quick(m, items, catName); } catch { return null; } }).ToArray();
            return Absorb(checkedList.Where(m => m != null).ToList());
        }

        /// <summary>Un partido del panel que comparte canal con uno de ESPN se une a ESPN.</summary>
        private static List<Match> Absorb(List<Match> list)
        {
            var outList = list.Where(m => !m.Panel).ToList();
            foreach (var p in list.Where(m => m.Panel))
            {
                var ids = new HashSet<int>(p.Channels.Select(c => c.Id));
                int i = outList.FindIndex(e => !e.Panel && e.Channels.Any(c => ids.Contains(c.Id)) &&
                    (p.Start <= 0 || e.Start <= 0 || Math.Abs(e.Start - p.Start) <= 3 * 3600_000L));
                if (i >= 0) outList[i] = outList[i].WithChannels(Dedup(outList[i].Channels.Concat(p.Channels)));
                else outList.Add(p);
            }
            return outList.OrderBy(m => m.Start > 0 ? m.Start : long.MaxValue).ThenBy(m => m.Panel ? 1 : 0).ToList();
        }

        /// <summary>ESPN del día + partidos del panel de ese día (los de ESPN reciben los canales del panel).</summary>
        public static List<Match> Merge(DateTime day, List<Match> espn, List<Match> panel)
        {
            long from = new DateTimeOffset(day.Date).ToUnixTimeMilliseconds();
            long to = new DateTimeOffset(day.Date.AddDays(1)).ToUnixTimeMilliseconds();
            long now = J.NowMs();
            bool today = now >= from && now < to;
            var result = new List<Match>(espn);
            var extras = new List<Match>();
            foreach (var p in panel)
            {
                bool inDay = p.Start > 0 ? p.Start >= from && p.Start < to : today;
                if (!inDay) continue;
                int i = result.FindIndex(e => !e.Panel && SameTeams(e, p));
                if (i >= 0) result[i] = result[i].WithChannels(Dedup(result[i].Channels.Concat(p.Channels)));
                else extras.Add(p);
            }
            result.AddRange(extras);
            return result.OrderBy(m => m.Start > 0 ? m.Start : long.MaxValue).ThenBy(m => m.Panel ? 1 : 0).ToList();
        }
    }

    /// <summary>Escudos para los partidos del panel (TheSportsDB), guardados en la PC.</summary>
    public static class Crests
    {
        private static readonly object Gate = new object();
        private static Dictionary<string, string> _map;

        private static string FilePath => Paths.File("crests.json");

        private static Dictionary<string, string> Map()
        {
            lock (Gate)
            {
                if (_map != null) return _map;
                try { _map = File.Exists(FilePath) ? Js.Read<Dictionary<string, string>>(File.ReadAllText(FilePath)) : null; } catch { _map = null; }
                if (_map == null) _map = new Dictionary<string, string>();
                return _map;
            }
        }

        private static void Save()
        {
            string json;
            lock (Gate) json = Js.Write(_map);
            try { Paths.WriteAtomic(FilePath, json); } catch { }
        }

        private static bool Valid(string u) => !string.IsNullOrWhiteSpace(u) && u.StartsWith("http");

        public static async Task<string> Find(string name, string sport)
        {
            string k = Selecciones.Plain(name) + "|" + sport;
            if (k.Length < 4) return "";
            var map = Map();
            string v;
            lock (Gate)
            {
                if (map.TryGetValue(k, out v) && Valid(v)) return v;
                if (map.TryGetValue("miss:" + k, out v) && J.NowMs() - J.ToLong(v) < 12 * 3600_000L) return "";
            }
            string q = Selecciones.En(name);
            string expected = sport == "basketball" ? "basketball" : sport == "football" ? "american football" : sport == "baseball" ? "baseball" : sport == "hockey" ? "ice hockey" : "soccer";
            string found = "";
            try
            {
                var o = J.Obj(await Net.GetString("https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t=" + Uri.EscapeDataString(q), 5000).ConfigureAwait(false));
                var arr = J.ArrOf(o, "teams");
                string want = Selecciones.Plain(q);
                if (arr != null)
                    foreach (var t in arr)
                    {
                        string sp = J.Str(t, "strSport").Trim().ToLowerInvariant();
                        if (sp.Length > 0 && sp != expected) continue;
                        var names = new List<string> { J.Str(t, "strTeam"), J.Str(t, "strTeamShort") };
                        names.AddRange(J.Str(t, "strTeamAlternate").Split(','));
                        if (!names.Any(x => Selecciones.Plain(x) == want)) continue;
                        string team = Selecciones.Plain(J.Str(t, "strTeam"));
                        if (team.Contains("women") || Regex.IsMatch(team, "\\bu\\d{2}\\b")) continue;
                        string logo = J.Str(t, "strBadge");
                        if (logo.Length == 0) logo = J.Str(t, "strTeamBadge");
                        if (Valid(logo)) { found = logo; break; }
                    }
            }
            catch { }
            lock (Gate)
            {
                if (Valid(found)) { map[k] = found; map.Remove("miss:" + k); }
                else map["miss:" + k] = J.NowMs().ToString(CultureInfo.InvariantCulture);
            }
            Save();
            return found;
        }

        /// <summary>Pone escudos a los partidos del panel (máx. 8 s; lo que falte se completa después).</summary>
        public static async Task<List<Match>> Fill(List<Match> list)
        {
            if (list.Count == 0) return list;
            var names = list.SelectMany(m => new[] { Tuple.Create(m.Home.Name, m.League.Sport), Tuple.Create(m.Away.Name, m.League.Sport) }).Distinct().ToList();
            var got = new ConcurrentDictionary<Tuple<string, string>, string>();
            var gate = new SemaphoreSlim(4);
            var work = Task.WhenAll(names.Select(async n =>
            {
                await gate.WaitAsync().ConfigureAwait(false);
                try { string u = await Find(n.Item1, n.Item2).ConfigureAwait(false); if (u.Length > 0) got[n] = u; }
                catch { }
                finally { gate.Release(); }
            }));
            await Task.WhenAny(work, Task.Delay(8000)).ConfigureAwait(false);
            return list.Select(m =>
            {
                string h, a;
                got.TryGetValue(Tuple.Create(m.Home.Name, m.League.Sport), out h);
                got.TryGetValue(Tuple.Create(m.Away.Name, m.League.Sport), out a);
                if (string.IsNullOrEmpty(h) && string.IsNullOrEmpty(a)) return m;
                var c = m.WithChannels(m.Channels);
                c.Home = new Team(m.Home.Id, m.Home.Name, m.Home.Short, string.IsNullOrEmpty(h) ? m.Home.Logo : h, m.Home.Score);
                c.Away = new Team(m.Away.Id, m.Away.Name, m.Away.Short, string.IsNullOrEmpty(a) ? m.Away.Logo : a, m.Away.Score);
                return c;
            }).ToList();
        }
    }
}
