using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI
{
    /// <summary>
    /// Controles de los reproductores (TV en vivo y películas/series) con el acomodo de la app de
    /// Android: arriba regresar, inicio, título, hora y sonido; al centro anterior / pausa / siguiente;
    /// abajo la información y los botones. Aparecen con el mouse o el control y se ocultan solos.
    /// </summary>
    public sealed class PlayerChrome : Grid
    {
        private static readonly CultureInfo Es = new CultureInfo("es-MX");

        public readonly Button BackBtn, HomeBtn, PlayBtn, VolBtn;
        public readonly Image Logo = new Image { Stretch = Stretch.Uniform };
        public readonly Border LogoBox;
        public readonly TextBlock Title = Ui.T("", 22, Brushes.White, FontWeights.Bold);
        public readonly TextBlock Subtitle = Ui.T("", 14.5, Ui.Hex("#FFD9D0EC"));
        public readonly TextBlock Clock = Ui.T("", 18, Brushes.White, FontWeights.SemiBold);
        public readonly StackPanel TopRight = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };
        public readonly StackPanel Center = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        public readonly StackPanel BottomLeft = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        public readonly StackPanel BottomRight = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };
        /// <summary>Fila encima de los botones de abajo (la barra de avance en películas y series).</summary>
        public readonly ContentControl Extra = new ContentControl { Focusable = false, IsTabStop = false };

        /// <summary>Mientras devuelva true los controles no se ocultan (pausa, arrastrando la barra…).</summary>
        public Func<bool> KeepOpen;
        /// <summary>Después de un clic con el mouse el foco vuelve aquí (así no queda un botón marcado).</summary>
        public Action FocusRest;
        public event Action ShownChanged;
        public int HideMs = 5000;
        private DispatcherTimer _hide;

        public bool IsShown => Visibility == Visibility.Visible;
        /// <summary>Se está usando con el control remoto o el teclado (hay un botón elegido).</summary>
        public bool IsActive => IsShown && IsKeyboardFocusWithin;

        public PlayerChrome(Action back, Action home, Action playPause)
        {
            Visibility = Visibility.Collapsed;
            RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // ---------- Arriba: regresar · inicio · canal / título · hora · sonido
            var top = new Border { Background = Ui.Gradient("#E0000000", "#00000000", 90), Padding = new Thickness(26, 18, 30, 64) };
            var tg = new Grid();
            tg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            tg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            tg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var left = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            BackBtn = Ctl(G.Back, back, "Regresar (Esc)");
            HomeBtn = Ctl(G.Home, home, "Inicio");
            HomeBtn.Margin = new Thickness(6, 0, 0, 0);
            left.Children.Add(BackBtn);
            left.Children.Add(HomeBtn);
            tg.Children.Add(left);

            var mid = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(18, 0, 18, 0) };
            LogoBox = new Border
            {
                Width = 78, Height = 50, CornerRadius = new CornerRadius(12), Background = Ui.Hex("#B3120D1C"),
                Padding = new Thickness(6), Margin = new Thickness(0, 0, 14, 0), Child = Logo, Visibility = Visibility.Collapsed
            };
            mid.Children.Add(LogoBox);
            var titles = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            Title.TextTrimming = TextTrimming.CharacterEllipsis;
            Title.Effect = Ui.Shadow(10, 0.8);
            Subtitle.TextTrimming = TextTrimming.CharacterEllipsis;
            Subtitle.Margin = new Thickness(0, 2, 0, 0);
            titles.Children.Add(Title);
            titles.Children.Add(Subtitle);
            mid.Children.Add(titles);
            Grid.SetColumn(mid, 1);
            tg.Children.Add(mid);

            Clock.VerticalAlignment = VerticalAlignment.Center;
            Clock.Margin = new Thickness(0, 0, 16, 0);
            Clock.Effect = Ui.Shadow(10, 0.8);
            TopRight.Children.Add(Clock);
            VolBtn = Ctl(G.Volume, ToggleMute, "Sonido (M) · rueda del mouse: volumen");
            TopRight.Children.Add(VolBtn);
            Grid.SetColumn(TopRight, 2);
            tg.Children.Add(TopRight);
            top.Child = tg;
            Children.Add(top);

            // ---------- Centro: anterior · pausa · siguiente
            PlayBtn = new Button { Style = Ui.S("CtlBig"), Content = G.Pause, ToolTip = "Pausa / reproducir (Espacio)" };
            PlayBtn.Click += (s, e) => { playPause?.Invoke(); AfterClick(); };
            Center.Children.Add(PlayBtn);
            Grid.SetRow(Center, 1);
            Children.Add(Center);

            // ---------- Abajo: información · botones
            var bottom = new Border { Background = Ui.Gradient("#00000000", "#EB000000", 90), Padding = new Thickness(32, 64, 32, 24) };
            Grid.SetRow(bottom, 2);
            var bs = new StackPanel();
            bs.Children.Add(Extra);
            var bg = new Grid { Margin = new Thickness(0, 8, 0, 0) };
            bg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            bg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            bg.Children.Add(BottomLeft);
            Grid.SetColumn(BottomRight, 1);
            bg.Children.Add(BottomRight);
            bs.Children.Add(bg);
            bottom.Child = bs;
            Children.Add(bottom);
        }

        // ------------------------------------------------------------ botones

        /// <summary>Botón de icono blanco (sin fondo) para los controles.</summary>
        public Button Ctl(string glyph, Action click, string tip = null, double size = 22)
        {
            var b = new Button { Style = Ui.S("Ctl"), Content = glyph, FontSize = size };
            if (tip != null) b.ToolTip = tip;
            b.Click += (s, e) => { click?.Invoke(); AfterClick(); };
            return b;
        }

        /// <summary>Botón de icono con un número abajo (−10 s / +10 s).</summary>
        public Button CtlSkip(string glyph, string number, Action click, string tip)
        {
            var st = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            var ic = Ui.Icon(glyph, 24, Brushes.White);
            ic.HorizontalAlignment = HorizontalAlignment.Center;
            st.Children.Add(ic);
            var n = Ui.T(number, 11, Brushes.White, FontWeights.Bold);
            n.FontFamily = Ui.Font;
            n.HorizontalAlignment = HorizontalAlignment.Center;
            n.Margin = new Thickness(0, 1, 0, 0);
            st.Children.Add(n);
            var b = new Button { Style = Ui.S("Ctl"), Content = st, Width = 64, Height = 64, ToolTip = tip };
            b.Click += (s, e) => { click?.Invoke(); AfterClick(); };
            return b;
        }

        /// <summary>Pone los botones a los lados del de pausa.</summary>
        public void SetCenter(Button left, Button right)
        {
            Center.Children.Clear();
            if (left != null)
            {
                left.Margin = new Thickness(0, 0, 56, 0);
                Center.Children.Add(left);
            }
            Center.Children.Add(PlayBtn);
            if (right != null)
            {
                right.Margin = new Thickness(56, 0, 0, 0);
                Center.Children.Add(right);
            }
        }

        public void AddRight(FrameworkElement e)
        {
            e.Margin = new Thickness(BottomRight.Children.Count == 0 ? 0 : 8, 0, 0, 0);
            BottomRight.Children.Add(e);
        }

        private void AfterClick()
        {
            Bump();
            // Con el mouse no se queda un botón marcado; con el control remoto sí.
            if (InputManager.Current.MostRecentInputDevice is MouseDevice && MainWindow.Instance?.Overlay?.DialogOpen != true)
                FocusRest?.Invoke();
        }

        // ------------------------------------------------------- mostrar / ocultar

        public void Show(bool focus = false)
        {
            if (!IsShown)
            {
                Visibility = Visibility.Visible;
                BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(160)));
                ShownChanged?.Invoke();
            }
            Paint();
            if (focus && !IsKeyboardFocusWithin) PlayBtn.Focus();
            Bump();
        }

        public void Hide()
        {
            _hide?.Stop();
            if (!IsShown) return;
            Visibility = Visibility.Collapsed;
            ShownChanged?.Invoke();
        }

        public void Toggle()
        {
            if (IsShown) Hide();
            else Show();
        }

        /// <summary>Reinicia la cuenta para ocultarse.</summary>
        public void Bump()
        {
            _hide?.Stop();
            if (!IsShown) return;
            _hide = UiThread.After(HideMs, () =>
            {
                if (!IsShown) return;
                if (IsMouseOver || (KeepOpen != null && KeepOpen())) { Bump(); return; }
                Hide();
            });
        }

        /// <summary>Hora, pausa y sonido al día.</summary>
        public void Paint()
        {
            var p = Playback.Main;
            Clock.Text = DateTime.Now.ToString("h:mm tt", Es);
            string play = p != null && p.Paused ? G.Play : G.Pause;
            if (!Equals(PlayBtn.Content, play)) PlayBtn.Content = play;
            string vol = p != null && p.Muted ? G.Mute : G.Volume;
            if (!Equals(VolBtn.Content, vol)) VolBtn.Content = vol;
        }

        // ------------------------------------------------------------- sonido

        public void ToggleMute()
        {
            var p = Playback.Main;
            if (p == null) return;
            p.SetMute(!p.Muted);
            Paint();
            MainWindow.Instance?.Toast(p.Muted ? "Sin sonido" : "Con sonido");
        }

        public static void Volume(int delta)
        {
            var p = Playback.Main;
            if (p == null) return;
            int v = Math.Max(0, Math.Min(150, (int)Math.Round(p.GetDouble("volume")) + delta));
            p.SetVolume(v);
            p.SetMute(false);
            Prefs.S.Volume = Math.Min(100, v);
            Prefs.Save();
            MainWindow.Instance?.Toast("Volumen " + v + " %");
        }

        // ------------------------------------------------- audio, subtítulos, pantalla

        public static void PickAudio()
        {
            var p = Playback.Main;
            if (p == null) return;
            var tracks = p.Tracks("audio");
            if (tracks.Count < 2) { MainWindow.Instance?.Toast("No hay otras pistas de audio"); return; }
            Dialogs.Choice("Audio", tracks.Select(t => t.Label).ToList(), Math.Max(0, tracks.FindIndex(t => t.Selected)), i => p.Set("aid", tracks[i].Id));
        }

        public static void PickSubs()
        {
            var p = Playback.Main;
            if (p == null) return;
            var tracks = p.Tracks("sub");
            if (tracks.Count == 0) { MainWindow.Instance?.Toast("Este video no tiene subtítulos"); return; }
            var labels = new List<string> { "Desactivados" };
            labels.AddRange(tracks.Select(t => t.Label));
            int sel = tracks.FindIndex(t => t.Selected) + 1;
            Dialogs.Choice("Subtítulos", labels, Math.Max(0, sel), i => p.Set("sid", i == 0 ? "no" : tracks[i - 1].Id));
        }

        private static int _aspect;

        public static void PickAspect()
        {
            var p = Playback.Main;
            if (p == null) return;
            var opts = new[] { "Ajustar (original)", "Llenar la pantalla", "16:9", "4:3" };
            Dialogs.Choice("Formato de pantalla", opts, _aspect, i =>
            {
                _aspect = i;
                switch (i)
                {
                    case 0: p.SetPanscan(0); p.SetAspect("no"); break;
                    case 1: p.SetAspect("no"); p.SetPanscan(1); break;
                    case 2: p.SetPanscan(0); p.SetAspect("16:9"); break;
                    case 3: p.SetPanscan(0); p.SetAspect("4:3"); break;
                }
            });
        }
    }
}
