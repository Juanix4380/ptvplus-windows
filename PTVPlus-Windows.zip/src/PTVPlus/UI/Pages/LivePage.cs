using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// TV en vivo a pantalla completa con listas semitransparentes encima (categorías + canales +
    /// buscador). ▲▼ cambian de canal con las listas ocultas; Enter las muestra; números = canal directo.
    /// </summary>
    public sealed class LivePage : Page
    {
        public const string FavKey = "fav";
        public const string RecentKey = "recent";
        public const string EventsKey = "events";
        public const string AllKey = "all";

        private readonly int? _startId;
        private string _catKey;
        private readonly Grid _ov = new Grid();
        private readonly Grid _hit = new Grid { Background = new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)) };
        private readonly Border _panel = new Border { HorizontalAlignment = HorizontalAlignment.Left, Width = 820 };
        private readonly ListBox _cats = new ListBox();
        private readonly ListBox _channels = new ListBox();
        private readonly TextBox _search = new TextBox();
        private readonly TextBlock _chTitle = Ui.T("", 20, Brushes.White, FontWeights.Bold);
        private readonly PlayerChrome _chrome;
        private readonly TextBlock _bNow = Ui.T("", 15.5, Brushes.White, FontWeights.SemiBold);
        private readonly TextBlock _bNext = Ui.T("", 13.5, Ui.Hex("#FFC9BFE0"));
        private readonly Grid _bProg = new Grid { Height = 4, Width = 380, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 7, 0, 6) };
        private readonly Border _bProgFill = new Border { HorizontalAlignment = HorizontalAlignment.Left, CornerRadius = new CornerRadius(2) };
        private Button _favBtn;
        private EpgEntry _epgNowEntry;
        private Point _lastMouse = new Point(-1, -1);
        private bool _leaving;
        private readonly TextBlock _status = Ui.T("", 20, Brushes.White, FontWeights.SemiBold);
        private readonly Border _digitsBox = new Border { Visibility = Visibility.Collapsed, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 40, 50, 0) };
        private readonly TextBlock _digits = Ui.T("", 44, Brushes.White, FontWeights.Bold);
        private readonly TextBlock _stats = Ui.T("", 13, Brushes.White);
        private List<CatEntry> _entries = new List<CatEntry>();
        private List<Item> _shown = new List<Item>();
        private DispatcherTimer _hidePanel, _digitTimer, _tick, _searchTimer;
        private string _digitBuf = "";
        private int _epgFor;

        public override bool VideoFull => true;
        public override UIElement OverlayContent => _ov;

        public LivePage(int? channelId, string startKey)
        {
            _startId = channelId;
            _catKey = startKey ?? (string.IsNullOrEmpty(Prefs.S.LastLiveCat) ? AllKey : Prefs.S.LastLiveCat);
            Background = Brushes.Black;
            _chrome = new PlayerChrome(Leave, () => { _leaving = true; Main.GoHome(); }, TogglePause);
            BuildOverlay();
        }

        // ------------------------------------------------------------ capa

        private void BuildOverlay()
        {
            _hit.Focusable = true;
            _hit.FocusVisualStyle = null;
            _ov.MouseMove += (s, e) =>
            {
                if (!Moved(e)) return;
                _hit.Cursor = null;
                if (_panel.Visibility != Visibility.Visible) _chrome.Show();
            };
            _hit.MouseLeftButtonUp += (s, e) =>
            {
                if (_panel.Visibility == Visibility.Visible) HidePanel();
                else _chrome.Toggle();
            };
            _hit.MouseLeftButtonDown += (s, e) => { if (e.ClickCount == 2) Main.ToggleFullscreen(); };
            _hit.MouseWheel += (s, e) => PlayerChrome.Volume(e.Delta > 0 ? 5 : -5);
            _ov.Children.Add(_hit);

            // Estado (conectando / reconectando / error)
            _status.HorizontalAlignment = HorizontalAlignment.Center;
            _status.VerticalAlignment = VerticalAlignment.Center;
            _status.TextWrapping = TextWrapping.Wrap;
            _status.TextAlignment = TextAlignment.Center;
            _status.MaxWidth = 700;
            _status.Margin = new Thickness(0, 210, 0, 0);
            _status.Effect = Ui.Shadow(12, 0.9);
            _status.IsHitTestVisible = false;
            _ov.Children.Add(_status);

            // Panel izquierdo: categorías | canales
            _panel.Background = new LinearGradientBrush(Color.FromArgb(0xF2, 0x07, 0x05, 0x0C), Color.FromArgb(0x00, 0x07, 0x05, 0x0C), new Point(0.62, 0), new Point(1, 0));
            var cols = new Grid { Margin = new Thickness(36, 30, 0, 24) };
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(250) });
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(440) });
            var catCol = new DockPanel { Margin = new Thickness(0, 0, 14, 0) };
            var ct = Ui.T("● CATEGORÍAS", 13, Ui.B("Accent"), FontWeights.Bold);
            ct.Margin = new Thickness(12, 0, 0, 12);
            DockPanel.SetDock(ct, Dock.Top);
            catCol.Children.Add(ct);
            _cats.Style = Ui.S("PlainList");
            _cats.ItemContainerStyle = Ui.S("RowItem");
            _cats.ItemTemplate = (DataTemplate)Application.Current.Resources["CatTemplate"];
            catCol.Children.Add(_cats);
            cols.Children.Add(catCol);

            var chCol = new DockPanel();
            Grid.SetColumn(chCol, 1);
            var sbox = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            _search.Style = Ui.S("Field");
            _search.Height = 46;
            _search.Padding = new Thickness(42, 0, 12, 0);
            sbox.Children.Add(_search);
            var si = Ui.Icon(G.Search, 15, Ui.B("Text3"));
            si.HorizontalAlignment = HorizontalAlignment.Left;
            si.Margin = new Thickness(15, 0, 0, 0);
            si.IsHitTestVisible = false;
            sbox.Children.Add(si);
            var sh = Ui.T("Buscar canal", 15, Ui.B("Text3"));
            sh.VerticalAlignment = VerticalAlignment.Center;
            sh.Margin = new Thickness(44, 0, 0, 0);
            sh.IsHitTestVisible = false;
            sbox.Children.Add(sh);
            _search.TextChanged += (s, e) =>
            {
                sh.Visibility = _search.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
                _searchTimer?.Stop();
                _searchTimer = UiThread.After(220, RunSearch);
                BumpPanel();
            };
            DockPanel.SetDock(sbox, Dock.Top);
            chCol.Children.Add(sbox);
            _chTitle.Margin = new Thickness(6, 0, 0, 8);
            DockPanel.SetDock(_chTitle, Dock.Top);
            chCol.Children.Add(_chTitle);
            _channels.Style = Ui.S("PlainList");
            _channels.ItemContainerStyle = Ui.S("RowItem");
            _channels.ItemTemplate = (DataTemplate)Application.Current.Resources["ChannelTemplate"];
            chCol.Children.Add(_channels);
            cols.Children.Add(chCol);
            _panel.Child = cols;
            _panel.Visibility = Visibility.Collapsed;
            _ov.Children.Add(_panel);

            _cats.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var c = ItemsControl.ContainerFromElement(_cats, e.OriginalSource as DependencyObject) as ListBoxItem;
                if (c?.DataContext is CatEntry ce) ApplyCat(ce);
                e.Handled = true;
            };
            _channels.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var c = ItemsControl.ContainerFromElement(_channels, e.OriginalSource as DependencyObject) as ListBoxItem;
                if (c?.DataContext is Item it) Play(it, true);
                e.Handled = true;
            };
            _cats.PreviewMouseWheel += (s, e) => BumpPanel();
            _channels.PreviewMouseWheel += (s, e) => BumpPanel();

            // Controles (como en Android): arriba regresar / inicio / canal / hora / Mis canales / sonido,
            // al centro canal anterior / pausa / canal siguiente, abajo EN VIVO + guía y botones.
            var prev = _chrome.Ctl(G.Prev, () => Zap(-1), "Canal anterior (▲)", 26);
            var next = _chrome.Ctl(G.Next, () => Zap(1), "Canal siguiente (▼)", 26);
            prev.Width = prev.Height = next.Width = next.Height = 66;
            _chrome.SetCenter(prev, next);
            _favBtn = _chrome.Ctl(G.Star, ToggleFav, "Agregar a Mis canales (F2)");
            _favBtn.Margin = new Thickness(0, 0, 6, 0);
            _chrome.TopRight.Children.Insert(1, _favBtn);

            var live = Ui.Badge("●  EN VIVO", Ui.Hex("#FFE0245E"));
            live.VerticalAlignment = VerticalAlignment.Top;
            live.Margin = new Thickness(0, 3, 16, 0);
            _chrome.BottomLeft.Children.Add(live);
            var epg = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            _bNow.TextTrimming = TextTrimming.CharacterEllipsis;
            _bNow.MaxWidth = 620;
            _bNext.TextTrimming = TextTrimming.CharacterEllipsis;
            _bNext.MaxWidth = 620;
            epg.Children.Add(_bNow);
            _bProg.Children.Add(new Border { Background = Ui.Hex("#44FFFFFF"), CornerRadius = new CornerRadius(2) });
            _bProgFill.Background = Ui.B("Accent");
            _bProg.Children.Add(_bProgFill);
            _bProg.Visibility = Visibility.Collapsed;
            epg.Children.Add(_bProg);
            epg.Children.Add(_bNext);
            _chrome.BottomLeft.Children.Add(epg);

            _chrome.AddRight(Ui.Pill("Canales", () => ShowPanel(false), G.List));
            _chrome.AddRight(_chrome.Ctl(G.Tiles, () => { _leaving = true; Main.Go(new MultiPage()); }, "Multipantalla"));
            _chrome.AddRight(_chrome.Ctl(G.Audio, PlayerChrome.PickAudio, "Audio"));
            _chrome.AddRight(_chrome.Ctl(G.All, PlayerChrome.PickAspect, "Formato de pantalla"));
            _chrome.AddRight(_chrome.Ctl(G.Full, () => Main.ToggleFullscreen(), "Pantalla completa (F)"));
            _chrome.KeepOpen = () => Playback.Main != null && Playback.Main.Paused;
            _chrome.FocusRest = FocusHit;
            _chrome.ShownChanged += () =>
            {
                if (!_chrome.IsShown && _panel.Visibility != Visibility.Visible) FocusHit();
                _hit.Cursor = !_chrome.IsShown && _panel.Visibility != Visibility.Visible && Main.IsFullscreen ? Cursors.None : null;
            };
            _ov.Children.Add(_chrome);

            // Número de canal tecleado
            _digitsBox.Background = Ui.Hex("#D9120D1C");
            _digitsBox.CornerRadius = new CornerRadius(16);
            _digitsBox.Padding = new Thickness(26, 10, 26, 10);
            _digitsBox.Child = _digits;
            _digitsBox.IsHitTestVisible = false;
            _ov.Children.Add(_digitsBox);

            // Datos de reproducción
            var statsBox = new Border
            {
                Background = Ui.Hex("#C0100A1A"), CornerRadius = new CornerRadius(12), Padding = new Thickness(14, 10, 14, 10),
                HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 24, 24, 0),
                Child = _stats, IsHitTestVisible = false
            };
            _stats.FontFamily = new FontFamily("Consolas");
            _stats.TextTrimming = TextTrimming.None;
            statsBox.SetBinding(VisibilityProperty, new System.Windows.Data.Binding("Text") { Source = _stats, Converter = new EmptyToCollapsed() });
            _ov.Children.Add(statsBox);
        }

        // ------------------------------------------------------- ciclo de vida

        public override void OnShow()
        {
            Catalog.Changed += Reload;
            Playback.Changed += PaintStatus;
            _tick = UiThread.Every(1000, Tick);
            Reload();
            var cur = Playback.Current;
            Item start = null;
            var s = Catalog.Snap;
            if (s != null)
            {
                if (_startId.HasValue) start = s.Find(Kind.Live, _startId.Value);
                if (start == null && _catKey == EventsKey) start = _shown.FirstOrDefault();
                if (start == null) start = s.Find(Kind.Live, Prefs.S.LastLiveId) ?? _shown.FirstOrDefault() ?? s.Live.FirstOrDefault();
            }
            if (cur != null && cur.IsLive && cur.Channel != null && start != null && cur.Channel.Id == start.Id)
            {
                // Viene de la vista previa: el mismo canal sigue, ahora con sonido.
                Playback.Main?.SetMute(false);
                Library.AddRecentLive(start.Id);
            }
            else if (start != null) Play(start, false);
            ShowInfo();
            // Desde "TV en vivo" se abre la lista; desde un canal (vista previa, búsqueda) los controles.
            if (_startId.HasValue && _catKey != EventsKey) _chrome.Show(true);
            else ShowPanel(false);
        }

        public override void OnHide()
        {
            Catalog.Changed -= Reload;
            Playback.Changed -= PaintStatus;
            _tick?.Stop();
            _hidePanel?.Stop();
            _digitTimer?.Stop();
            _chrome.Hide();
            Main.Activate();
        }

        public override void FocusFirst()
        {
            // El teclado va a la capa de encima del video (listas y controles).
            Main.Overlay?.Activate();
            if (_panel.Visibility == Visibility.Visible) FocusChannel(PlayingIndex());
            else if (_chrome.IsShown) _chrome.PlayBtn.Focus();
            else FocusHit();
        }

        private void FocusHit()
        {
            _hit.Focus();
        }

        private bool Moved(MouseEventArgs e)
        {
            var p = e.GetPosition(_ov);
            bool moved = _lastMouse.X < 0 || Math.Abs(p.X - _lastMouse.X) + Math.Abs(p.Y - _lastMouse.Y) > 4;
            _lastMouse = p;
            return moved;
        }

        /// <summary>Salir de TV en vivo (botón de regresar de los controles).</summary>
        private void Leave()
        {
            _leaving = true;
            Main.Back();
        }

        public override bool OnBack()
        {
            if (_leaving) return false;
            if (_search.Text.Length > 0 && _search.IsKeyboardFocusWithin) { _search.Text = ""; return true; }
            if (_panel.Visibility == Visibility.Visible) { HidePanel(); return true; }
            if (_chrome.IsActive) { _chrome.Hide(); return true; }
            _chrome.Hide();
            return false;
        }

        // ------------------------------------------------------------- datos

        private void Reload()
        {
            var s = Catalog.Snap;
            if (s == null) { _status.Text = Catalog.Error ?? "Cargando canales…"; return; }
            bool kids = Profiles.Current()?.Kids ?? false;
            bool adult = Prefs.S.ShowAdult && !kids;
            var list = new List<CatEntry>
            {
                new CatEntry { Key = FavKey, Name = "Mis canales", Items = () => Library.Favorites().Where(f => f.Kind == Kind.Live).Select(f => s.Find(Kind.Live, f.Id)).Where(i => i != null).ToList() },
                new CatEntry { Key = RecentKey, Name = "Recientes", Items = () => Library.RecentLive().Select(id => s.Find(Kind.Live, id)).Where(i => i != null).ToList() },
                new CatEntry { Key = EventsKey, Name = "Eventos", Items = () => Scopes.Events(s) },
                new CatEntry { Key = AllKey, Name = "Todos", Count = s.Live.Count(i => adult || !s.IsAdultItem(i)).ToString(), Items = () => s.Live.Where(i => adult || !s.IsAdultItem(i)).ToList() }
            };
            foreach (var c in s.LiveCats)
            {
                if (c.Adult && !adult) continue;
                if (kids && !Scopes.Matches(c, Scopes.KidsWords)) continue;
                int n = s.ItemsOf(Kind.Live, c.Id).Count;
                if (n == 0) continue;
                var cat = c;
                list.Add(new CatEntry { Key = c.Id, Name = c.Name, Count = n.ToString(), Items = () => s.ItemsOf(Kind.Live, cat.Id) });
            }
            _entries = list;
            _cats.ItemsSource = _entries;
            var sel = _entries.FirstOrDefault(e => e.Key == _catKey) ?? _entries.First(e => e.Key == AllKey);
            ApplyCat(sel, false);
            _cats.SelectedItem = sel;
        }

        private void ApplyCat(CatEntry e, bool bump = true)
        {
            if (e == null) return;
            foreach (var x in _entries) x.Applied = x == e;
            _catKey = e.Key;
            if (e.Key != EventsKey) { Prefs.S.LastLiveCat = e.Key; Prefs.Save(); }
            _shown = e.Items() ?? new List<Item>();
            _chTitle.Text = e.Name + "  ·  " + _shown.Count;
            if (_search.Text.Length > 0) _search.Text = "";
            _channels.ItemsSource = _shown;
            int i = PlayingIndex();
            if (i >= 0) { _channels.SelectedIndex = i; _channels.ScrollIntoView(_shown[i]); }
            if (bump) BumpPanel();
        }

        private void RunSearch()
        {
            var s = Catalog.Snap;
            if (s == null) return;
            string q = TextUtil.Norm(_search.Text.Trim());
            if (q.Length == 0)
            {
                var cur = _entries.FirstOrDefault(x => x.Applied);
                _shown = cur?.Items() ?? new List<Item>();
                _chTitle.Text = (cur?.Name ?? "") + "  ·  " + _shown.Count;
            }
            else
            {
                bool adult = Prefs.S.ShowAdult;
                int num;
                bool isNum = int.TryParse(q, out num);
                _shown = s.Live.Where(i => (adult || !s.IsAdultItem(i)) && (i.Norm.Contains(q) || (isNum && i.Num == num))).Take(300).ToList();
                _chTitle.Text = "Resultados  ·  " + _shown.Count;
            }
            _channels.ItemsSource = _shown;
        }

        private int PlayingIndex()
        {
            var cur = Playback.Current;
            if (cur == null || cur.Channel == null) return _shown.Count > 0 ? 0 : -1;
            int i = _shown.FindIndex(x => x.Id == cur.Channel.Id);
            return i >= 0 ? i : (_shown.Count > 0 ? 0 : -1);
        }

        // ------------------------------------------------------------- canal

        private void Play(Item it, bool fromList)
        {
            if (it == null) return;
            var cur = Playback.Current;
            if (cur != null && cur.Channel != null && cur.Channel.Id == it.Id && Playback.LastError == null)
            {
                if (fromList) HidePanel();
                return;
            }
            Playback.PlayChannel(it, false);
            _epgFor = 0;
            if (fromList) HidePanel();
            ShowInfo();
            if (_panel.Visibility != Visibility.Visible) _chrome.Show(false);
        }

        private void Zap(int delta)
        {
            if (_shown.Count == 0) return;
            int i = PlayingIndex();
            int n = ((i + delta) % _shown.Count + _shown.Count) % _shown.Count;
            Play(_shown[n], false);
            _channels.SelectedIndex = n;
        }

        // ------------------------------------------------------------ panel

        private void ShowPanel(bool focusCats)
        {
            _chrome.Hide();
            _hit.Cursor = null;
            if (_panel.Visibility != Visibility.Visible)
            {
                _panel.Visibility = Visibility.Visible;
                _panel.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(170)));
            }
            Main.Overlay?.Activate();
            if (focusCats) FocusCat();
            else FocusChannel(PlayingIndex());
            BumpPanel();
        }

        private void HidePanel()
        {
            _hidePanel?.Stop();
            _panel.Visibility = Visibility.Collapsed;
            Main.Overlay?.Activate();
            FocusHit();
        }

        private void BumpPanel()
        {
            _hidePanel?.Stop();
            _hidePanel = UiThread.After(12000, () =>
            {
                if (_search.IsKeyboardFocusWithin || Playback.Current == null) { BumpPanel(); return; }
                HidePanel();
            });
        }

        private void FocusChannel(int i)
        {
            if (_shown.Count == 0) { FocusCat(); return; }
            i = Math.Max(0, Math.Min(i, _shown.Count - 1));
            _channels.SelectedIndex = i;
            _channels.ScrollIntoView(_shown[i]);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                var c = _channels.ItemContainerGenerator.ContainerFromIndex(i) as ListBoxItem;
                c?.Focus();
            }), DispatcherPriority.Loaded);
        }

        private void FocusCat()
        {
            var cur = _entries.FirstOrDefault(e => e.Applied);
            if (cur == null) return;
            _cats.SelectedItem = cur;
            _cats.ScrollIntoView(cur);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                var c = _cats.ItemContainerGenerator.ContainerFromItem(cur) as ListBoxItem;
                c?.Focus();
            }), DispatcherPriority.Loaded);
        }

        // ----------------------------------------------------------- cartel

        /// <summary>Canal, categoría, logo, guía y Mis canales en los controles.</summary>
        private void ShowInfo()
        {
            var cur = Playback.Current;
            var it = cur?.Channel;
            if (it == null) return;
            _chrome.Title.Text = (it.Num > 0 ? it.Num + "   " : "") + it.Name;
            var cat = Catalog.Snap?.CategoryOf(Kind.Live, it.CatId);
            _chrome.Subtitle.Text = cat?.Name ?? "";
            _chrome.Subtitle.Visibility = string.IsNullOrEmpty(_chrome.Subtitle.Text) ? Visibility.Collapsed : Visibility.Visible;
            if (!string.IsNullOrEmpty(it.Icon))
            {
                Images.Load(_chrome.Logo, it.Icon, 160);
                _chrome.LogoBox.Visibility = Visibility.Visible;
            }
            else _chrome.LogoBox.Visibility = Visibility.Collapsed;
            PaintFav(it);
            if (_epgFor != it.Id) LoadEpg(it);
        }

        private void PaintFav(Item it)
        {
            bool on = it != null && Library.IsFav(Kind.Live, it.Id);
            _favBtn.Content = on ? G.StarFill : G.Star;
            _favBtn.Foreground = on ? Ui.Hex("#FFFFC83D") : Brushes.White;
            _favBtn.ToolTip = on ? "Quitar de Mis canales (F2)" : "Agregar a Mis canales (F2)";
        }

        private void ToggleFav()
        {
            var it = Playback.Current?.Channel;
            if (it == null) return;
            bool on = Library.ToggleFav(it);
            PaintFav(it);
            Main.Toast(on ? "Agregado a Mis canales" : "Quitado de Mis canales");
        }

        private void TogglePause()
        {
            if (Playback.Current == null) return;
            Playback.TogglePause();
            UiThread.After(150, () => _chrome.Paint());
            _chrome.Bump();
        }

        private async void LoadEpg(Item it)
        {
            _epgFor = it.Id;
            _epgNowEntry = null;
            _bNow.Text = "Sin guía para este canal";
            _bNext.Text = "";
            _bNext.Visibility = Visibility.Collapsed;
            _bProg.Visibility = Visibility.Collapsed;
            try
            {
                var list = await Xtream.ShortEpg(Prefs.Account(), it.Id, 4);
                if (_epgFor != it.Id) return;
                long now = J.NowMs();
                var cur = list.FirstOrDefault(e => e.Start <= now && (e.End == 0 || e.End > now));
                var next = list.FirstOrDefault(e => e.Start > now);
                if (cur != null)
                {
                    _epgNowEntry = cur;
                    _bNow.Text = "Ahora: " + cur.Title + (cur.End > 0 ? "   ·   " + cur.Hours : "");
                    _bProg.Visibility = cur.End > 0 ? Visibility.Visible : Visibility.Collapsed;
                    _bProgFill.Width = Math.Max(4, _bProg.Width * cur.Progress(now));
                }
                if (next != null)
                {
                    _bNext.Text = "Después: " + next.Title + "   " + TextUtil.Clock(next.Start);
                    _bNext.Visibility = Visibility.Visible;
                }
            }
            catch { }
        }

        private void PaintStatus()
        {
            var m = Playback.Main;
            if (Playback.LastError != null) _status.Text = Playback.LastError;
            else if (Playback.Notice != null) _status.Text = Playback.Notice;
            else if (m != null && Playback.Current != null && (m.Buffering || (m.CoreIdle && m.Position <= 0))) _status.Text = "Cargando…";
            else _status.Text = "";
        }

        private void Tick()
        {
            PaintStatus();
            if (_chrome.IsShown)
            {
                _chrome.Paint();
                var e = _epgNowEntry;
                if (e != null && e.End > 0)
                {
                    long now = J.NowMs();
                    if (now >= e.End) { _epgFor = 0; ShowInfo(); }
                    else _bProgFill.Width = Math.Max(4, _bProg.Width * e.Progress(now));
                }
            }
            _stats.Text = Prefs.S.PlayerStats && Playback.Main != null && Playback.Current != null ? Playback.Main.Stats() : "";
        }

        // ------------------------------------------------------------ teclado

        public override bool OnKey(KeyEventArgs e)
        {
            var k = e.Key;
            bool panel = _panel.Visibility == Visibility.Visible;
            // Número de canal directo
            int digit = -1;
            if (k >= Key.D0 && k <= Key.D9 && !_search.IsKeyboardFocusWithin) digit = k - Key.D0;
            if (k >= Key.NumPad0 && k <= Key.NumPad9) digit = k - Key.NumPad0;
            if (digit >= 0 && !_search.IsKeyboardFocusWithin)
            {
                Digit(digit);
                return true;
            }
            if (k == Key.M || k == Key.VolumeMute) { _chrome.ToggleMute(); return true; }
            if (k == Key.F) { Main.ToggleFullscreen(); return true; }
            if (k == Key.VolumeUp || k == Key.OemPlus || k == Key.Add) { PlayerChrome.Volume(5); return true; }
            if (k == Key.VolumeDown || k == Key.OemMinus || k == Key.Subtract) { PlayerChrome.Volume(-5); return true; }
            if (k == Key.MediaPlayPause || k == Key.Play || k == Key.Pause) { TogglePause(); _chrome.Show(); return true; }
            if (k == Key.F2 && !panel) { ToggleFav(); return true; }
            if (!panel)
            {
                if (_chrome.IsActive)
                {
                    // Con los controles elegidos: las flechas se mueven entre botones.
                    _chrome.Bump();
                    switch (k)
                    {
                        case Key.Up: Move(FocusNavigationDirection.Up); return true;
                        case Key.Down: Move(FocusNavigationDirection.Down); return true;
                        case Key.Left: Move(FocusNavigationDirection.Left); return true;
                        case Key.Right: Move(FocusNavigationDirection.Right); return true;
                        case Key.PageUp:
                        case Key.MediaPreviousTrack:
                            Zap(-1);
                            return true;
                        case Key.PageDown:
                        case Key.MediaNextTrack:
                            Zap(1);
                            return true;
                    }
                    return false;
                }
                switch (k)
                {
                    case Key.Up:
                    case Key.PageUp:
                    case Key.MediaPreviousTrack:
                        Zap(-1);
                        return true;
                    case Key.Down:
                    case Key.PageDown:
                    case Key.MediaNextTrack:
                        Zap(1);
                        return true;
                    case Key.Enter:
                    case Key.Space:
                    case Key.I:
                        _chrome.Show(true);
                        return true;
                    case Key.Right:
                        ShowPanel(false);
                        return true;
                    case Key.Left:
                        ShowPanel(true);
                        return true;
                }
                return false;
            }
            BumpPanel();
            bool inCats = _cats.IsKeyboardFocusWithin, inCh = _channels.IsKeyboardFocusWithin;
            if (inCats)
            {
                if (k == Key.Enter || k == Key.Space) { ApplyCat(_cats.SelectedItem as CatEntry); return true; }
                if (k == Key.Right) { FocusChannel(Math.Max(0, _channels.SelectedIndex)); return true; }
                if (k == Key.Left) return true;
            }
            else if (inCh)
            {
                if (k == Key.Enter || k == Key.Space) { Play(_channels.SelectedItem as Item, true); return true; }
                if (k == Key.Left) { FocusCat(); return true; }
                if (k == Key.Right) return true;
                if (k == Key.Up && _channels.SelectedIndex <= 0) { _search.Focus(); return true; }
                if (k == Key.F2 && _channels.SelectedItem is Item fit)
                {
                    bool on = Library.ToggleFav(fit);
                    Main.Toast(on ? "Agregado a Mis canales" : "Quitado de Mis canales");
                    return true;
                }
            }
            else if (_search.IsKeyboardFocusWithin)
            {
                if (k == Key.Down || k == Key.Enter) { FocusChannel(0); return true; }
            }
            return false;
        }

        private void Digit(int d)
        {
            if (_digitBuf.Length >= 4) _digitBuf = "";
            _digitBuf += d.ToString();
            _digits.Text = _digitBuf;
            _digitsBox.Visibility = Visibility.Visible;
            _digitTimer?.Stop();
            _digitTimer = UiThread.After(1400, () =>
            {
                _digitsBox.Visibility = Visibility.Collapsed;
                int n = J.ToInt(_digitBuf);
                _digitBuf = "";
                var s = Catalog.Snap;
                var it = s?.Live.FirstOrDefault(x => x.Num == n);
                if (it != null) Play(it, false);
                else Main.Toast("No existe el canal " + n);
            });
        }
    }

    /// <summary>Oculta un elemento cuando su texto está vacío.</summary>
    public sealed class EmptyToCollapsed : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
            string.IsNullOrEmpty(value as string) ? Visibility.Collapsed : Visibility.Visible;

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => System.Windows.Data.Binding.DoNothing;
    }
}
