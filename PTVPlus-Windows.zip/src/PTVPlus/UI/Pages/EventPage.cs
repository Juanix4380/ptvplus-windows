using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// Pantalla del partido: el video arriba con el canal que lo pasa (el mismo reproductor que
    /// la pantalla completa: al agrandarlo sigue sin cortes), los canales que lo transmiten,
    /// el marcador y las incidencias.
    /// </summary>
    public sealed class EventPage : Page
    {
        private Match _m;
        private readonly Button _videoBtn = new Button { Focusable = true, Cursor = Cursors.Hand, FocusVisualStyle = null };
        private readonly Border _slot = new Border { Background = Brushes.Black };
        private readonly Border _ring = new Border { BorderThickness = new Thickness(3), CornerRadius = new CornerRadius(19), Margin = new Thickness(-4), BorderBrush = Brushes.Transparent, IsHitTestVisible = false };
        private readonly TextBlock _chName = Ui.T("", 15.5, Brushes.White, FontWeights.Bold);
        private readonly TextBlock _chState = Ui.T("", 12.5, Ui.B("Accent"), FontWeights.SemiBold);
        private readonly Button _mute;
        private readonly WrapPanel _channels = new WrapPanel();
        private readonly StackPanel _info = new StackPanel();
        private readonly StackPanel _events = new StackPanel();
        private readonly Grid _left = new Grid();
        private readonly TextBlock _noChannel = Ui.T("", 17, Ui.B("Text2"), FontWeights.SemiBold);
        private DispatcherTimer _tick, _refresh;
        private const double StripH = 58;

        public override FrameworkElement VideoSlot => _m.Channels.Count > 0 ? _slot : null;

        public EventPage(Match m)
        {
            _m = m;
            Background = Ui.B("Bg");
            RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ---------- Arriba: regresar · liga · hora
            var head = new Grid { Margin = new Thickness(48, 22, 48, 14) };
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            head.Children.Add(Ui.Round(G.Back, () => Main.Back(), "Atrás"));
            var lg = new Image { Width = 34, Height = 34, Margin = new Thickness(18, 0, 10, 0), VerticalAlignment = VerticalAlignment.Center };
            RenderOptions.SetBitmapScalingMode(lg, BitmapScalingMode.Linear);
            if (!string.IsNullOrEmpty(m.LeagueLogo)) Images.Load(lg, m.LeagueLogo, 68);
            Grid.SetColumn(lg, 1);
            head.Children.Add(lg);
            var ht = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            ht.Children.Add(Ui.T(m.League.Name, 22, Ui.B("Text"), FontWeights.Bold));
            ht.Children.Add(Ui.T(m.Home.Name + "  vs  " + m.Away.Name, 13.5, Ui.B("Text3")));
            Grid.SetColumn(ht, 2);
            head.Children.Add(ht);
            Children.Add(head);

            // ---------- Cuerpo: video + canales | marcador + incidencias
            var body = new Grid { Margin = new Thickness(48, 0, 48, 30) };
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(62, GridUnitType.Star) });
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(28) });
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(38, GridUnitType.Star) });
            Grid.SetRow(body, 1);
            Children.Add(body);

            _mute = new Button { Style = Ui.S("Round"), Content = G.Volume, Width = 40, Height = 40, FontSize = 16, ToolTip = "Sonido", Focusable = false };
            _mute.Click += (s, e) => { var p = Playback.Main; if (p != null) { p.SetMute(!p.Muted); Paint(); } };
            var full = new Button { Style = Ui.S("Round"), Content = G.Full, Width = 40, Height = 40, FontSize = 16, ToolTip = "Pantalla completa", Focusable = false, Margin = new Thickness(8, 0, 0, 0) };
            full.Click += (s, e) => OpenFull();

            var leftStack = new StackPanel();
            // Video (clic = pantalla completa con el mismo reproductor)
            var card = new Grid();
            card.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            card.RowDefinitions.Add(new RowDefinition { Height = new GridLength(StripH) });
            var vb = new Border { CornerRadius = new CornerRadius(16, 16, 0, 0), Background = Brushes.Black, Child = _slot, ClipToBounds = true };
            card.Children.Add(vb);
            var strip = new Grid { Margin = new Thickness(14, 0, 10, 0) };
            strip.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            strip.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            strip.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var badge = Ui.Badge("● EN VIVO", Ui.Hex("#FFE0245E"));
            badge.VerticalAlignment = VerticalAlignment.Center;
            badge.Margin = new Thickness(0, 0, 12, 0);
            strip.Children.Add(badge);
            var st = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            _chName.TextTrimming = TextTrimming.CharacterEllipsis;
            st.Children.Add(_chName);
            st.Children.Add(_chState);
            Grid.SetColumn(st, 1);
            strip.Children.Add(st);
            var sb = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            sb.Children.Add(_mute);
            sb.Children.Add(full);
            Grid.SetColumn(sb, 2);
            strip.Children.Add(sb);
            var stripBox = new Border { CornerRadius = new CornerRadius(0, 0, 16, 16), Background = Ui.Gradient("#FF221838", "#FF150F24", 90), Child = strip };
            Grid.SetRow(stripBox, 1);
            card.Children.Add(stripBox);
            Grid.SetRowSpan(_ring, 2);
            card.Children.Add(_ring);
            _videoBtn.Template = PlainTemplate();
            _videoBtn.Content = card;
            _videoBtn.Click += (s, e) => OpenFull();
            _videoBtn.GotKeyboardFocus += (s, e) => _ring.BorderBrush = Brushes.White;
            _videoBtn.LostKeyboardFocus += (s, e) => _ring.BorderBrush = Brushes.Transparent;
            _videoBtn.MouseEnter += (s, e) => { if (!_videoBtn.IsKeyboardFocused) _ring.BorderBrush = Ui.B("Accent"); };
            _videoBtn.MouseLeave += (s, e) => { if (!_videoBtn.IsKeyboardFocused) _ring.BorderBrush = Brushes.Transparent; };
            leftStack.Children.Add(_videoBtn);

            // Sin canal todavía
            _noChannel.TextWrapping = TextWrapping.Wrap;
            _noChannel.Margin = new Thickness(0, 10, 0, 0);
            leftStack.Children.Add(_noChannel);

            var ct = Ui.T("Canales que lo transmiten", 18, Ui.B("Text"), FontWeights.Bold);
            ct.Margin = new Thickness(2, 22, 0, 12);
            leftStack.Children.Add(ct);
            leftStack.Children.Add(_channels);
            var leftScroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Focusable = false, Content = leftStack };
            body.Children.Add(leftScroll);

            // Marcador + incidencias
            var right = new Border { CornerRadius = new CornerRadius(20), Background = Ui.Gradient("#FF1E1631", "#FF120D1C", 90), Padding = new Thickness(24) };
            var rs = new DockPanel();
            DockPanel.SetDock(_info, Dock.Top);
            rs.Children.Add(_info);
            var evScroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Focusable = false, Content = _events, Margin = new Thickness(0, 16, 0, 0) };
            rs.Children.Add(evScroll);
            right.Child = rs;
            Grid.SetColumn(right, 2);
            body.Children.Add(right);

            body.SizeChanged += (s, e) => Layout(e.NewSize.Width);
            BuildChannels();
            BuildInfo();
        }

        private static ControlTemplate PlainTemplate()
        {
            var t = new ControlTemplate(typeof(Button));
            t.VisualTree = new FrameworkElementFactory(typeof(ContentPresenter));
            return t;
        }

        private void Layout(double bodyW)
        {
            double leftW = Math.Max(320, (bodyW - 28) * 0.62);
            double videoH = Math.Round(leftW * 9 / 16);
            double maxH = Math.Max(200, ActualHeight - 300);
            if (videoH > maxH) { videoH = maxH; }
            _slot.Width = Math.Round(Math.Min(leftW, videoH * 16 / 9));
            _slot.Height = videoH;
            _videoBtn.Width = _slot.Width;
            _videoBtn.HorizontalAlignment = HorizontalAlignment.Left;
        }

        // ------------------------------------------------------- ciclo de vida

        public override void OnShow()
        {
            Playback.Changed += Paint;
            _tick = UiThread.Every(1000, Paint);
            _refresh = UiThread.Every(60000, Refresh);
            if (_m.Channels.Count == 0)
            {
                _videoBtn.Visibility = Visibility.Collapsed;
                _noChannel.Text = _m.Finished ? "Este partido ya terminó." : "Todavía no hay un canal con este partido. Vuelve a entrar un poco antes de que empiece.";
            }
            else
            {
                // Si regresas de pantalla completa, el mismo canal sigue sin recargar.
                var cur = Playback.Current;
                bool playingOurs = cur != null && cur.IsLive && cur.Channel != null && _m.Channels.Any(c => c.Id == cur.Channel.Id);
                if (!playingOurs) Playback.PlayChannel(_m.Channels[0], false);
                else Playback.Main?.SetMute(false);
            }
            LoadEvents();
            Paint();
        }

        public override void OnHide()
        {
            Playback.Changed -= Paint;
            _tick?.Stop();
            _refresh?.Stop();
        }

        public override void FocusFirst()
        {
            if (_videoBtn.Visibility == Visibility.Visible) _videoBtn.Focus();
            else
            {
                foreach (var c in _channels.Children) if (c is Button b) { b.Focus(); return; }
            }
        }

        public override bool OnKey(KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Up: Move(FocusNavigationDirection.Up); return true;
                case Key.Down: Move(FocusNavigationDirection.Down); return true;
                case Key.Left: Move(FocusNavigationDirection.Left); return true;
                case Key.Right: Move(FocusNavigationDirection.Right); return true;
                case Key.F: OpenFull(); return true;
                case Key.M: { var p = Playback.Main; if (p != null) { p.SetMute(!p.Muted); Paint(); } return true; }
            }
            return false;
        }

        /// <summary>Pantalla completa con el MISMO reproductor (sin cortes ni recarga).</summary>
        private void OpenFull()
        {
            var cur = Playback.Current;
            var ch = cur?.Channel ?? _m.Channels.FirstOrDefault();
            if (ch == null) return;
            Main.Go(new LivePage(ch.Id, null));
        }

        // ------------------------------------------------------------- canales

        private void BuildChannels()
        {
            _channels.Children.Clear();
            var cur = Playback.Current?.Channel;
            foreach (var ch in _m.Channels)
            {
                var it = ch;
                var g = new StackPanel { Orientation = Orientation.Horizontal };
                var box = new Border { Width = 54, Height = 36, CornerRadius = new CornerRadius(8), Background = Ui.Hex("#33000000"), Margin = new Thickness(0, 0, 12, 0) };
                var img = new Image { Stretch = Stretch.Uniform, Margin = new Thickness(4) };
                RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.Linear);
                if (!string.IsNullOrEmpty(ch.Icon)) Images.Load(img, ch.Icon, 120);
                box.Child = img;
                g.Children.Add(box);
                var texts = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                var n = Ui.T(ch.Name, 14.5, Brushes.White, FontWeights.SemiBold);
                n.TextTrimming = TextTrimming.CharacterEllipsis;
                n.MaxWidth = 260;
                texts.Children.Add(n);
                if (ch.Num > 0) texts.Children.Add(Ui.T("Canal " + ch.Num, 12, Ui.B("Text3")));
                g.Children.Add(texts);
                bool on = cur != null && cur.Id == ch.Id;
                var b = new Button { Style = Ui.S("RowBtn"), Content = g, Margin = new Thickness(0, 0, 12, 12), Padding = new Thickness(12, 10, 16, 10), Tag = ch.Id };
                if (on) b.Background = Ui.Hex("#FF3B2D63");
                b.Click += (s, e) =>
                {
                    var c = Playback.Current?.Channel;
                    if (c != null && c.Id == it.Id) { OpenFull(); return; }
                    Playback.PlayChannel(it, false);
                    BuildChannels();
                };
                _channels.Children.Add(b);
            }
        }

        // ------------------------------------------------------------ marcador

        private void BuildInfo()
        {
            _info.Children.Clear();
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.Children.Add(TeamBox(_m.Home));
            var mid = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 10, 0) };
            bool score = !_m.Panel && _m.State != "pre";
            var big = Ui.T(score ? _m.Home.Score + " - " + _m.Away.Score : EventsPage.TimeText(_m), score ? 34 : 24, Brushes.White, FontWeights.Bold);
            big.HorizontalAlignment = HorizontalAlignment.Center;
            mid.Children.Add(big);
            string st = _m.Live ? (_m.Panel ? "EN VIVO" : (_m.Detail.Length > 0 ? _m.Detail : "EN VIVO")) : _m.Finished ? "Finalizado" : (_m.Start > 0 ? DateTimeOffset.FromUnixTimeMilliseconds(_m.Start).LocalDateTime.ToString("dddd d 'de' MMMM", new System.Globalization.CultureInfo("es-MX")) : "");
            var stt = Ui.T(st, 13, _m.Live ? Ui.Hex("#FFFF6B93") : Ui.B("Text3"), FontWeights.SemiBold);
            stt.HorizontalAlignment = HorizontalAlignment.Center;
            stt.Margin = new Thickness(0, 4, 0, 0);
            mid.Children.Add(stt);
            Grid.SetColumn(mid, 1);
            g.Children.Add(mid);
            var away = TeamBox(_m.Away);
            Grid.SetColumn(away, 2);
            g.Children.Add(away);
            _info.Children.Add(g);
            if (_m.Tv.Count > 0)
            {
                var tv = Ui.T("Transmite: " + string.Join(", ", _m.Tv), 12.5, Ui.B("Text3"));
                tv.TextWrapping = TextWrapping.Wrap;
                tv.HorizontalAlignment = HorizontalAlignment.Center;
                tv.TextAlignment = TextAlignment.Center;
                tv.Margin = new Thickness(0, 14, 0, 0);
                _info.Children.Add(tv);
            }
        }

        private static FrameworkElement TeamBox(Team t)
        {
            var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            var box = new Border { Width = 76, Height = 76, CornerRadius = new CornerRadius(38), Background = Ui.Hex("#22FFFFFF"), HorizontalAlignment = HorizontalAlignment.Center };
            if (!string.IsNullOrEmpty(t.Logo))
            {
                var img = new Image { Width = 56, Height = 56, Stretch = Stretch.Uniform };
                RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.Linear);
                Images.Load(img, t.Logo, 112);
                box.Child = img;
            }
            else box.Child = new TextBlock { Text = TextUtil.Initials(t.Name), Foreground = Brushes.White, FontSize = 22, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            sp.Children.Add(box);
            var n = Ui.T(t.Name, 15, Brushes.White, FontWeights.SemiBold);
            n.TextWrapping = TextWrapping.Wrap;
            n.TextAlignment = TextAlignment.Center;
            n.HorizontalAlignment = HorizontalAlignment.Center;
            n.MaxWidth = 170;
            n.Margin = new Thickness(0, 10, 0, 0);
            sp.Children.Add(n);
            return sp;
        }

        private async void LoadEvents()
        {
            _events.Children.Clear();
            if (_m.Panel) return;
            List<KeyEvent> list;
            try { list = await Sports.Summary(_m); }
            catch { return; }
            if (Main.Current != this) return;
            _events.Children.Clear();
            if (list.Count == 0) return;
            var t = Ui.T("Incidencias", 16, Ui.B("Text"), FontWeights.Bold);
            t.Margin = new Thickness(0, 0, 0, 10);
            _events.Children.Add(t);
            foreach (var e in list.Where(x => x.Kind != "other").Reverse())
            {
                var row = new Grid { Margin = new Thickness(0, 0, 0, 8) };
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(54) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                row.Children.Add(Ui.T(e.Minute, 13, Ui.B("Accent"), FontWeights.Bold));
                string icon = e.Kind == "goal" ? "⚽  " : e.Kind == "own" ? "⚽  " : e.Kind == "yellow" ? "🟨  " : e.Kind == "red" ? "🟥  " : e.Kind == "sub" ? "⇄  " : "";
                var tx = Ui.T(icon + e.Text + (e.Kind == "period" ? "" : e.Home ? "  ·  " + _m.Home.Short : "  ·  " + _m.Away.Short), 13.5, Ui.B("Text2"));
                tx.TextWrapping = TextWrapping.Wrap;
                Grid.SetColumn(tx, 1);
                row.Children.Add(tx);
                _events.Children.Add(row);
            }
        }

        /// <summary>Marcador al día cada minuto (partidos de ESPN).</summary>
        private async void Refresh()
        {
            if (_m.Panel || _m.Finished) return;
            try
            {
                var day = _m.Start > 0 ? DateTimeOffset.FromUnixTimeMilliseconds(_m.Start).LocalDateTime.Date : DateTime.Today;
                var list = await Sports.Matches(day, true);
                var upd = list.FirstOrDefault(x => x.Id == _m.Id && x.League.Slug == _m.League.Slug);
                if (upd == null || Main.Current != this) return;
                var chans = _m.Channels;
                _m = upd.WithChannels(chans);
                BuildInfo();
                LoadEvents();
            }
            catch { }
        }

        // ------------------------------------------------------------- pintar

        private void Paint()
        {
            var cur = Playback.Current;
            var ch = cur?.Channel;
            _chName.Text = ch == null ? "" : (ch.Num > 0 ? ch.Num + "  " : "") + ch.Name;
            var p = Playback.Main;
            _mute.Content = p != null && p.Muted ? G.Mute : G.Volume;
            if (Playback.LastError != null) _chState.Text = Playback.LastError;
            else if (Playback.Notice != null) _chState.Text = Playback.Notice;
            else if (p != null && cur != null && (p.Buffering || (p.CoreIdle && p.Position <= 0))) _chState.Text = "Cargando…";
            else _chState.Text = "Clic en el video: pantalla completa";
            // Marca el canal que suena
            foreach (var c in _channels.Children)
                if (c is Button b)
                {
                    bool on = ch != null && Equals(b.Tag, ch.Id);
                    var want = on ? Ui.Hex("#FF3B2D63") : null;
                    if (on && b.ReadLocalValue(Control.BackgroundProperty) == DependencyProperty.UnsetValue) b.Background = want;
                    else if (!on && b.ReadLocalValue(Control.BackgroundProperty) != DependencyProperty.UnsetValue) b.ClearValue(Control.BackgroundProperty);
                }
        }
    }
}
