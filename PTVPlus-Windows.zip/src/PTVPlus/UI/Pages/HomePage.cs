using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// Inicio (modo TV): TV en vivo sonando en la vista previa, destacados que cambian solos,
    /// accesos grandes y filas (Continuar viendo, recién llegadas, Mi lista, mejor calificadas).
    /// </summary>
    public sealed class HomePage : Page
    {
        private const double Edge = 48;
        private readonly Grid _ambientHost = new Grid { IsHitTestVisible = false };
        private readonly ScrollViewer _scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Focusable = false, PanningMode = PanningMode.VerticalOnly };
        private readonly StackPanel _body = new StackPanel();
        private readonly Grid _top = new Grid();
        private readonly Border _topBg = new Border { Background = Ui.Gradient("#F20B0812", "#000B0812", 90) };
        private readonly Grid _main = new Grid();
        private readonly Button _liveBtn = new Button { Style = null, Focusable = true, Cursor = Cursors.Hand, FocusVisualStyle = null };
        private readonly Border _slot = new Border { Background = Brushes.Black };
        private readonly Button _feature = new Button();
        private readonly Grid _featureFrame = new Grid();
        private readonly Image _featureImg = new Image { Stretch = Stretch.UniformToFill };
        private readonly TextBlock _featureTitle = Ui.T("", 16, Brushes.White, FontWeights.Bold);
        private readonly StackPanel _dots = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 0) };
        private readonly StackPanel _info = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        private readonly TextBlock _kicker = Ui.T("", 13, Ui.B("Accent"), FontWeights.Bold);
        private readonly TextBlock _title = Ui.T("", 32, Ui.B("Text"), FontWeights.Bold);
        private readonly TextBlock _meta = Ui.T("", 14.5, Ui.B("Text2"));
        private readonly TextBlock _plot = Ui.T("", 15, Ui.B("Text2"));
        private readonly UniformGrid _tiles = new UniformGrid { Rows = 1 };
        private readonly StackPanel _rounds = new StackPanel { Orientation = Orientation.Horizontal };
        private readonly StackPanel _rows = new StackPanel();
        private readonly TextBlock _clock = Ui.T("", 22, Ui.B("Text"), FontWeights.SemiBold);
        private readonly TextBlock _date = Ui.T("", 12.5, Ui.B("Text3"));
        private readonly Image _avatar = new Image { Width = 40, Height = 40, Stretch = Stretch.UniformToFill };
        private readonly TextBlock _empty = Ui.T("", 16, Ui.B("Text2"));

        // Vista previa en vivo: el video arriba y la franja con canal / guía / sonido abajo (sin capa
        // encima del video: la página se dibuja más ligera).
        private const double StripH = 60;
        private readonly Border _ovRing = new Border { BorderThickness = new Thickness(3), CornerRadius = new CornerRadius(19), Margin = new Thickness(-4), BorderBrush = Brushes.Transparent, IsHitTestVisible = false };
        private readonly TextBlock _ovName = Ui.T("", 15.5, Brushes.White, FontWeights.Bold);
        private readonly TextBlock _ovNow = Ui.T("", 12.5, Ui.Hex("#FFD9D2E8"));
        private readonly TextBlock _ovState = Ui.T("", 12.5, Ui.B("Accent"), FontWeights.SemiBold);
        private readonly Button _mute;

        private List<Item> _featured = new List<Item>();
        private int _featIdx;
        private int _builtVersion = -1;
        private int _builtLib = -1;
        private DispatcherTimer _rotate, _clockTimer, _pull, _paint;
        private Item _previewItem;
        private static readonly Dictionary<string, string> Plots = new Dictionary<string, string>();

        public override FrameworkElement VideoSlot => _slot;
        private double TopHeight => _top.ActualHeight + _top.Margin.Top + _top.Margin.Bottom;
        public override double VideoTopLimit => TopHeight;

        public HomePage()
        {
            Background = Ui.B("Bg");
            Children.Add(_ambientHost);
            Children.Add(new Border { Background = Ui.Gradient("#660B0812", "#FF0B0812", 90), IsHitTestVisible = false });

            // ---------- Barra de arriba
            BuildTop();

            // ---------- Principal: TV en vivo + destacado + información
            _main.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            _main.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            _main.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _main.Margin = new Thickness(Edge, 8, Edge, 0);

            _mute = new Button { Style = Ui.S("Round"), Content = G.Mute, Width = 40, Height = 40, FontSize = 16, ToolTip = "Sonido", Focusable = false };
            _mute.Click += (s, e) => ToggleSound();
            var liveCard = new Grid();
            liveCard.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            liveCard.RowDefinitions.Add(new RowDefinition { Height = new GridLength(StripH) });
            var liveBorder = new Border { CornerRadius = new CornerRadius(16, 16, 0, 0), Background = Brushes.Black, Child = _slot, ClipToBounds = true };
            liveCard.Children.Add(liveBorder);
            var strip = BuildStrip();
            Grid.SetRow(strip, 1);
            liveCard.Children.Add(strip);
            Grid.SetRowSpan(_ovRing, 2);
            liveCard.Children.Add(_ovRing);
            _liveBtn.Template = PlainTemplate();
            _liveBtn.Content = liveCard;
            _liveBtn.Click += (s, e) => OpenLive();
            _liveBtn.GotKeyboardFocus += (s, e) => { _ovRing.BorderBrush = Brushes.White; ScrollTop(); };
            _liveBtn.LostKeyboardFocus += (s, e) => _ovRing.BorderBrush = Brushes.Transparent;
            _liveBtn.MouseEnter += (s, e) => { if (!_liveBtn.IsKeyboardFocused) _ovRing.BorderBrush = Ui.B("Accent"); };
            _liveBtn.MouseLeave += (s, e) => { if (!_liveBtn.IsKeyboardFocused) _ovRing.BorderBrush = Brushes.Transparent; };
            _main.Children.Add(_liveBtn);

            _feature.Style = Ui.S("CardBtn");
            _feature.Margin = new Thickness(18, 0, 0, 0);
            var fcol = new StackPanel();
            _featureFrame.Children.Add(new Border { Background = Ui.Gradient("#FF2A1E46", "#FF140F22", 90) });
            RenderOptions.SetBitmapScalingMode(_featureImg, BitmapScalingMode.HighQuality);
            _featureFrame.Children.Add(_featureImg);
            _featureFrame.Children.Add(new Border { Background = Ui.Gradient("#00000000", "#E6000000", 90), VerticalAlignment = VerticalAlignment.Bottom, Height = 110 });
            _featureTitle.VerticalAlignment = VerticalAlignment.Bottom;
            _featureTitle.Margin = new Thickness(12, 0, 12, 12);
            _featureTitle.TextWrapping = TextWrapping.Wrap;
            _featureTitle.MaxHeight = 44;
            _featureFrame.Children.Add(_featureTitle);
            fcol.Children.Add(_featureFrame);
            fcol.Children.Add(_dots);
            _feature.Content = fcol;
            _feature.Click += (s, e) => OpenFeatured();
            _feature.GotKeyboardFocus += (s, e) => ScrollTop();
            Grid.SetColumn(_feature, 1);
            _main.Children.Add(_feature);

            _info.Margin = new Thickness(30, 0, 0, 0);
            _info.Children.Add(_kicker);
            _title.TextWrapping = TextWrapping.Wrap;
            _title.MaxHeight = 90;
            _title.Margin = new Thickness(0, 6, 0, 8);
            _info.Children.Add(_title);
            _info.Children.Add(_meta);
            _plot.TextWrapping = TextWrapping.Wrap;
            _plot.MaxHeight = 120;
            _plot.Margin = new Thickness(0, 12, 0, 0);
            _info.Children.Add(_plot);
            var hint = Ui.T("Enter o clic en el póster para ver la ficha", 12.5, Ui.B("Text3"));
            hint.Margin = new Thickness(0, 14, 0, 0);
            _info.Children.Add(hint);
            Grid.SetColumn(_info, 2);
            _main.Children.Add(_info);
            _body.Children.Add(_main);

            // ---------- Accesos grandes
            var tilesRow = new Grid { Margin = new Thickness(Edge, 26, Edge, 8) };
            tilesRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            tilesRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            tilesRow.Children.Add(_tiles);
            Grid.SetColumn(_rounds, 1);
            _rounds.Margin = new Thickness(10, 0, 0, 0);
            tilesRow.Children.Add(_rounds);
            _body.Children.Add(tilesRow);
            BuildTiles();

            _empty.Margin = new Thickness(Edge, 20, Edge, 0);
            _body.Children.Add(_empty);
            _rows.Margin = new Thickness(0, 14, 0, 40);
            _body.Children.Add(_rows);

            _scroll.Content = _body;
            Grid.SetRow(_scroll, 0);
            Children.Add(_scroll);
            Children.Add(_topBg);
            Children.Add(_top);
            _topBg.VerticalAlignment = VerticalAlignment.Top;
            _top.SizeChanged += (s, e) =>
            {
                _topBg.Height = TopHeight + 20;
                _body.Margin = new Thickness(0, TopHeight, 0, 0);
                Layout();
            };

            SizeChanged += (s, e) => Layout();
            _scroll.ScrollChanged += (s, e) => { };
        }

        private static ControlTemplate PlainTemplate()
        {
            var t = new ControlTemplate(typeof(Button));
            t.VisualTree = new FrameworkElementFactory(typeof(ContentPresenter));
            return t;
        }

        private void ScrollTop()
        {
            if (_scroll.VerticalOffset > 0) _scroll.ScrollToTop();
        }

        // ------------------------------------------------------------- arriba

        private void BuildTop()
        {
            _top.VerticalAlignment = VerticalAlignment.Top;
            _top.Margin = new Thickness(Edge, 18, Edge, 14);
            _top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            _top.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var brand = new StackPanel { Orientation = Orientation.Horizontal };
            var logo = new Image { Source = Images.Asset("logo_mark.png"), Width = 42, Height = 42 };
            RenderOptions.SetBitmapScalingMode(logo, BitmapScalingMode.HighQuality);
            brand.Children.Add(logo);
            var name = Ui.T("PTV PLUS", 22, Ui.B("Text"), FontWeights.Bold);
            name.VerticalAlignment = VerticalAlignment.Center;
            name.Margin = new Thickness(12, 0, 0, 0);
            brand.Children.Add(name);
            _top.Children.Add(brand);

            var right = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            var search = Ui.Pill("Buscar películas, series y canales", () => Main.Go(new CatalogPage(Scopes.All, null, true)), G.Search);
            search.Margin = new Thickness(0, 0, 22, 0);
            right.Children.Add(search);
            var clockBox = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 18, 0) };
            _clock.HorizontalAlignment = HorizontalAlignment.Right;
            _date.HorizontalAlignment = HorizontalAlignment.Right;
            clockBox.Children.Add(_clock);
            clockBox.Children.Add(_date);
            right.Children.Add(clockBox);
            var av = new Button { Style = Ui.S("Round"), Width = 46, Height = 46, ToolTip = "Cambiar de perfil", Margin = new Thickness(0, 0, 10, 0) };
            _avatar.Clip = new EllipseGeometry(new Point(20, 20), 20, 20);
            av.Content = _avatar;
            av.Click += (s, e) => { Playback.Stop(); Prefs.S.ProfileChosen = false; Prefs.Save(); Main.Reset(new ProfilesPage()); };
            right.Children.Add(av);
            right.Children.Add(Ui.Round(G.Settings, () => Main.Go(new SettingsPage()), "Configuración"));
            Grid.SetColumn(right, 2);
            _top.Children.Add(right);
        }

        // --------------------------------------------------------- accesos

        private void BuildTiles()
        {
            Tile("TV en vivo", G.Tv, "#FF7B4FD1", "#FF3A1F7A", OpenLive);
            Tile("Películas", G.Movie, "#FF8E3FB8", "#FF451C66", () => Main.Go(new CatalogPage(Scopes.Movies)));
            Tile("Series", G.Video, "#FF5E54D6", "#FF2A2470", () => Main.Go(new CatalogPage(Scopes.Series)));
            Tile("Anime", G.Star, "#FFB04A8C", "#FF5A1F48", () => Main.Go(new CatalogPage(Scopes.Anime)));
            Tile("Niños", G.Smile, "#FF3D8FD1", "#FF1C3F70", () => Main.Go(new CatalogPage(Scopes.Kids)));
            Tile("Especial", G.StarFill, "#FFC08A2E", "#FF5C3D10", () => Main.Go(new CatalogPage(Scopes.Special)));
            RoundTile("Todo", G.All, () => Main.Go(new CatalogPage(Scopes.All)));
            RoundTile("Multi", G.Tiles, () => Main.Go(new MultiPage()));
            RoundTile("Eventos", G.Calendar, () => Main.Go(new EventsPage()));
            RoundTile("Mi lista", G.Heart, () => Main.Go(new CatalogPage(Scopes.All, CatalogPage.KeyFav)));
        }

        private void Tile(string label, string glyph, string c1, string c2, Action go)
        {
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            sp.Children.Add(Ui.Icon(glyph, 30));
            var t = Ui.T(label, 15, Brushes.White, FontWeights.Bold);
            t.HorizontalAlignment = HorizontalAlignment.Center;
            t.Margin = new Thickness(0, 10, 0, 0);
            sp.Children.Add(t);
            var b = new Button { Style = Ui.S("TileBtn"), Content = sp, Background = Ui.Gradient(c1, c2, 45), Height = 104, Margin = new Thickness(0, 0, 14, 0) };
            b.Click += (s, e) => go();
            _tiles.Children.Add(b);
        }

        private void RoundTile(string label, string glyph, Action go)
        {
            var sp = new StackPanel { Margin = new Thickness(6, 0, 6, 0) };
            var b = Ui.Round(glyph, go, label);
            b.Width = 60;
            b.Height = 60;
            b.FontSize = 22;
            sp.Children.Add(b);
            var t = Ui.T(label, 12, Ui.B("Text2"), FontWeights.SemiBold);
            t.HorizontalAlignment = HorizontalAlignment.Center;
            t.Margin = new Thickness(0, 6, 0, 0);
            sp.Children.Add(t);
            _rounds.Children.Add(sp);
        }

        // ------------------------------------------------------- franja en vivo

        private Border BuildStrip()
        {
            var g = new Grid { Margin = new Thickness(12, 0, 8, 0) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var badge = Ui.Badge("● EN VIVO", Ui.Hex("#FFE0245E"));
            badge.VerticalAlignment = VerticalAlignment.Center;
            badge.Margin = new Thickness(0, 0, 12, 0);
            g.Children.Add(badge);
            var texts = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            _ovName.TextTrimming = TextTrimming.CharacterEllipsis;
            _ovNow.TextTrimming = TextTrimming.CharacterEllipsis;
            _ovState.TextTrimming = TextTrimming.CharacterEllipsis;
            texts.Children.Add(_ovName);
            var sub = new Grid();
            sub.Children.Add(_ovNow);
            sub.Children.Add(_ovState);
            texts.Children.Add(sub);
            Grid.SetColumn(texts, 1);
            g.Children.Add(texts);
            _mute.VerticalAlignment = VerticalAlignment.Center;
            _mute.Margin = new Thickness(8, 0, 0, 0);
            Grid.SetColumn(_mute, 2);
            g.Children.Add(_mute);
            return new Border
            {
                CornerRadius = new CornerRadius(0, 0, 16, 16), Background = Ui.Gradient("#FF221838", "#FF150F24", 90), Child = g
            };
        }

        // -------------------------------------------------------- ciclo de vida

        public override void OnShow()
        {
            Catalog.Changed += OnCatalog;
            Library.Changed += OnLibrary;
            Playback.Changed += PaintLive;
            _avatar.Source = Images.Avatar(Profiles.Current()?.Avatar ?? 0);
            Tick();
            _clockTimer = UiThread.Every(15000, Tick);
            _rotate = UiThread.Every(7000, () => ShowFeature(_featIdx + 1));
            _pull = UiThread.Every(60000, () => { var t = HistorySync.PullAsync(); });
            _paint = UiThread.Every(1000, PaintLive);
            Catalog.Ensure();
            OnCatalog();
            StartPreview();
        }

        public override void OnHide()
        {
            Catalog.Changed -= OnCatalog;
            Library.Changed -= OnLibrary;
            Playback.Changed -= PaintLive;
            _clockTimer?.Stop();
            _rotate?.Stop();
            _pull?.Stop();
            _paint?.Stop();
        }

        public override void FocusFirst()
        {
            var first = _tiles.Children.OfType<Button>().FirstOrDefault();
            first?.Focus();
        }

        private void Tick()
        {
            var now = DateTime.Now;
            var es = new CultureInfo("es-MX");
            _clock.Text = now.ToString("h:mm tt", es);
            _date.Text = now.ToString("dddd d 'de' MMMM", es);
        }

        private void Layout()
        {
            double w = ActualWidth, h = ActualHeight;
            if (w <= 0 || h <= 0) return;
            double avail = w - Edge * 2;
            // El inicio es solo la parte grande de arriba (vista previa + destacado + información) y los
            // accesos: la vista previa ocupa todo lo que deja libre la pantalla.
            double tilesH = Math.Max(86, Math.Min(124, h * 0.12));
            double top = TopHeight > 0 ? TopHeight : 80;
            double mainH = Math.Max(StripH + 200, Math.Min(760, h - top - tilesH - 26 - 8 - 8 - 34));
            double infoW = avail >= 1500 ? 400 : avail >= 1250 ? 300 : 0;
            double featW = mainH * 0.62;
            double liveW = (mainH - StripH) * 16 / 9;
            for (int i = 0; i < 3; i++)
            {
                double maxLive = avail - featW - 18 - (infoW > 0 ? infoW + 30 : 0);
                if (liveW <= maxLive) break;
                liveW = Math.Max(320, maxLive);
                mainH = liveW * 9 / 16 + StripH;
                featW = mainH * 0.62;
            }
            _liveBtn.Width = liveW;
            _liveBtn.Height = mainH;
            _slot.Width = liveW;
            _slot.Height = mainH - StripH;
            _featureFrame.Width = featW;
            _featureFrame.Height = mainH - 24;
            _featureFrame.Clip = Ui.Rounded(featW, mainH - 24, 14);
            _featureImg.Width = featW;
            _featureImg.Height = mainH - 24;
            _feature.Tag = mainH - 18;
            _info.Visibility = infoW > 0 && avail - liveW - featW - 18 > 240 ? Visibility.Visible : Visibility.Collapsed;
            _title.FontSize = h > 900 ? 34 : 28;
            _plot.MaxHeight = mainH > 420 ? 160 : 100;
            foreach (var b in _tiles.Children.OfType<Button>()) b.Height = tilesH;
        }

        // ---------------------------------------------------------- vista previa

        private void StartPreview()
        {
            var s = Catalog.Snap;
            if (s == null || Playback.Main == null) return;
            var cur = Playback.Current;
            if (cur != null && cur.IsLive && cur.Channel != null)
            {
                _previewItem = cur.Channel;
                PaintLive();
                return;
            }
            Item it = s.Find(Kind.Live, Prefs.S.LastLiveId);
            if (it == null) it = Library.RecentLive().Select(id => s.Find(Kind.Live, id)).FirstOrDefault(x => x != null);
            if (it == null) it = s.Live.FirstOrDefault(x => !s.IsAdultItem(x));
            if (it == null) return;
            _previewItem = it;
            Playback.PlayChannel(it, preview: true);
            PaintLive();
        }

        private void PaintLive()
        {
            // El motor de video pudo tardar en arrancar: la vista previa empieza en cuanto esté.
            if (_previewItem == null && Playback.Main != null && Catalog.Snap != null)
            {
                StartPreview();
                if (_previewItem != null) return;
            }
            var cur = Playback.Current;
            var it = cur?.Channel ?? _previewItem;
            _ovName.Text = it == null ? "TV en vivo" : (it.Num > 0 ? it.Num + "  " : "") + it.Name;
            var m = Playback.Main;
            bool muted = m == null || m.Muted;
            _mute.Content = muted ? G.Mute : G.Volume;
            if (Playback.LastError != null) _ovState.Text = Playback.LastError;
            else if (Playback.Notice != null) _ovState.Text = Playback.Notice;
            else if (m != null && (m.Buffering || (m.CoreIdle && m.Position <= 0 && cur != null))) _ovState.Text = "Cargando…";
            else _ovState.Text = "";
            _ovNow.Visibility = _ovState.Text.Length > 0 ? Visibility.Collapsed : Visibility.Visible;
            if (it != null) LoadNow(it);
        }

        private int _nowFor;
        private long _nowAt;

        private async void LoadNow(Item it)
        {
            if (_nowFor == it.Id && J.NowMs() - _nowAt < 120000) return;
            _nowFor = it.Id;
            _nowAt = J.NowMs();
            try
            {
                var list = await Xtream.ShortEpg(Prefs.Account(), it.Id, 2);
                long now = J.NowMs();
                var cur = list.FirstOrDefault(e => e.Start <= now && (e.End == 0 || e.End > now)) ?? list.FirstOrDefault();
                _ovNow.Text = cur != null && cur.Title.Length > 0 ? "Ahora: " + cur.Title : "";
            }
            catch { _ovNow.Text = ""; }
        }

        private void ToggleSound()
        {
            var m = Playback.Main;
            if (m == null) return;
            m.SetMute(!m.Muted);
            PaintLive();
        }

        private void OpenLive()
        {
            var cur = Playback.Current;
            int id = cur != null && cur.IsLive && cur.Channel != null ? cur.Channel.Id : (_previewItem?.Id ?? 0);
            Main.Go(new LivePage(id == 0 ? null : (int?)id, null));
        }

        // ------------------------------------------------------------- datos

        private void OnCatalog()
        {
            var s = Catalog.Snap;
            if (s == null)
            {
                _empty.Text = Catalog.Error ?? (string.IsNullOrEmpty(Catalog.Status) ? "Cargando contenido…" : Catalog.Status);
                return;
            }
            _empty.Text = "";
            if (_builtVersion != Catalog.Version)
            {
                _builtVersion = Catalog.Version;
                _featured = PickFeatured(s);
                BuildDots();
                ShowFeature(0);
                if (_previewItem == null) StartPreview();
                if (_featured.Count > 0) SetAmbient(_featured[0]);
            }
            BuildRows(s);
        }

        private void OnLibrary()
        {
            var s = Catalog.Snap;
            if (s != null) BuildRows(s);
        }

        private bool Kids => Profiles.Current()?.Kids ?? false;

        private List<Item> PickFeatured(Snapshot s)
        {
            Func<IEnumerable<Item>, List<Item>> good = list =>
            {
                var l = list.Take(150).Where(i => !string.IsNullOrEmpty(i.Icon) && i.Rating >= 6f && i.Rating <= 10f).ToList();
                return l.Count > 0 ? l : list.Take(60).Where(i => !string.IsNullOrEmpty(i.Icon)).ToList();
            };
            IEnumerable<Item> movies = s.RecentMovies, series = s.RecentSeries;
            if (Kids)
            {
                var kidsItems = new HashSet<string>(Scopes.Items(s, Scopes.Kids, true).Select(i => i.Key));
                movies = movies.Where(i => kidsItems.Contains(i.Key));
                series = series.Where(i => kidsItems.Contains(i.Key));
            }
            var m = good(movies);
            var se = good(series);
            var outList = new List<Item>();
            for (int i = 0; outList.Count < 10 && (i < m.Count || i < se.Count); i++)
            {
                if (i < se.Count) outList.Add(se[i]);
                if (i < m.Count && outList.Count < 10) outList.Add(m[i]);
            }
            return outList;
        }

        private void BuildDots()
        {
            _dots.Children.Clear();
            for (int i = 0; i < _featured.Count; i++)
                _dots.Children.Add(new Border { Width = 7, Height = 7, CornerRadius = new CornerRadius(4), Margin = new Thickness(3, 0, 3, 0), Background = Ui.B("Text3") });
        }

        private void ShowFeature(int idx)
        {
            if (_featured.Count == 0)
            {
                _title.Text = "";
                return;
            }
            _featIdx = ((idx % _featured.Count) + _featured.Count) % _featured.Count;
            var it = _featured[_featIdx];
            Images.Load(_featureImg, it.Icon, 420);
            _featureTitle.Text = it.Title;
            var s = Catalog.Snap;
            string cat = s?.CategoryOf(it.Kind, it.CatId)?.Name ?? "";
            _kicker.Text = ((it.Kind == Kind.Movie ? "PELÍCULA" : "SERIE") + (cat.Length > 0 ? " · " + cat.ToUpperInvariant() : ""));
            _title.Text = it.Title;
            var meta = new List<string>();
            if (it.YearOrName.Length > 0) meta.Add(it.YearOrName);
            if (it.Rating > 0) meta.Add(it.RatingText);
            _meta.Text = string.Join("   ·   ", meta);
            for (int i = 0; i < _dots.Children.Count; i++)
                ((Border)_dots.Children[i]).Background = i == _featIdx ? Ui.B("Accent") : Ui.B("Text3");
            string key = it.Key;
            string plot;
            if (Plots.TryGetValue(key, out plot)) _plot.Text = plot;
            else
            {
                _plot.Text = "";
                LoadPlot(it);
            }
            SetAmbient(it);
        }

        private async void LoadPlot(Item it)
        {
            try
            {
                string plot;
                if (it.Kind == Kind.Movie) plot = (await Xtream.GetVodInfo(Prefs.Account(), it.Id)).Plot;
                else plot = (await Xtream.GetSeriesInfo(Prefs.Account(), it.Id)).Plot;
                Plots[it.Key] = plot ?? "";
                if (_featured.Count > 0 && _featured[_featIdx].Key == it.Key) _plot.Text = plot ?? "";
            }
            catch { }
        }

        private void SetAmbient(Item it)
        {
            string url = !string.IsNullOrEmpty(it.Backdrop) ? it.Backdrop : it.Icon;
            _ambientHost.Children.Clear();
            if (!string.IsNullOrEmpty(url)) _ambientHost.Children.Add(Ui.Ambient(url));
        }

        private void OpenFeatured()
        {
            if (_featured.Count == 0) return;
            Main.Go(new DetailPage(_featured[_featIdx]));
        }

        private void BuildRows(Snapshot s)
        {
            // El inicio ya no lleva filas de categorías: todo eso está en Películas, Series, etc.
            if (_rows.Children.Count > 0) _rows.Children.Clear();
        }

        private static string Subtitle(HistoryEntry h)
        {
            if (h.Kind == Kind.Episode)
            {
                string se = (h.Season > 0 ? "T" + h.Season + " · " : "") + (h.Episode > 0 ? "E" + h.Episode : "");
                return se.Length > 0 ? se : "Continuar";
            }
            long left = Math.Max(0, (h.Dur - h.Pos) / 60000);
            return left > 0 ? "Quedan " + left + " min" : "Continuar";
        }

        private void AddRow(string title, IEnumerable<Item> items, double pw)
        {
            var list = items.ToList();
            if (list.Count == 0) return;
            var cards = list.Select(i => (FrameworkElement)Ui.Poster(i, pw, () => Main.Go(new DetailPage(i)))).ToArray();
            _rows.Children.Add(Ui.Row(title, cards, Edge));
        }

        private async void Resume(HistoryEntry h)
        {
            var s = Catalog.Snap;
            if (h.Kind == Kind.Movie)
            {
                var it = s?.Find(Kind.Movie, J.ToInt(h.Id));
                if (it != null) Main.Go(new PlayerPage(Media.ForMovie(it), Playback.StartFor(Media.ForMovie(it))));
                return;
            }
            var series = s?.Find(Kind.Series, h.SeriesId);
            if (series == null) return;
            // Episodio donde se quedó (o el siguiente si ya terminó).
            try
            {
                var info = await SeriesCache.Get(series.Id);
                var all = info.Ordered();
                int i = all.FindIndex(e => e.Id == h.Id);
                if (i < 0) { Main.Go(new DetailPage(series)); return; }
                var prog = Library.EpisodeProgress(h.Id);
                if (prog != null && prog[1] > 0 && prog[0] >= prog[1] - 60_000 && i + 1 < all.Count) i++;
                var queue = all.Select(e => Media.ForEpisode(series, e, series.Title, info.Cover)).ToList();
                Main.Go(new PlayerPage(queue[i], Playback.StartFor(queue[i]), queue, i));
            }
            catch
            {
                Main.Go(new DetailPage(series));
            }
        }

        public override bool OnKey(KeyEventArgs e)
        {
            // Sobre el destacado: → pasa al siguiente.
            if (e.Key == Key.Right && _feature.IsKeyboardFocused && _featured.Count > 1)
            {
                ShowFeature(_featIdx + 1);
                _rotate?.Stop();
                _rotate?.Start();
                return true;
            }
            if ((e.Key == Key.MediaPlayPause || e.Key == Key.M) && _liveBtn.IsKeyboardFocused)
            {
                ToggleSound();
                return true;
            }
            return false;
        }
    }

    /// <summary>Información de series ya pedida (no se vuelve a descargar al regresar).</summary>
    public static class SeriesCache
    {
        private static readonly Dictionary<int, SeriesInfo> Map = new Dictionary<int, SeriesInfo>();

        public static async Task<SeriesInfo> Get(int id)
        {
            SeriesInfo s;
            if (Map.TryGetValue(id, out s)) return s;
            s = await Xtream.GetSeriesInfo(Prefs.Account(), id);
            Map[id] = s;
            return s;
        }
    }
}
