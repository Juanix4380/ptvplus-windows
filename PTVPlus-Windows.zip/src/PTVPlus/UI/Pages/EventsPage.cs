using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PTVPlus.Core;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// Eventos como en la app de Android: los partidos del día (ESPN + todos los "vs" del panel)
    /// que tienen canal, por partido, por liga o por región, y con días para atrás y adelante.
    /// </summary>
    public sealed class EventsPage : Page
    {
        private static readonly CultureInfo Es = new CultureInfo("es-MX");
        private static readonly int[] Offsets = { -2, -1, 0, 1, 2 };

        private readonly StackPanel _dates = new StackPanel { Orientation = Orientation.Horizontal };
        private readonly StackPanel _tabs = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        private readonly ScrollViewer _scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Focusable = false };
        private readonly StackPanel _list = new StackPanel { Margin = new Thickness(48, 8, 48, 40) };
        private readonly TextBlock _status = Ui.T("", 17, Ui.B("Text2"), FontWeights.SemiBold);
        private readonly TextBlock _sub = Ui.T("Partidos con canal", 13.5, Ui.B("Text3"));
        private readonly Button _filter;
        private int _day;
        private int _tab;
        private string _league;
        private List<Match> _matches = new List<Match>();
        private int _seq;
        private bool _loading;
        private DispatcherTimer _refresh;

        public EventsPage()
        {
            Background = Ui.B("Bg");
            RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            var head = new Grid { Margin = new Thickness(48, 22, 48, 6) };
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            head.Children.Add(Ui.Round(G.Back, () => Main.Back(), "Atrás"));
            var titles = new StackPanel { Margin = new Thickness(18, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
            titles.Children.Add(Ui.T("Eventos", 28, Ui.B("Text"), FontWeights.Bold));
            titles.Children.Add(_sub);
            Grid.SetColumn(titles, 1);
            head.Children.Add(titles);
            var refresh = Ui.Round(G.Refresh, () => Load(true, false), "Actualizar");
            Grid.SetColumn(refresh, 2);
            head.Children.Add(refresh);
            Children.Add(head);

            var bar = new Grid { Margin = new Thickness(48, 12, 48, 8) };
            bar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            bar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            bar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            bar.Children.Add(_dates);
            _filter = Ui.Primary("", () => { _league = null; Render(); }, G.Close);
            _filter.Margin = new Thickness(14, 0, 0, 0);
            _filter.Visibility = Visibility.Collapsed;
            Grid.SetColumn(_filter, 1);
            bar.Children.Add(_filter);
            Grid.SetColumn(_tabs, 2);
            bar.Children.Add(_tabs);
            Grid.SetRow(bar, 1);
            Children.Add(bar);

            _scroll.Content = _list;
            Grid.SetRow(_scroll, 2);
            Children.Add(_scroll);
            _status.HorizontalAlignment = HorizontalAlignment.Center;
            _status.VerticalAlignment = VerticalAlignment.Center;
            _status.TextAlignment = TextAlignment.Center;
            _status.TextWrapping = TextWrapping.Wrap;
            _status.MaxWidth = 600;
            Grid.SetRow(_status, 2);
            Children.Add(_status);

            BuildDates();
            BuildTabs();
            SizeChanged += (s, e) => { if (Math.Abs(e.NewSize.Width - e.PreviousSize.Width) > 40) Render(); };
        }

        // ------------------------------------------------------------- barra

        private void BuildDates()
        {
            _dates.Children.Clear();
            foreach (int off in Offsets)
            {
                int o = off;
                var d = DateTime.Today.AddDays(o);
                string label = o == 0 ? "Hoy" : o == -1 ? "Ayer" : o == 1 ? "Mañana" : Es.TextInfo.ToTitleCase(d.ToString("ddd", Es).Replace(".", ""));
                label += "  " + d.ToString("dd/MM", Es);
                var b = o == _day ? Ui.Primary(label, () => SetDay(o)) : Ui.Pill(label, () => SetDay(o));
                b.Margin = new Thickness(0, 0, 10, 0);
                b.Tag = "day" + o;
                _dates.Children.Add(b);
            }
        }

        private void BuildTabs()
        {
            _tabs.Children.Clear();
            var names = new[] { "Partidos", "Ligas", "Regiones" };
            for (int i = 0; i < names.Length; i++)
            {
                int t = i;
                var b = t == _tab ? Ui.Primary(names[i], () => SetTab(t)) : Ui.Pill(names[i], () => SetTab(t));
                b.Margin = new Thickness(10, 0, 0, 0);
                b.Tag = "tab" + t;
                _tabs.Children.Add(b);
            }
        }

        private void SetDay(int o)
        {
            if (_day == o) return;
            _day = o;
            BuildDates();
            FocusTag(_dates, "day" + o);
            Load(false, false);
        }

        private void SetTab(int t)
        {
            _tab = t;
            if (t != 0) _league = null;
            BuildTabs();
            FocusTag(_tabs, "tab" + t);
            Render();
        }

        private void FocusTag(Panel p, string tag)
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                foreach (var c in p.Children) if (c is Button b && Equals(b.Tag, tag)) { b.Focus(); break; }
            }), DispatcherPriority.Loaded);
        }

        // ------------------------------------------------------- ciclo de vida

        public override void OnShow()
        {
            if (_matches.Count == 0) Load(false, false);
            else Render();
            _refresh = UiThread.Every(60000, () => { if (_day == 0 && !_loading) Load(true, true); });
        }

        public override void OnHide()
        {
            _refresh?.Stop();
        }

        public override void FocusFirst()
        {
            var first = FirstCard();
            if (first != null) first.Focus();
            else FocusTag(_dates, "day" + _day);
        }

        private Button FirstCard()
        {
            foreach (var c in _list.Children)
            {
                if (c is Button b) return b;
                if (c is Panel p) foreach (var x in p.Children) if (x is Button bb) return bb;
            }
            return null;
        }

        public override bool OnKey(KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Up: Move(FocusNavigationDirection.Up); return true;
                case Key.Down: Move(FocusNavigationDirection.Down); return true;
                case Key.Left: Move(FocusNavigationDirection.Left); return true;
                case Key.Right: Move(FocusNavigationDirection.Right); return true;
                case Key.F5: Load(true, false); return true;
            }
            return false;
        }

        public override bool OnBack()
        {
            if (_league != null) { _league = null; Render(); return true; }
            return false;
        }

        // ------------------------------------------------------------- datos

        private async void Load(bool force, bool silent)
        {
            int my = ++_seq;
            _loading = true;
            var day = DateTime.Today.AddDays(_day);
            if (!silent)
            {
                _status.Text = "Buscando partidos con canal…";
                if (!force)
                {
                    _matches = new List<Match>();
                    _list.Children.Clear();
                }
            }
            List<Match> espn;
            bool failed = false;
            try { espn = await Task.Run(() => Sports.Matches(day, force)); }
            catch { espn = new List<Match>(); failed = true; }
            if (my != _seq) return;
            try
            {
                if (!silent)
                {
                    // 1) Al instante, con los canales que ya se conocen
                    var quick = await Task.Run(() => PanelEvents.Confirm(PanelEvents.Merge(day, espn, PanelEvents.Cached()), false));
                    if (my != _seq) return;
                    if (quick.Count > 0)
                    {
                        _matches = quick;
                        _status.Text = "";
                        Render();
                    }
                }
                // 2) Completo: todos los "vs" del panel y la guía de los partidos cercanos
                List<Match> panel;
                bool f = force && !silent;
                try { panel = await Task.Run(() => PanelEvents.Matches(f)); }
                catch { panel = new List<Match>(); }
                var all = await Task.Run(() => PanelEvents.Confirm(PanelEvents.Merge(day, espn, panel), true));
                if (my != _seq) return;
                _matches = all;
                _status.Text = "";
                Render();
                if (_matches.Count == 0)
                    _status.Text = failed ? "No se pudieron cargar los eventos. Revisa tu conexión." : "No hay partidos con canal para este día.";
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Eventos");
                if (my == _seq && _matches.Count == 0) _status.Text = "No se pudieron cargar los eventos.";
            }
            finally
            {
                if (my == _seq) _loading = false;
            }
        }

        // ------------------------------------------------------------- lista

        private double CardWidth(out int cols)
        {
            double w = Math.Max(600, ActualWidth - 96);
            cols = w >= 1500 ? 3 : w >= 900 ? 2 : 1;
            return Math.Floor((w - (cols - 1) * 16 - 2) / cols);
        }

        private List<Tuple<string, List<Match>>> LeagueGroups()
        {
            var by = _matches.GroupBy(m => m.League.Slug).ToDictionary(g => g.Key, g => g.ToList());
            var outList = new List<Tuple<string, List<Match>>>();
            foreach (var lg in Sports.Leagues) { List<Match> l; if (by.TryGetValue(lg.Slug, out l)) outList.Add(Tuple.Create(lg.Slug, l)); }
            foreach (var kv in by) if (!Sports.Leagues.Any(l => l.Slug == kv.Key)) outList.Add(Tuple.Create(kv.Key, kv.Value));
            return outList;
        }

        private void Render()
        {
            bool hadFocus = _list.IsKeyboardFocusWithin;
            _list.Children.Clear();
            int cols;
            double cw = CardWidth(out cols);
            _filter.Visibility = _league != null && _tab == 0 ? Visibility.Visible : Visibility.Collapsed;
            _sub.Text = _matches.Count == 0 ? "Partidos con canal" : _matches.Count + " partidos con canal" + (_matches.Count(m => m.Live) > 0 ? " · " + _matches.Count(m => m.Live) + " en vivo" : "");
            if (_tab == 0)
            {
                var shown = _league != null ? _matches.Where(m => m.League.Slug == _league).ToList() : _matches;
                if (_league != null) _filter.Content = Ui.IconText(G.Close, shown.FirstOrDefault()?.League.Name ?? "Liga");
                // En vivo primero, luego por hora
                var ordered = shown.Where(m => m.Live).Concat(shown.Where(m => !m.Live && !m.Finished)).Concat(shown.Where(m => m.Finished)).ToList();
                var wrap = new WrapPanel();
                foreach (var m in ordered) wrap.Children.Add(MatchCard(m, cw));
                _list.Children.Add(wrap);
            }
            else if (_tab == 1)
            {
                var wrap = new WrapPanel();
                foreach (var g in LeagueGroups()) wrap.Children.Add(LeagueCard(g.Item2, cw));
                _list.Children.Add(wrap);
            }
            else
            {
                var groups = LeagueGroups();
                var regions = Sports.Leagues.Select(l => l.Region).Concat(groups.Select(g => g.Item2[0].League.Region)).Distinct().ToList();
                foreach (var r in regions)
                {
                    var lgs = groups.Where(g => g.Item2[0].League.Region == r).ToList();
                    if (lgs.Count == 0) continue;
                    var t = Ui.T(r.ToUpperInvariant(), 14, Ui.B("Accent"), FontWeights.Bold);
                    t.Margin = new Thickness(4, 14, 0, 10);
                    _list.Children.Add(t);
                    var wrap = new WrapPanel();
                    foreach (var g in lgs) wrap.Children.Add(LeagueCard(g.Item2, cw));
                    _list.Children.Add(wrap);
                }
            }
            if (hadFocus) FocusFirst();
        }

        private static Image Logo(string url, double size)
        {
            var img = new Image { Width = size, Height = size, Stretch = Stretch.Uniform };
            RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.Linear);
            if (!string.IsNullOrEmpty(url)) Images.Load(img, url, (int)(size * 2));
            return img;
        }

        private static FrameworkElement TeamLine(Team t, string score, bool showScore)
        {
            var g = new Grid { Margin = new Thickness(0, 6, 0, 0) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(40) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var box = new Border { Width = 34, Height = 34, CornerRadius = new CornerRadius(17), Background = Ui.Hex("#22FFFFFF"), HorizontalAlignment = HorizontalAlignment.Left };
            if (!string.IsNullOrEmpty(t.Logo)) box.Child = Logo(t.Logo, 26);
            else box.Child = new TextBlock { Text = TextUtil.Initials(t.Name), Foreground = Brushes.White, FontSize = 12, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            g.Children.Add(box);
            var n = Ui.T(t.Name, 16.5, Brushes.White, FontWeights.SemiBold);
            n.VerticalAlignment = VerticalAlignment.Center;
            n.TextTrimming = TextTrimming.CharacterEllipsis;
            Grid.SetColumn(n, 1);
            g.Children.Add(n);
            var sc = Ui.T(showScore ? score : "", 20, Brushes.White, FontWeights.Bold);
            sc.VerticalAlignment = VerticalAlignment.Center;
            sc.Margin = new Thickness(10, 0, 4, 0);
            Grid.SetColumn(sc, 2);
            g.Children.Add(sc);
            return g;
        }

        public static string TimeText(Match m) => m.Start > 0 ? DateTimeOffset.FromUnixTimeMilliseconds(m.Start).LocalDateTime.ToString("h:mm tt", Es) : (m.Detail.Length > 0 ? m.Detail : "Hoy");

        private Button MatchCard(Match m, double w)
        {
            var root = new StackPanel();
            var top = new Grid();
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var lg = Logo(m.LeagueLogo, 20);
            lg.Margin = new Thickness(0, 0, 8, 0);
            top.Children.Add(lg);
            var ln = Ui.T(m.League.Name, 12.5, Ui.B("Text3"), FontWeights.Bold);
            ln.VerticalAlignment = VerticalAlignment.Center;
            ln.TextTrimming = TextTrimming.CharacterEllipsis;
            Grid.SetColumn(ln, 1);
            top.Children.Add(ln);
            FrameworkElement state;
            if (m.Live) state = Ui.Badge("●  EN VIVO" + (!m.Panel && m.Clock.Length > 0 && m.Clock != "0'" ? "  " + m.Clock : ""), Ui.Hex("#FFE0245E"));
            else if (m.Finished) state = Ui.T("Finalizado", 12.5, Ui.B("Text3"), FontWeights.SemiBold);
            else state = Ui.T(TimeText(m), 14, Ui.B("Accent"), FontWeights.Bold);
            state.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(state, 2);
            top.Children.Add(state);
            root.Children.Add(top);
            bool score = !m.Panel && m.State != "pre";
            root.Children.Add(TeamLine(m.Home, m.Home.Score, score));
            root.Children.Add(TeamLine(m.Away, m.Away.Score, score));
            var names = string.Join(", ", m.Channels.Take(3).Select(c => c.Name));
            var ch = Ui.T("▶  " + m.Channels.Count + (m.Channels.Count == 1 ? " canal" : " canales") + (names.Length > 0 ? "  ·  " + names : ""), 12.5, Ui.B("Text2"));
            ch.Margin = new Thickness(0, 10, 0, 0);
            ch.TextTrimming = TextTrimming.CharacterEllipsis;
            root.Children.Add(ch);
            var b = new Button { Style = Ui.S("RowBtn"), Content = root, Width = w, Margin = new Thickness(0, 0, 16, 16), Padding = new Thickness(18, 14, 18, 14) };
            if (m.Live) b.Background = Ui.Hex("#FF241634");
            b.Click += (s, e) => Main.Go(new EventPage(m));
            return b;
        }

        private Button LeagueCard(List<Match> ms, double w)
        {
            var first = ms[0];
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(52) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.Children.Add(Logo(first.LeagueLogo, 36));
            var texts = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            var n = Ui.T(first.League.Name, 16.5, Brushes.White, FontWeights.SemiBold);
            n.TextTrimming = TextTrimming.CharacterEllipsis;
            texts.Children.Add(n);
            int live = ms.Count(x => x.Live);
            texts.Children.Add(Ui.T(ms.Count + (ms.Count == 1 ? " partido" : " partidos") + (live > 0 ? " · " + live + " en vivo" : ""), 13, live > 0 ? Ui.Hex("#FFFF6B93") : Ui.B("Text3")));
            Grid.SetColumn(texts, 1);
            g.Children.Add(texts);
            var b = new Button { Style = Ui.S("RowBtn"), Content = g, Width = w, Margin = new Thickness(0, 0, 16, 12) };
            b.Click += (s, e) =>
            {
                _league = first.League.Slug;
                _tab = 0;
                BuildTabs();
                Render();
                FocusFirst();
            };
            return b;
        }
    }
}
