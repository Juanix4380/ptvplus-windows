using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// Reproductor de películas y episodios a pantalla completa con los mismos controles que TV en
    /// vivo: arriba regresar / inicio / título / hora / sonido, al centro −10 s · pausa · +10 s,
    /// abajo la barra de avance, siguiente episodio, audio, subtítulos, formato y pantalla completa.
    /// </summary>
    public sealed class PlayerPage : Page
    {
        private readonly Media _media;
        private readonly double _start;
        private readonly List<Media> _queue;
        private readonly int _index;
        private readonly Grid _ov = new Grid();
        private readonly Grid _hit = new Grid { Background = new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)), Focusable = true, FocusVisualStyle = null };
        private readonly PlayerChrome _chrome;
        private readonly Slider _seek = new Slider { Minimum = 0, Maximum = 1, IsMoveToPointEnabled = true, Focusable = false };
        private readonly TextBlock _pos = Ui.T("0:00", 14, Brushes.White, FontWeights.SemiBold);
        private readonly TextBlock _dur = Ui.T("0:00", 14, Ui.Hex("#FFCFC6E2"));
        private readonly TextBlock _status = Ui.T("", 20, Brushes.White, FontWeights.SemiBold);
        private readonly TextBlock _stats = Ui.T("", 13, Brushes.White);
        private readonly Border _center = new Border { Width = 96, Height = 96, CornerRadius = new CornerRadius(48), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, IsHitTestVisible = false, Opacity = 0 };
        private readonly TextBlock _centerIcon = Ui.Icon(G.Pause, 38);
        private Button _nextBtn, _fullBtn, _subsBtn, _epsBtn;
        // Lista de episodios (series)
        private readonly Border _eps = new Border { HorizontalAlignment = HorizontalAlignment.Right, Width = 620, Visibility = Visibility.Collapsed };
        private readonly StackPanel _seasonBar = new StackPanel { Orientation = Orientation.Horizontal };
        private readonly StackPanel _epList = new StackPanel();
        private readonly ScrollViewer _epScroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Focusable = false };
        private readonly TextBlock _epsTitle = Ui.T("Episodios", 24, Brushes.White, FontWeights.Bold);
        private readonly TextBlock _epsSub = Ui.T("", 14, Ui.Hex("#FFCFC6E2"));
        private DispatcherTimer _tick;
        private Point _lastMouse = new Point(-1, -1);
        private bool _dragging;
        private bool _updating;
        private bool _ended;
        private bool _leaving;

        public override bool VideoFull => true;
        public override UIElement OverlayContent => _ov;

        public PlayerPage(Media media, double start, List<Media> queue = null, int index = 0)
        {
            _media = media;
            _start = start;
            _queue = queue;
            _index = index;
            Background = Brushes.Black;
            _chrome = new PlayerChrome(Leave, () => { _leaving = true; Main.GoHome(); }, TogglePause);
            Build();
        }

        private void Build()
        {
            _ov.MouseMove += (s, e) =>
            {
                if (!Moved(e)) return;
                _hit.Cursor = null;
                if (!EpisodesOpen) _chrome.Show();
            };
            // Un clic muestra los controles y otro los quita (la pausa va en su botón).
            _hit.MouseLeftButtonUp += (s, e) =>
            {
                if (EpisodesOpen) CloseEpisodes();
                else _chrome.Toggle();
            };
            _hit.MouseWheel += (s, e) => PlayerChrome.Volume(e.Delta > 0 ? 5 : -5);
            _ov.Children.Add(_hit);

            _status.HorizontalAlignment = HorizontalAlignment.Center;
            _status.VerticalAlignment = VerticalAlignment.Center;
            _status.TextWrapping = TextWrapping.Wrap;
            _status.TextAlignment = TextAlignment.Center;
            _status.MaxWidth = 760;
            _status.Margin = new Thickness(0, 210, 0, 0);
            _status.Effect = Ui.Shadow(12, 0.9);
            _status.IsHitTestVisible = false;
            _ov.Children.Add(_status);

            _center.Background = Ui.Hex("#B30B0812");
            _center.Child = _centerIcon;
            _ov.Children.Add(_center);

            // ---------- Controles
            var back10 = _chrome.CtlSkip(G.Back10, "10", () => Seek(-10), "Regresar 10 s (◄)");
            var fwd10 = _chrome.CtlSkip(G.Fwd10, "10", () => Seek(10), "Adelantar 10 s (►)");
            _chrome.SetCenter(back10, fwd10);

            var seekRow = new Grid();
            seekRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            seekRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            seekRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            _pos.VerticalAlignment = VerticalAlignment.Center;
            _pos.MinWidth = 64;
            seekRow.Children.Add(_pos);
            _seek.Style = Ui.S("Seek");
            _seek.Margin = new Thickness(12, 0, 12, 0);
            _seek.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(_seek, 1);
            seekRow.Children.Add(_seek);
            _dur.VerticalAlignment = VerticalAlignment.Center;
            _dur.MinWidth = 64;
            _dur.TextAlignment = TextAlignment.Right;
            Grid.SetColumn(_dur, 2);
            seekRow.Children.Add(_dur);
            _chrome.Extra.Content = seekRow;

            _epsBtn = Ui.Pill("Episodios", OpenEpisodes, G.List);
            _epsBtn.Visibility = Visibility.Collapsed;
            _epsBtn.Margin = new Thickness(0, 0, 10, 0);
            _chrome.BottomLeft.Children.Add(_epsBtn);
            _nextBtn = Ui.Pill("Siguiente episodio", () => Playback.Next(), G.Next);
            _nextBtn.Visibility = Visibility.Collapsed;
            _chrome.BottomLeft.Children.Add(_nextBtn);

            _chrome.AddRight(_chrome.Ctl(G.Audio, PlayerChrome.PickAudio, "Audio"));
            _subsBtn = _chrome.Ctl(G.Subs, PlayerChrome.PickSubs, "Subtítulos");
            _chrome.AddRight(_subsBtn);
            _chrome.AddRight(_chrome.Ctl(G.All, PlayerChrome.PickAspect, "Formato de pantalla"));
            _fullBtn = _chrome.Ctl(G.Full, () => { Main.ToggleFullscreen(); PaintFull(); }, "Pantalla completa (F)");
            _chrome.AddRight(_fullBtn);

            _chrome.KeepOpen = () => _dragging || (Playback.Main != null && Playback.Main.Paused);
            _chrome.FocusRest = () => _hit.Focus();
            _chrome.ShownChanged += () =>
            {
                if (!_chrome.IsShown && !EpisodesOpen) _hit.Focus();
                _hit.Cursor = !_chrome.IsShown && !EpisodesOpen && Main.IsFullscreen ? Cursors.None : null;
            };
            _ov.Children.Add(_chrome);
            BuildEpisodesPanel();

            var statsBox = new Border
            {
                Background = Ui.Hex("#C0100A1A"), CornerRadius = new CornerRadius(12), Padding = new Thickness(14, 10, 14, 10),
                HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 110, 30, 0),
                Child = _stats, IsHitTestVisible = false
            };
            _stats.FontFamily = new FontFamily("Consolas");
            _stats.TextTrimming = TextTrimming.None;
            statsBox.SetBinding(VisibilityProperty, new System.Windows.Data.Binding("Text") { Source = _stats, Converter = new EmptyToCollapsed() });
            _ov.Children.Add(statsBox);

            _seek.AddHandler(Thumb.DragStartedEvent, new DragStartedEventHandler((s, e) => _dragging = true));
            _seek.AddHandler(Thumb.DragCompletedEvent, new DragCompletedEventHandler((s, e) =>
            {
                _dragging = false;
                Playback.SeekTo(_seek.Value);
                _chrome.Bump();
            }));
            _seek.ValueChanged += (s, e) =>
            {
                if (_updating || _dragging) return;
                // Clic en la barra: salta ahí.
                Playback.SeekTo(_seek.Value);
                _chrome.Bump();
            };
        }

        // ---------------------------------------------------------- episodios

        private bool EpisodesOpen => _eps.Visibility == Visibility.Visible;

        private void BuildEpisodesPanel()
        {
            _eps.Background = new LinearGradientBrush(Color.FromArgb(0x00, 0x07, 0x05, 0x0C), Color.FromArgb(0xF7, 0x07, 0x05, 0x0C), new Point(0, 0), new Point(0.22, 0));
            var dock = new DockPanel { Margin = new Thickness(90, 34, 40, 24) };
            var head = new StackPanel();
            DockPanel.SetDock(head, Dock.Top);
            _epsTitle.TextTrimming = TextTrimming.CharacterEllipsis;
            head.Children.Add(_epsTitle);
            _epsSub.Margin = new Thickness(0, 4, 0, 0);
            head.Children.Add(_epsSub);
            var seasons = new ScrollViewer
            {
                HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden, VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Focusable = false, Content = _seasonBar, Margin = new Thickness(0, 16, 0, 16)
            };
            head.Children.Add(seasons);
            dock.Children.Add(head);
            _epScroll.Content = _epList;
            dock.Children.Add(_epScroll);
            _eps.Child = dock;
            _ov.Children.Add(_eps);
        }

        private void OpenEpisodes()
        {
            var q = Playback.Queue;
            if (q == null || q.Count == 0) return;
            var cur = Playback.Current ?? _media;
            _epsTitle.Text = cur.Title;
            _epsSub.Text = q.Count + " episodios";
            _eps.Visibility = Visibility.Visible;
            _eps.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(150)));
            _chrome.Hide();
            _hit.Cursor = null;
            ShowSeason(cur.Season, true);
            Main.Overlay?.Activate();
        }

        private void CloseEpisodes()
        {
            if (!EpisodesOpen) return;
            _eps.Visibility = Visibility.Collapsed;
            _hit.Focus();
        }

        private void ShowSeason(int season, bool focusPlaying)
        {
            var q = Playback.Queue;
            var list = q.Select(m => m.Season).Distinct().OrderBy(x => x == 0 ? int.MaxValue : x).ToList();
            if (!list.Contains(season)) season = list.FirstOrDefault();
            _seasonBar.Children.Clear();
            foreach (int sn in list)
            {
                int n = sn;
                string label = n == 0 ? "Especiales" : "Temporada " + n;
                var b = n == season ? Ui.Primary(label, () => ShowSeason(n, false)) : Ui.Pill(label, () => ShowSeason(n, false));
                b.Margin = new Thickness(0, 0, 10, 0);
                b.Tag = n;
                _seasonBar.Children.Add(b);
            }
            _seasonBar.Visibility = list.Count > 1 ? Visibility.Visible : Visibility.Collapsed;

            _epList.Children.Clear();
            Button focus = null, first = null;
            for (int i = 0; i < q.Count; i++)
            {
                if (q[i].Season != season) continue;
                bool playing = i == Playback.Index && Playback.Current != null && Playback.Current.Url == q[i].Url;
                var row = EpisodeRow(q[i], i, playing);
                if (first == null) first = row;
                if (playing) focus = row;
                _epList.Children.Add(row);
            }
            _epScroll.ScrollToTop();
            var target = focusPlaying ? (focus ?? first) : null;
            if (!focusPlaying)
            {
                foreach (var c in _seasonBar.Children) if (c is Button sb && (int)sb.Tag == season) target = sb;
            }
            if (target != null)
                Dispatcher.BeginInvoke(new Action(() => { target.Focus(); target.BringIntoView(); }), DispatcherPriority.Loaded);
        }

        private Button EpisodeRow(Media m, int index, bool playing)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(172) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var thumb = new Border { Width = 160, Height = 90, CornerRadius = new CornerRadius(10), Background = Ui.Gradient("#FF2A1E46", "#FF140F22", 90), HorizontalAlignment = HorizontalAlignment.Left };
            var tg = new Grid();
            var ph = Ui.Icon(G.Play, 20, Ui.B("Text3"));
            ph.HorizontalAlignment = HorizontalAlignment.Center;
            ph.VerticalAlignment = VerticalAlignment.Center;
            tg.Children.Add(ph);
            var prog = Library.EpisodeProgress(m.Id);
            bool seen = prog != null && prog[1] > 0 && prog[0] >= prog[1] - 60_000;
            if (prog != null && prog[1] > 0 && prog[0] > 0)
            {
                var bar = new Grid { Height = 4, VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(8, 0, 8, 7) };
                bar.Children.Add(new Border { Background = Ui.Hex("#66FFFFFF"), CornerRadius = new CornerRadius(2) });
                bar.Children.Add(new Border
                {
                    Background = Ui.B("Accent"), CornerRadius = new CornerRadius(2), HorizontalAlignment = HorizontalAlignment.Left,
                    Width = Math.Max(4, 144 * Math.Min(1.0, prog[0] / (double)prog[1]))
                });
                tg.Children.Add(bar);
            }
            thumb.Child = tg;
            if (!string.IsNullOrEmpty(m.Image)) Images.LoadInto(thumb, ph, m.Image, 260);
            g.Children.Add(thumb);

            var texts = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 0, 0, 0) };
            string name = m.Subtitle ?? "";
            var t1 = Ui.T("Episodio " + m.EpisodeNum, 16, Brushes.White, FontWeights.Bold);
            texts.Children.Add(t1);
            // "T1 · E4 · Título" → "Título"
            var parts = name.Split(new[] { " · " }, StringSplitOptions.None);
            int ei = Array.FindIndex(parts, x => x.Length > 1 && x[0] == 'E' && char.IsDigit(x[1]));
            string rest = ei >= 0 ? string.Join(" · ", parts.Skip(ei + 1)) : name;
            if (rest.Length > 0)
            {
                var t2 = Ui.T(rest, 13.5, Ui.Hex("#FFD9D0EC"));
                t2.TextWrapping = TextWrapping.Wrap;
                t2.MaxHeight = 40;
                t2.Margin = new Thickness(0, 3, 0, 0);
                texts.Children.Add(t2);
            }
            string state = playing ? "●  Reproduciendo" : seen ? "Visto" : prog != null && prog[1] > 0 && prog[0] > 0 ? "Quedan " + Math.Max(1, (prog[1] - prog[0]) / 60000) + " min" : "";
            if (state.Length > 0)
            {
                var t3 = Ui.T(state, 12.5, playing ? Ui.B("Accent") : Ui.B("Text3"), FontWeights.SemiBold);
                t3.Margin = new Thickness(0, 5, 0, 0);
                texts.Children.Add(t3);
            }
            Grid.SetColumn(texts, 1);
            g.Children.Add(texts);

            var b = new Button { Style = Ui.S("RowBtn"), Content = g, Padding = new Thickness(10), Margin = new Thickness(0, 0, 0, 10) };
            if (playing) b.Background = Ui.Hex("#FF2E2150");
            b.Click += (s, e) =>
            {
                CloseEpisodes();
                if (!playing) Playback.PlayAt(index);
                _chrome.Show();
            };
            return b;
        }

        private bool Moved(MouseEventArgs e)
        {
            var p = e.GetPosition(_ov);
            bool moved = _lastMouse.X < 0 || Math.Abs(p.X - _lastMouse.X) + Math.Abs(p.Y - _lastMouse.Y) > 4;
            _lastMouse = p;
            return moved;
        }

        // ------------------------------------------------------- ciclo de vida

        public override void OnShow()
        {
            Playback.Changed += Paint;
            Playback.Ended += OnEnded;
            _tick = UiThread.Every(500, Tick);
            var cur = Playback.Current;
            if (cur == null || cur.Url != _media.Url) Playback.Play(_media, _start, _queue, _index);
            else Playback.Main?.SetMute(false);
            Paint();
            _chrome.Show();
        }

        public override void OnHide()
        {
            Playback.Changed -= Paint;
            Playback.Ended -= OnEnded;
            _tick?.Stop();
            _chrome.Hide();
            Playback.SaveProgress(true);
            Main.Activate();
        }

        public override void FocusFirst()
        {
            Main.Overlay?.Activate();
            if (_chrome.IsShown) _chrome.PlayBtn.Focus();
            else _hit.Focus();
        }

        /// <summary>Salir del reproductor (botón de regresar de los controles).</summary>
        private void Leave()
        {
            _leaving = true;
            Main.Back();
        }

        public override bool OnBack()
        {
            if (_leaving) return false;
            if (EpisodesOpen) { CloseEpisodes(); return true; }
            if (_chrome.IsActive) { _chrome.Hide(); return true; }
            if (Main.IsFullscreen) { Main.ToggleFullscreen(); PaintFull(); return true; }
            return false;
        }

        private void OnEnded()
        {
            if (Playback.HasNext && Prefs.S.AutoNext) return;
            _ended = true;
            UiThread.After(1500, () =>
            {
                if (_ended && Main.Current == this)
                {
                    _leaving = true;
                    Main.Back();
                }
            });
        }

        // ------------------------------------------------------------ pintar

        private void Paint()
        {
            var m = Playback.Current ?? _media;
            _chrome.Title.Text = m.Title;
            _chrome.Subtitle.Text = m.Subtitle;
            _chrome.Subtitle.Visibility = string.IsNullOrEmpty(m.Subtitle) ? Visibility.Collapsed : Visibility.Visible;
            _nextBtn.Visibility = Playback.HasNext ? Visibility.Visible : Visibility.Collapsed;
            _epsBtn.Visibility = m.Kind == Kind.Episode && Playback.Queue.Count > 1 ? Visibility.Visible : Visibility.Collapsed;
            _chrome.Paint();
            PaintFull();
            var p = Playback.Main;
            if (Playback.LastError != null) _status.Text = Playback.LastError;
            else if (Playback.Notice != null) _status.Text = Playback.Notice;
            else if (p != null && Playback.Current != null && (p.Buffering || (p.CoreIdle && p.Position <= 0 && !p.Paused))) _status.Text = "Cargando…";
            else _status.Text = "";
        }

        private void PaintFull()
        {
            string g = Main.IsFullscreen ? G.ExitFull : G.Full;
            if (!Equals(_fullBtn.Content, g)) _fullBtn.Content = g;
            _fullBtn.ToolTip = Main.IsFullscreen ? "Salir de pantalla completa (F)" : "Pantalla completa (F)";
        }

        private void Tick()
        {
            var p = Playback.Main;
            if (p == null) return;
            double dur = p.Duration, pos = p.Position;
            _updating = true;
            if (dur > 0 && !_dragging)
            {
                if (Math.Abs(_seek.Maximum - dur) > 0.5) _seek.Maximum = dur;
                _seek.Value = Math.Max(0, Math.Min(dur, pos));
            }
            _updating = false;
            _pos.Text = TextUtil.Time(_dragging ? _seek.Value : pos);
            _dur.Text = dur > 0 ? TextUtil.Time(dur) : "--:--";
            _stats.Text = Prefs.S.PlayerStats && Playback.Current != null ? p.Stats() : "";
            Paint();
        }

        // --------------------------------------------------------- acciones

        private void Flash(string glyph)
        {
            if (_chrome.IsShown) return;
            _centerIcon.Text = glyph;
            var a = new DoubleAnimationUsingKeyFrames();
            a.KeyFrames.Add(new LinearDoubleKeyFrame(1, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(80))));
            a.KeyFrames.Add(new LinearDoubleKeyFrame(1, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(500))));
            a.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(800))));
            _center.BeginAnimation(OpacityProperty, a);
        }

        private void TogglePause()
        {
            var p = Playback.Main;
            bool wasPaused = p != null && p.Paused;
            Playback.TogglePause();
            Flash(wasPaused ? G.Play : G.Pause);
            UiThread.After(150, () => _chrome.Paint());
            _chrome.Bump();
        }

        private void Seek(double secs)
        {
            Playback.Seek(secs);
            Main.Toast((secs < 0 ? "−" : "+") + Math.Abs(secs) + " s");
            _chrome.Bump();
        }

        // ------------------------------------------------------------ teclado

        public override bool OnKey(KeyEventArgs e)
        {
            bool active = _chrome.IsActive;
            if (EpisodesOpen)
            {
                switch (e.Key)
                {
                    case Key.Up: Move(FocusNavigationDirection.Up); return true;
                    case Key.Down: Move(FocusNavigationDirection.Down); return true;
                    case Key.Left: Move(FocusNavigationDirection.Left); return true;
                    case Key.Right: Move(FocusNavigationDirection.Right); return true;
                    case Key.Enter:
                    case Key.Space:
                        return false;
                }
            }
            switch (e.Key)
            {
                case Key.Space:
                case Key.MediaPlayPause:
                case Key.Play:
                case Key.Pause:
                    TogglePause();
                    if (!active) _chrome.Show();
                    return true;
                case Key.Enter:
                    if (active) { _chrome.Bump(); return false; }
                    _chrome.Show(true);
                    return true;
                case Key.Left:
                    if (active) { _chrome.Bump(); Move(FocusNavigationDirection.Left); return true; }
                    Seek(-10);
                    return true;
                case Key.Right:
                    if (active) { _chrome.Bump(); Move(FocusNavigationDirection.Right); return true; }
                    Seek(10);
                    return true;
                case Key.Up:
                    if (active) { _chrome.Bump(); Move(FocusNavigationDirection.Up); return true; }
                    PlayerChrome.Volume(5);
                    return true;
                case Key.Down:
                    if (active) { _chrome.Bump(); Move(FocusNavigationDirection.Down); return true; }
                    _chrome.Show(true);
                    return true;
                case Key.J:
                    Seek(-10);
                    return true;
                case Key.L:
                    Seek(30);
                    return true;
                case Key.M:
                case Key.VolumeMute:
                    _chrome.ToggleMute();
                    return true;
                case Key.VolumeUp:
                case Key.OemPlus:
                case Key.Add:
                    PlayerChrome.Volume(5);
                    return true;
                case Key.VolumeDown:
                case Key.OemMinus:
                case Key.Subtract:
                    PlayerChrome.Volume(-5);
                    return true;
                case Key.F:
                    Main.ToggleFullscreen();
                    PaintFull();
                    return true;
                case Key.N:
                case Key.MediaNextTrack:
                    if (Playback.HasNext) Playback.Next();
                    return true;
                case Key.Tab:
                    _chrome.Show();
                    return false;
            }
            return false;
        }
    }
}
