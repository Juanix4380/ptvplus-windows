using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// Multipantalla: 2, 3 o 4 canales a la vez. El audio sigue a la ventana elegida; cada canal
    /// se cambia con un buscador. Cloud autoriza al abrir y cada 25 s.
    /// </summary>
    public sealed class MultiPage : Page
    {
        private sealed class Win
        {
            public int Index;
            public VideoHost Host;
            public MpvPlayer Player;
            public Item Channel;
            public Border Frame;
            public TextBlock Label;
            public TextBlock Speaker;
            public TextBlock State;
            public Rect Rect;
            public int Retries;
            /// <summary>Lo que está cargado (null = nada): así no se recarga sin necesidad.</summary>
            public string Url;
        }

        private const int Max = 4;
        private readonly Canvas _canvas = new Canvas { ClipToBounds = true };
        private readonly Grid _ov = new Grid();
        private readonly Canvas _ovCanvas = new Canvas();
        private readonly StackPanel _toolbar = new StackPanel { Orientation = Orientation.Horizontal };
        private readonly Border _picker = new Border { Visibility = Visibility.Collapsed, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        private readonly ListBox _cats = new ListBox();
        private readonly ListBox _channels = new ListBox();
        private readonly TextBox _search = new TextBox();
        private readonly TextBlock _pickTitle = Ui.T("", 20, Brushes.White, FontWeights.Bold);
        private readonly List<Win> _wins = new List<Win>();
        private List<CatEntry> _entries = new List<CatEntry>();
        private List<Item> _shown = new List<Item>();
        private int _count;
        private int _active;
        /// <summary>Pantallas a la vez que permite la cuenta (más conexiones = cortes en todas).</summary>
        private readonly int _maxConn = Prefs.S.MaxConnections > 0 ? Math.Min(4, Prefs.S.MaxConnections) : 4;
        private bool _authorized;
        private int _seq;
        private DispatcherTimer _poll, _searchTimer, _watch;
        private readonly List<Button> _layoutBtns = new List<Button>();

        public override UIElement OverlayContent => _ov;

        public MultiPage()
        {
            Background = Ui.B("Bg");
            _count = Math.Max(2, Math.Min(4, Prefs.S.MultiCount));
            Children.Add(_canvas);
            for (int i = 0; i < Max; i++)
            {
                var w = new Win { Index = i, Host = new VideoHost { Visibility = Visibility.Collapsed } };
                var win = w;
                w.Host.Created += h => OnHost(win, h);
                _canvas.Children.Add(w.Host);
                _wins.Add(w);
            }
            BuildOverlay();
            SizeChanged += (s, e) => LayoutWindows();
        }

        // ------------------------------------------------------------ capa

        private void BuildOverlay()
        {
            _ov.Children.Add(_ovCanvas);
            var bar = new Border
            {
                VerticalAlignment = VerticalAlignment.Top, Background = Ui.Gradient("#F20B0812", "#000B0812", 90),
                Padding = new Thickness(36, 22, 36, 30)
            };
            var row = new Grid();
            var left = new StackPanel { Orientation = Orientation.Horizontal };
            left.Children.Add(Ui.Round(G.Back, () => Main.Back(), "Atrás"));
            var t = Ui.T("Multipantalla", 24, Brushes.White, FontWeights.Bold);
            t.VerticalAlignment = VerticalAlignment.Center;
            t.Margin = new Thickness(16, 0, 0, 0);
            left.Children.Add(t);
            var hint = Ui.T("Clic o flechas: elegir ventana (se escucha esa)  ·  Enter: cambiar canal", 13, Ui.B("Text3"));
            hint.VerticalAlignment = VerticalAlignment.Center;
            hint.Margin = new Thickness(22, 4, 0, 0);
            left.Children.Add(hint);
            row.Children.Add(left);
            _toolbar.HorizontalAlignment = HorizontalAlignment.Right;
            foreach (int n in new[] { 2, 3, 4 })
            {
                int count = n;
                var b = Ui.Pill(n + " ventanas", () => SetCount(count), G.Tiles);
                b.Margin = new Thickness(10, 0, 0, 0);
                b.Tag = n;
                _layoutBtns.Add(b);
                _toolbar.Children.Add(b);
            }
            var change = Ui.Primary("Cambiar canal", () => OpenPicker(), G.List);
            change.Margin = new Thickness(16, 0, 0, 0);
            _toolbar.Children.Add(change);
            row.Children.Add(_toolbar);
            bar.Child = row;
            _ov.Children.Add(bar);

            // Selector de canal
            _picker.Width = 860;
            _picker.Height = 620;
            _picker.CornerRadius = new CornerRadius(24);
            _picker.Background = Ui.Gradient("#F7221838", "#F7120D1C", 90);
            _picker.BorderBrush = Ui.Hex("#55A782E8");
            _picker.BorderThickness = new Thickness(1.2);
            _picker.Padding = new Thickness(24);
            _picker.Effect = Ui.Shadow(40, 0.7);
            var pg = new Grid();
            pg.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            pg.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            pg.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            pg.Children.Add(_pickTitle);
            var sbox = new Grid { Margin = new Thickness(0, 12, 0, 12) };
            _search.Style = Ui.S("Field");
            _search.Height = 46;
            _search.Padding = new Thickness(42, 0, 12, 0);
            sbox.Children.Add(_search);
            var si = Ui.Icon(G.Search, 15, Ui.B("Text3"));
            si.HorizontalAlignment = HorizontalAlignment.Left;
            si.Margin = new Thickness(15, 0, 0, 0);
            si.IsHitTestVisible = false;
            sbox.Children.Add(si);
            var sh = Ui.T("Buscar canal por nombre o número", 15, Ui.B("Text3"));
            sh.VerticalAlignment = VerticalAlignment.Center;
            sh.Margin = new Thickness(44, 0, 0, 0);
            sh.IsHitTestVisible = false;
            sbox.Children.Add(sh);
            _search.TextChanged += (s, e) =>
            {
                sh.Visibility = _search.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
                _searchTimer?.Stop();
                _searchTimer = UiThread.After(220, RunSearch);
            };
            Grid.SetRow(sbox, 1);
            pg.Children.Add(sbox);
            var lists = new Grid();
            lists.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(280) });
            lists.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _cats.Style = Ui.S("PlainList");
            _cats.ItemContainerStyle = Ui.S("RowItem");
            _cats.ItemTemplate = (DataTemplate)Application.Current.Resources["CatTemplate"];
            _cats.Margin = new Thickness(0, 0, 12, 0);
            lists.Children.Add(_cats);
            _channels.Style = Ui.S("PlainList");
            _channels.ItemContainerStyle = Ui.S("RowItem");
            _channels.ItemTemplate = (DataTemplate)Application.Current.Resources["ChannelTemplate"];
            Grid.SetColumn(_channels, 1);
            lists.Children.Add(_channels);
            Grid.SetRow(lists, 2);
            pg.Children.Add(lists);
            _picker.Child = pg;
            _ov.Children.Add(_picker);

            _cats.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var c = ItemsControl.ContainerFromElement(_cats, e.OriginalSource as DependencyObject) as ListBoxItem;
                if (c?.DataContext is CatEntry ce) ApplyCat(ce);
            };
            _channels.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var c = ItemsControl.ContainerFromElement(_channels, e.OriginalSource as DependencyObject) as ListBoxItem;
                if (c?.DataContext is Item it) Assign(it);
            };

            for (int i = 0; i < Max; i++)
            {
                var w = _wins[i];
                var win = w;
                w.Frame = new Border { BorderThickness = new Thickness(3), CornerRadius = new CornerRadius(14), Background = new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)), Cursor = Cursors.Hand };
                var g = new Grid();
                w.Label = Ui.T("", 15, Brushes.White, FontWeights.SemiBold);
                w.Label.VerticalAlignment = VerticalAlignment.Center;
                w.Speaker = Ui.Icon(G.Volume, 15, Ui.B("Accent"));
                w.Speaker.VerticalAlignment = VerticalAlignment.Center;
                w.Speaker.Margin = new Thickness(0, 0, 8, 0);
                var lrow = new StackPanel { Orientation = Orientation.Horizontal };
                lrow.Children.Add(w.Speaker);
                lrow.Children.Add(w.Label);
                var lb = new Border { Background = Ui.Hex("#B30B0812"), CornerRadius = new CornerRadius(10), Padding = new Thickness(12, 6, 12, 6), Margin = new Thickness(12), HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top, Child = lrow, MaxWidth = 420 };
                g.Children.Add(lb);
                w.State = Ui.T("", 15, Brushes.White, FontWeights.SemiBold);
                w.State.HorizontalAlignment = HorizontalAlignment.Center;
                w.State.VerticalAlignment = VerticalAlignment.Center;
                w.State.TextWrapping = TextWrapping.Wrap;
                w.State.TextAlignment = TextAlignment.Center;
                w.State.Margin = new Thickness(16);
                g.Children.Add(w.State);
                // Botones de cada ventana: cambiar canal y verla en grande (sin doble clic).
                var btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 10, 10, 0) };
                var pick = Ui.Round(G.List, () => { SetActive(win.Index); OpenPicker(); }, "Cambiar canal de esta ventana");
                var big = Ui.Round(G.Full, () => { if (win.Channel != null) OpenFull(win); }, "Ver en grande");
                foreach (var b in new[] { pick, big })
                {
                    b.Width = 40;
                    b.Height = 40;
                    b.FontSize = 15;
                    b.Focusable = false;
                    b.Margin = new Thickness(8, 0, 0, 0);
                    btns.Children.Add(b);
                }
                g.Children.Add(btns);
                w.Frame.Child = g;
                w.Frame.MouseLeftButtonDown += (s, e) =>
                {
                    SetActive(win.Index);
                    if (win.Channel == null) OpenPicker();
                };
                _ovCanvas.Children.Add(w.Frame);
            }
        }

        // ------------------------------------------------------- ciclo de vida

        public override void OnShow()
        {
            Playback.MultiOpen = true;
            Catalog.Changed += OnCatalog;
            _watch = UiThread.Every(1000, Watch);
            if (_count > Math.Max(2, _maxConn)) _count = Math.Max(2, _maxConn);
            OnCatalog();
            LayoutWindows();
            Authorize(true);
            if (_maxConn < 2)
                Dialogs.Message("Multipantalla", "Tu cuenta permite ver 1 canal a la vez. Para ver varios canales juntos necesitas una cuenta con 2 o más conexiones.");
        }

        public override void OnHide()
        {
            Playback.MultiOpen = false;
            Catalog.Changed -= OnCatalog;
            _poll?.Stop();
            _watch?.Stop();
            _seq++;
            foreach (var w in _wins)
            {
                try { w.Player?.Dispose(); } catch { }
                w.Player = null;
                w.Url = null;
            }
            Prefs.S.MultiIds = _wins.Select(w => w.Channel?.Id ?? 0).ToList();
            Prefs.S.MultiCount = _count;
            Prefs.Save();
            Main.Activate();
        }

        public override void FocusFirst()
        {
            Main.Overlay?.Activate();
            _ov.Focusable = true;
            _ov.Focus();
        }

        public override bool OnBack()
        {
            if (_picker.Visibility == Visibility.Visible) { ClosePicker(); return true; }
            return false;
        }

        private void OnHost(Win w, IntPtr hwnd)
        {
            try
            {
                if (w.Player != null || Main.Current != this) return;
                w.Player = MpvPlayer.Create(hwnd, true);
                var win = w;
                w.Player.EndFile += (reason, err) => UiThread.Post(() => OnEnd(win, reason));
                if (_authorized && w.Index < _count && w.Url == null) StartWin(w);
            }
            catch (Exception e)
            {
                Log.Error(e, "Multi mpv");
                w.State.Text = "No se pudo iniciar el video";
            }
        }

        private void OnCatalog()
        {
            var s = Catalog.Snap;
            if (s == null) return;
            // La ventana 1 empieza con el canal que estabas viendo; las demás vacías para que elijas.
            if (_wins.All(w => w.Channel == null))
                _wins[0].Channel = s.Find(Kind.Live, Prefs.S.LastLiveId) ?? s.Live.FirstOrDefault(i => !s.IsAdultItem(i));
            if (_entries.Count == 0) BuildCats(s);
            Paint();
            if (_authorized) foreach (var w in _wins.Take(_count)) if (w.Player != null && !w.Player.Disposed && w.Url == null) StartWin(w);
        }

        // ------------------------------------------------------- autorización

        private async void Authorize(bool start)
        {
            int my = ++_seq;
            if (start) foreach (var w in _wins.Take(_count)) if (w.Channel != null) w.State.Text = "Conectando…";
            var d = await Cloud.Verify();
            if (my != _seq) return;
            if (!d.Allowed)
            {
                foreach (var w in _wins) { w.Player?.Stop(); w.Url = null; w.State.Text = d.Message; }
                _authorized = false;
                Dialogs.Message("Acceso a tu servicio", d.Message);
                return;
            }
            _authorized = true;
            // Solo arranca lo que no está sonando: la revisión de cada 25 s no toca el video.
            for (int i = 0; i < _count; i++) if (_wins[i].Url == null) StartWin(_wins[i]);
            _poll?.Stop();
            _poll = UiThread.After(25000, () => Authorize(false));
        }

        private void StartWin(Win w)
        {
            if (w.Channel == null) { w.State.Text = "＋  Elegir canal\n(clic o Enter)"; w.Url = null; return; }
            if (w.Index >= _maxConn)
            {
                w.State.Text = "Tu cuenta permite " + _maxConn + (_maxConn == 1 ? " canal" : " canales") + " a la vez";
                w.Url = null;
                return;
            }
            if (w.Player == null) { w.State.Text = "Conectando…"; return; }
            w.State.Text = "Conectando…";
            w.Retries = 0;
            w.Url = Xtream.LiveUrl(Prefs.Account(), w.Channel.Id, Prefs.S.LiveFormat == "m3u8" ? "m3u8" : "ts");
            w.Player.Load(w.Url);
            w.Player.SetMute(w.Index != _active);
            Paint();
        }

        private void OnEnd(Win w, int reason)
        {
            if (Main.Current != this || w.Player == null || w.Url == null || reason == MpvNative.EndStop || reason == MpvNative.EndQuit) return;
            if (w.Retries < 30 && _authorized && w.Channel != null)
            {
                w.Retries++;
                w.State.Text = w.Retries > 2 ? "Reconectando…" : "";
                var win = w;
                int delay = Math.Min(5000, 400 * w.Retries);
                UiThread.After(delay, () =>
                {
                    if (Main.Current != this || win.Player == null || win.Channel == null || win.Url == null) return;
                    // Cada tercer intento prueba el otro formato (.ts ↔ .m3u8).
                    string fmt = Prefs.S.LiveFormat == "m3u8" ? "m3u8" : "ts";
                    if (win.Retries % 3 == 0) fmt = fmt == "ts" ? "m3u8" : "ts";
                    win.Url = Xtream.LiveUrl(Prefs.Account(), win.Channel.Id, fmt);
                    win.Player.Load(win.Url);
                    win.Player.SetMute(win.Index != _active);
                });
            }
            else w.State.Text = "Canal no disponible. Enter para elegir otro.";
        }

        /// <summary>Estado de cada ventana (cargando / reproduciendo).</summary>
        private void Watch()
        {
            foreach (var w in _wins.Take(_count))
            {
                var p = w.Player;
                if (p == null || w.Channel == null) continue;
                if (!p.CoreIdle && !p.Buffering && p.Position > 0)
                {
                    if (w.State.Text.Length > 0 && !w.State.Text.StartsWith("Canal no")) w.State.Text = "";
                    w.Retries = 0;
                }
                else if (p.Buffering && w.State.Text.Length == 0) w.State.Text = "Cargando…";
            }
        }

        // ------------------------------------------------------------ medidas

        private List<Rect> Rects(int n, double W, double H, double g)
        {
            var list = new List<Rect>();
            if (n == 2)
            {
                double w = (W - g) / 2, h = w * 9 / 16;
                if (h > H) { h = H; w = h * 16 / 9; }
                double x0 = (W - (2 * w + g)) / 2, y0 = (H - h) / 2;
                list.Add(new Rect(x0, y0, w, h));
                list.Add(new Rect(x0 + w + g, y0, w, h));
            }
            else if (n == 3)
            {
                double bw = (W - g) / 1.5, bh = bw * 9 / 16;
                if (bh > H) { bh = H; bw = bh * 16 / 9; }
                double sh = (bh - g) / 2, sw = sh * 16 / 9;
                double total = bw + g + sw;
                double x0 = (W - total) / 2, y0 = (H - bh) / 2;
                list.Add(new Rect(x0, y0, bw, bh));
                list.Add(new Rect(x0 + bw + g, y0, sw, sh));
                list.Add(new Rect(x0 + bw + g, y0 + sh + g, sw, sh));
            }
            else
            {
                double w = (W - g) / 2, h = w * 9 / 16;
                if (2 * h + g > H) { h = (H - g) / 2; w = h * 16 / 9; }
                double x0 = (W - (2 * w + g)) / 2, y0 = (H - (2 * h + g)) / 2;
                list.Add(new Rect(x0, y0, w, h));
                list.Add(new Rect(x0 + w + g, y0, w, h));
                list.Add(new Rect(x0, y0 + h + g, w, h));
                list.Add(new Rect(x0 + w + g, y0 + h + g, w, h));
            }
            return list;
        }

        private void LayoutWindows()
        {
            double W = ActualWidth - 72, H = ActualHeight - 120 - 30;
            if (W <= 0 || H <= 0) return;
            var rects = Rects(_count, W, H, 14);
            for (int i = 0; i < Max; i++)
            {
                var w = _wins[i];
                if (i < _count)
                {
                    var r = rects[i];
                    r.Offset(36, 120);
                    w.Rect = r;
                    Canvas.SetLeft(w.Host, Math.Round(r.X));
                    Canvas.SetTop(w.Host, Math.Round(r.Y));
                    w.Host.Width = Math.Round(r.Width);
                    w.Host.Height = Math.Round(r.Height);
                    w.Host.Visibility = Visibility.Visible;
                    Canvas.SetLeft(w.Frame, Math.Round(r.X) - 3);
                    Canvas.SetTop(w.Frame, Math.Round(r.Y) - 3);
                    w.Frame.Width = Math.Round(r.Width) + 6;
                    w.Frame.Height = Math.Round(r.Height) + 6;
                    w.Frame.Visibility = Visibility.Visible;
                }
                else
                {
                    w.Host.Visibility = Visibility.Collapsed;
                    w.Frame.Visibility = Visibility.Collapsed;
                }
            }
            Paint();
        }

        private void Paint()
        {
            for (int i = 0; i < Max; i++)
            {
                var w = _wins[i];
                bool on = i == _active;
                w.Frame.BorderBrush = on ? Ui.B("Accent") : Ui.Hex("#33FFFFFF");
                w.Label.Text = w.Channel == null ? "Ventana " + (i + 1) : (w.Channel.Num > 0 ? w.Channel.Num + "  " : "") + w.Channel.Name;
                w.Speaker.Visibility = on ? Visibility.Visible : Visibility.Collapsed;
            }
            foreach (var b in _layoutBtns)
            {
                bool sel = b.Tag is int n && n == _count;
                b.BorderBrush = sel ? Ui.B("Accent") : Ui.Hex("#FF3A2D58");
            }
        }

        private void SetCount(int n)
        {
            if (n == _count) return;
            if (n > _maxConn && _maxConn >= 2)
            {
                Main.Toast("Tu cuenta permite " + _maxConn + " canales a la vez");
                return;
            }
            int old = _count;
            _count = n;
            for (int i = n; i < Max; i++) { _wins[i].Player?.Stop(); _wins[i].Url = null; }
            if (_active >= n) _active = 0;
            LayoutWindows();
            if (_authorized) for (int i = old; i < n; i++) if (_wins[i].Url == null) StartWin(_wins[i]);
            SetActive(_active);
        }

        private void SetActive(int i)
        {
            _active = Math.Max(0, Math.Min(_count - 1, i));
            // El audio sigue a la ventana elegida.
            foreach (var w in _wins) w.Player?.SetMute(w.Index != _active);
            Paint();
        }

        private void OpenFull(Win w)
        {
            var ch = w.Channel;
            Main.Replace(new LivePage(ch.Id, null));
        }

        // ------------------------------------------------------------ selector

        private void BuildCats(Snapshot s)
        {
            bool adult = Prefs.S.ShowAdult && !(Profiles.Current()?.Kids ?? false);
            var list = new List<CatEntry>
            {
                new CatEntry { Key = "recent", Name = "Recientes", Items = () => Library.RecentLive().Select(id => s.Find(Kind.Live, id)).Where(i => i != null).ToList() },
                new CatEntry { Key = "fav", Name = "Mis canales", Items = () => Library.Favorites().Where(f => f.Kind == Kind.Live).Select(f => s.Find(Kind.Live, f.Id)).Where(i => i != null).ToList() },
                new CatEntry { Key = "events", Name = "Eventos", Items = () => Scopes.Events(s) },
                new CatEntry { Key = "all", Name = "Todos", Items = () => s.Live.Where(i => adult || !s.IsAdultItem(i)).ToList() }
            };
            foreach (var c in s.LiveCats)
            {
                if (c.Adult && !adult) continue;
                var cat = c;
                int n = s.ItemsOf(Kind.Live, c.Id).Count;
                if (n > 0) list.Add(new CatEntry { Key = c.Id, Name = c.Name, Count = n.ToString(), Items = () => s.ItemsOf(Kind.Live, cat.Id) });
            }
            _entries = list;
            _cats.ItemsSource = _entries;
            ApplyCat(_entries.FirstOrDefault(e => e.Key == "all"));
        }

        private void ApplyCat(CatEntry e)
        {
            if (e == null) return;
            foreach (var x in _entries) x.Applied = x == e;
            _shown = e.Items() ?? new List<Item>();
            _channels.ItemsSource = _shown;
        }

        private void RunSearch()
        {
            var s = Catalog.Snap;
            if (s == null) return;
            string q = TextUtil.Norm(_search.Text.Trim());
            if (q.Length == 0) { ApplyCat(_entries.FirstOrDefault(x => x.Applied)); return; }
            int num;
            bool isNum = int.TryParse(q, out num);
            _shown = s.Live.Where(i => (Prefs.S.ShowAdult || !s.IsAdultItem(i)) && (i.Norm.Contains(q) || (isNum && i.Num == num))).Take(300).ToList();
            _channels.ItemsSource = _shown;
        }

        private void OpenPicker()
        {
            _pickTitle.Text = "Canal para la ventana " + (_active + 1);
            _picker.Visibility = Visibility.Visible;
            // Las ventanas de video quedan debajo: se ocultan mientras se elige.
            foreach (var w in _wins) w.Host.Visibility = Visibility.Hidden;
            Main.Overlay?.Activate();
            var cur = _entries.FirstOrDefault(x => x.Applied);
            _cats.SelectedItem = cur;
            // Se abre con el buscador listo: escribe el nombre o número del canal, ▼ baja a la lista.
            _search.Text = "";
            Dispatcher.BeginInvoke(new Action(() => _search.Focus()), DispatcherPriority.Loaded);
        }

        private void ClosePicker()
        {
            _picker.Visibility = Visibility.Collapsed;
            LayoutWindows();
            _ov.Focus();
        }

        private void Assign(Item it)
        {
            if (it == null) return;
            var w = _wins[_active];
            w.Channel = it;
            Library.AddRecentLive(it.Id);
            ClosePicker();
            if (_authorized) StartWin(w);
            else Authorize(true);
        }

        // ------------------------------------------------------------ teclado

        public override bool OnKey(KeyEventArgs e)
        {
            if (_picker.Visibility == Visibility.Visible)
            {
                if (_cats.IsKeyboardFocusWithin)
                {
                    if (e.Key == Key.Enter) { ApplyCat(_cats.SelectedItem as CatEntry); return true; }
                    if (e.Key == Key.Right) { (_channels.ItemContainerGenerator.ContainerFromIndex(Math.Max(0, _channels.SelectedIndex)) as ListBoxItem)?.Focus(); return true; }
                }
                else if (_channels.IsKeyboardFocusWithin)
                {
                    if (e.Key == Key.Enter) { Assign(_channels.SelectedItem as Item); return true; }
                    if (e.Key == Key.Left) { (_cats.ItemContainerGenerator.ContainerFromItem(_cats.SelectedItem) as ListBoxItem)?.Focus(); return true; }
                }
                else if (_search.IsKeyboardFocusWithin && (e.Key == Key.Down || e.Key == Key.Enter))
                {
                    (_channels.ItemContainerGenerator.ContainerFromIndex(0) as ListBoxItem)?.Focus();
                    return true;
                }
                return false;
            }
            if (e.OriginalSource is Button && (e.Key == Key.Enter || e.Key == Key.Space)) return false;
            switch (e.Key)
            {
                case Key.Left: SetActive(_count == 3 && _active == 2 ? 0 : _active - 1); return true;
                case Key.Right: SetActive(_count == 3 && _active == 0 ? 1 : _active + 1); return true;
                case Key.Up: if (_count == 4 && _active >= 2) SetActive(_active - 2); else if (_count == 3 && _active == 2) SetActive(1); return true;
                case Key.Down: if (_count == 4 && _active < 2) SetActive(_active + 2); else if (_count == 3 && _active == 1) SetActive(2); return true;
                case Key.Enter: OpenPicker(); return true;
                case Key.D1: case Key.NumPad1: SetActive(0); return true;
                case Key.D2: case Key.NumPad2: SetActive(1); return true;
                case Key.D3: case Key.NumPad3: SetActive(2); return true;
                case Key.D4: case Key.NumPad4: SetActive(3); return true;
                case Key.F: Main.ToggleFullscreen(); return true;
            }
            return false;
        }
    }
}
