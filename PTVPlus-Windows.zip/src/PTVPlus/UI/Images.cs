using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using PTVPlus.Core;

namespace PTVPlus.UI
{
    /// <summary>
    /// Imágenes de internet con caché en disco y en memoria, descargadas en paralelo y reducidas
    /// al tamaño en pantalla (poca memoria y desplazamiento fluido).
    /// </summary>
    public static class Images
    {
        private static readonly SemaphoreSlim Gate = new SemaphoreSlim(8);
        private static readonly object MemGate = new object();
        private static readonly Dictionary<string, LinkedListNode<KeyValuePair<string, BitmapSource>>> Map =
            new Dictionary<string, LinkedListNode<KeyValuePair<string, BitmapSource>>>();
        private static readonly LinkedList<KeyValuePair<string, BitmapSource>> Lru = new LinkedList<KeyValuePair<string, BitmapSource>>();
        private const int MemMax = 500;
        private static string _dir;
        private static bool _pruned;

        private static string Dir()
        {
            if (_dir == null)
            {
                _dir = Paths.Dir("img");
                if (!_pruned)
                {
                    _pruned = true;
                    Task.Run(() => Prune(_dir));
                }
            }
            return _dir;
        }

        /// <summary>La caché en disco no pasa de ~400 MB (se borran las más viejas).</summary>
        private static void Prune(string dir)
        {
            try
            {
                var files = new DirectoryInfo(dir).GetFiles().OrderByDescending(f => f.LastAccessTimeUtc).ToList();
                long total = 0;
                foreach (var f in files)
                {
                    total += f.Length;
                    if (total > 400L * 1024 * 1024) { try { f.Delete(); } catch { } }
                }
            }
            catch { }
        }

        private static BitmapSource FromMem(string key)
        {
            lock (MemGate)
            {
                LinkedListNode<KeyValuePair<string, BitmapSource>> n;
                if (!Map.TryGetValue(key, out n)) return null;
                Lru.Remove(n);
                Lru.AddFirst(n);
                return n.Value.Value;
            }
        }

        private static void ToMem(string key, BitmapSource b)
        {
            lock (MemGate)
            {
                LinkedListNode<KeyValuePair<string, BitmapSource>> n;
                if (Map.TryGetValue(key, out n)) { Lru.Remove(n); Map.Remove(key); }
                var node = new LinkedListNode<KeyValuePair<string, BitmapSource>>(new KeyValuePair<string, BitmapSource>(key, b));
                Lru.AddFirst(node);
                Map[key] = node;
                while (Lru.Count > MemMax)
                {
                    var last = Lru.Last;
                    Lru.RemoveLast();
                    Map.Remove(last.Value.Key);
                }
            }
        }

        public static async Task<BitmapSource> Get(string url, int decodeWidth)
        {
            if (string.IsNullOrWhiteSpace(url)) return null;
            string key = url + "|" + decodeWidth;
            var hit = FromMem(key);
            if (hit != null) return hit;
            string file = Path.Combine(Dir(), Paths.Hash(url));
            byte[] data = null;
            try
            {
                if (File.Exists(file))
                {
                    data = await File.ReadAllBytesAsync(file).ConfigureAwait(false);
                    try { File.SetLastAccessTimeUtc(file, DateTime.UtcNow); } catch { }
                }
            }
            catch { data = null; }
            if (data == null || data.Length == 0)
            {
                await Gate.WaitAsync().ConfigureAwait(false);
                try
                {
                    data = await Net.GetBytes(url, 15000).ConfigureAwait(false);
                    if (data != null && data.Length > 0)
                    {
                        try { await File.WriteAllBytesAsync(file, data).ConfigureAwait(false); } catch { }
                    }
                }
                catch
                {
                    return null;
                }
                finally
                {
                    Gate.Release();
                }
            }
            if (data == null || data.Length == 0) return null;
            var bmp = await Task.Run(() => Decode(data, decodeWidth)).ConfigureAwait(false);
            if (bmp != null) ToMem(key, bmp);
            return bmp;
        }

        private static BitmapSource Decode(byte[] data, int decodeWidth)
        {
            try
            {
                var bi = new BitmapImage();
                using (var ms = new MemoryStream(data))
                {
                    bi.BeginInit();
                    bi.CacheOption = BitmapCacheOption.OnLoad;
                    bi.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
                    if (decodeWidth > 0) bi.DecodePixelWidth = decodeWidth;
                    bi.StreamSource = ms;
                    bi.EndInit();
                }
                bi.Freeze();
                return bi;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>Pone la imagen en el control cuando llega (si el control sigue mostrando ese enlace).</summary>
        public static async void Load(Image target, string url, int decodeWidth)
        {
            if (target == null) return;
            target.Tag = url;
            var cached = string.IsNullOrWhiteSpace(url) ? null : FromMem(url + "|" + decodeWidth);
            target.Source = cached;
            if (cached != null || string.IsNullOrWhiteSpace(url)) return;
            var bmp = await Get(url, decodeWidth);
            if (bmp != null && Equals(target.Tag, url)) target.Source = bmp;
        }

        /// <summary>
        /// Pone la imagen como fondo de un recuadro con esquinas redondeadas (sin recortes extra:
        /// mucho más ligero al desplazar filas con muchas tarjetas) y oculta el texto de respaldo.
        /// </summary>
        public static async void LoadInto(Border target, UIElement placeholder, string url, int decodeWidth)
        {
            if (target == null || string.IsNullOrWhiteSpace(url)) return;
            target.Tag = url;
            var bmp = FromMem(url + "|" + decodeWidth) ?? await Get(url, decodeWidth);
            if (bmp == null || !Equals(target.Tag, url)) return;
            var brush = new ImageBrush(bmp) { Stretch = Stretch.UniformToFill };
            RenderOptions.SetBitmapScalingMode(brush, BitmapScalingMode.Linear);
            brush.Freeze();
            target.Background = brush;
            if (placeholder != null) placeholder.Visibility = Visibility.Collapsed;
        }

        private static readonly Dictionary<string, BitmapImage> Packs = new Dictionary<string, BitmapImage>();

        /// <summary>Imagen incluida en la app (Assets).</summary>
        public static BitmapImage Asset(string path)
        {
            BitmapImage b;
            if (Packs.TryGetValue(path, out b)) return b;
            try
            {
                b = new BitmapImage();
                b.BeginInit();
                b.UriSource = new Uri("pack://application:,,,/Assets/" + path, UriKind.Absolute);
                b.CacheOption = BitmapCacheOption.OnLoad;
                b.EndInit();
                b.Freeze();
                Packs[path] = b;
                return b;
            }
            catch (Exception e)
            {
                Log.Error(e, "Asset " + path);
                return null;
            }
        }

        public static BitmapImage Avatar(int index) => Asset("avatars/a" + Math.Max(0, Math.Min(12, index)) + ".png");
    }

    /// <summary>Propiedades para cargar imágenes desde listas (plantillas de canales).</summary>
    public static class Img
    {
        public static readonly DependencyProperty DecodeWidthProperty =
            DependencyProperty.RegisterAttached("DecodeWidth", typeof(int), typeof(Img), new PropertyMetadata(160));

        public static int GetDecodeWidth(DependencyObject o) => (int)o.GetValue(DecodeWidthProperty);
        public static void SetDecodeWidth(DependencyObject o, int v) => o.SetValue(DecodeWidthProperty, v);

        public static readonly DependencyProperty SrcProperty =
            DependencyProperty.RegisterAttached("Src", typeof(string), typeof(Img), new PropertyMetadata(null, OnSrc));

        public static string GetSrc(DependencyObject o) => (string)o.GetValue(SrcProperty);
        public static void SetSrc(DependencyObject o, string v) => o.SetValue(SrcProperty, v);

        private static void OnSrc(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var img = d as Image;
            if (img == null) return;
            Images.Load(img, e.NewValue as string, GetDecodeWidth(img));
        }
    }
}
