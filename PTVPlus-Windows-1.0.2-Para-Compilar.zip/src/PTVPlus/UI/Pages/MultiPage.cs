using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// Multipantalla: 2, 3 o 4 canales a la vez. El audio sigue a la ventana elegida; cada canal
    /// se cambia con un buscador. Cloud autoriza al abrir y cada 25 s.
    /// </summary>
    public sealed class MultiPage : Page
    {
        private sealed class Win
        {
            public int Index;
            public VideoHost Host;
            public MpvPlayer Player;
            public Item Channel;
            public Border Frame;
            public TextBlock Label;
            public TextBlock State;
            public Rect Rect;
            public int Retries;
        }

        private const int Max = 4;
        private readonly Canvas _canvas = new Canvas { ClipToBounds = true };
        private readonly Grid _ov = new Grid();
        private readonly Canvas _ovCanvas = new Canvas();
        private readonly StackPanel _toolbar = new StackPanel { Orientation = Orientation.Horizontal };
        private readonly Border _picker = new Border { Visibility = Visibility.Collapsed, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        private readonly ListBox _cats = new ListBox();
        private readonly ListBox _channels = new ListBox();
        private readonly TextBox _search = new TextBox();
        private readonly TextBlock _pickTitle = Ui.T("", 20, Brushes.White, FontWeights.Bold);
        private readonly List<Win> _wins = new List<Win>();
        private List<CatEntry> _entries = new List<CatEntry>();
        private List<Item> _shown = new List<Item>();
        private int _count;
        private int _active;
        private bool _authorized;
        private int _seq;
        private DispatcherTimer _poll, _searchTimer, _watch;
        private readonly List<Button> _layoutBtns = new List<Button>();

        public override UIElement OverlayContent => _ov;

        public MultiPage()
        {
            Background = Ui.B("Bg");
            _count = Math.Max(2, Math.Min(4, Prefs.S.MultiCount));
            Children.Add(_canvas);
            for (int i = 0; i < Max; i++)
            {
                var w = new Win { Index = i, Host = new VideoHost { Visibility = Visibility.Collapsed } };
                var win = w;
                w.Host.Created += h => OnHost(win, h);
                _canvas.Children.Add(w.Host);
                _wins.Add(w);
            }
            BuildOverlay();
            SizeChanged += (s, e) => { LayoutWindows(); ResizePicker(); };
        }

        // ------------------------------------------------------------ capa

        private void BuildOverlay()
        {
            _ov.Children.Add(_ovCanvas);
            var bar = new Border
            {
                VerticalAlignment = VerticalAlignment.Top, Background = Ui.Gradient("#F20B0812", "#000B0812", 90),
                Padding = new Thickness(26, 12, 26, 12)
            };
            // Dos renglones: la barra de opciones no se monta sobre el título
            // cuando la ventana cambia de tamaño o la escala de Windows es 125/150%.
            var row = new Grid();
            row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            var left = new StackPanel { Orientation = Orientation.Horizontal };
            left.Children.Add(Ui.Round(G.Back, () => Main.Back(), "Atrás"));
            var t = Ui.T("Multipantalla", 23, Brushes.White, FontWeights.Bold);
            t.VerticalAlignment = VerticalAlignment.Center;
            t.Margin = new Thickness(14, 0, 0, 0);
            left.Children.Add(t);
            row.Children.Add(left);
            _toolbar.HorizontalAlignment = HorizontalAlignment.Left;
            _toolbar.Margin = new Thickness(0, 10, 0, 0);
            foreach (int n in new[] { 2, 3, 4 })
            {
                int count = n;
                var b = Ui.Pill(n + " vistas", () => SetCount(count), G.Tiles);
                b.Margin = new Thickness(0, 0, 8, 0);
                b.Tag = n;
                _layoutBtns.Add(b);
                _toolbar.Children.Add(b);
            }
            var change = Ui.Primary("Cambiar canal", () => OpenPicker(), G.List);
            change.Margin = new Thickness(8, 0, 0, 0);
            _toolbar.Children.Add(change);
            Grid.SetRow(_toolbar, 1);
            row.Children.Add(_toolbar);
            bar.Child = row;
            _ov.Children.Add(bar);

            // Selector de canal
            _picker.Width = 860;
            _picker.Height = 620;
            _picker.CornerRadius = new CornerRadius(24);
            _picker.Background = Ui.Gradient("#F7221838", "#F7120D1C", 90);
            _picker.BorderBrush = Ui.Hex("#55A782E8");
            _picker.BorderThickness = new Thickness(1.2);
            _picker.Padding = new Thickness(24);
            _picker.Effect = Ui.Shadow(40, 0.7);
            var pg = new Grid();
            pg.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            pg.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            pg.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            pg.Children.Add(_pickTitle);
            _search.Style = Ui.S("Field");
            _search.Height = 46;
            _search.Margin = new Thickness(0, 12, 0, 12);
            _search.TextChanged += (s, e) => { _searchTimer?.Stop(); _searchTimer = UiThread.After(220, RunSearch); };
            Grid.SetRow(_search, 1);
            pg.Children.Add(_search);
            var lists = new Grid();
            lists.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(280) });
            lists.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _cats.Style = Ui.S("PlainList");
            _cats.ItemContainerStyle = Ui.S("RowItem");
            _cats.ItemTemplate = (DataTemplate)Application.Current.Resources["CatTemplate"];
            _cats.Margin = new Thickness(0, 0, 12, 0);
            lists.Children.Add(_cats);
            _channels.Style = Ui.S("PlainList");
            _channels.ItemContainerStyle = Ui.S("RowItem");
            _channels.ItemTemplate = (DataTemplate)Application.Current.Resources["ChannelTemplate"];
            Grid.SetColumn(_channels, 1);
            lists.Children.Add(_channels);
            Grid.SetRow(lists, 2);
            pg.Children.Add(lists);
            _picker.Child = pg;
            _ov.Children.Add(_picker);

            _cats.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var c = ItemsControl.ContainerFromElement(_cats, e.OriginalSource as DependencyObject) as ListBoxItem;
                if (c?.DataContext is CatEntry ce) ApplyCat(ce);
            };
            _channels.PreviewMouseLeftButtonUp += (s, e) =>
            {
                var c = ItemsControl.ContainerFromElement(_channels, e.OriginalSource as DependencyObject) as ListBoxItem;
                if (c?.DataContext is Item it) Assign(it);
            };

            for (int i = 0; i < Max; i++)
            {
                var w = _wins[i];
                var win = w;
                w.Frame = new Border { BorderThickness = new Thickness(3), CornerRadius = new CornerRadius(14), Background = new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)), Cursor = Cursors.Hand };
                var g = new Grid();
                w.Label = Ui.T("", 14, Brushes.White, FontWeights.SemiBold);
                w.Label.TextTrimming = TextTrimming.CharacterEllipsis;
                var lb = new Border { Background = Ui.Hex("#B30B0812"), CornerRadius = new CornerRadius(10), Padding = new Thickness(12, 6, 12, 6), Margin = new Thickness(12), HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top, Child = w.Label };
                g.Children.Add(lb);
                w.State = Ui.T("", 15, Brushes.White, FontWeights.SemiBold);
                w.State.HorizontalAlignment = HorizontalAlignment.Center;
                w.State.VerticalAlignment = VerticalAlignment.Center;
                w.State.TextWrapping = TextWrapping.Wrap;
                w.State.TextAlignment = TextAlignment.Center;
                w.State.Margin = new Thickness(16);
                g.Children.Add(w.State);
                w.Frame.Child = g;
                w.Frame.MouseLeftButtonDown += (s, e) =>
                {
                    if (e.ClickCount == 2 && win.Channel != null) { OpenFull(win); return; }
                    SetActive(win.Index);
                };
                _ovCanvas.Children.Add(w.Frame);
            }
        }

        private void ResizePicker()
        {
            if (ActualWidth <= 0 || ActualHeight <= 0) return;
            _picker.Width = Math.Max(450, Math.Min(860, ActualWidth - 50));
            _picker.Height = Math.Max(310, Math.Min(620, ActualHeight - 50));
        }

        // ------------------------------------------------------- ciclo de vida

        public override void OnShow()
        {
            Playback.MultiOpen = true;
            Catalog.Changed += OnCatalog;
            _watch = UiThread.Every(1000, Watch);
            OnCatalog();
            LayoutWindows();
            Authorize();
        }

        public override void OnHide()
        {
            Playback.MultiOpen = false;
            Catalog.Changed -= OnCatalog;
            _poll?.Stop();
            _watch?.Stop();
            _seq++;
            foreach (var w in _wins)
            {
                try { w.Player?.Dispose(); } catch { }
                w.Player = null;
            }
            Prefs.S.MultiIds = _wins.Select(w => w.Channel?.Id ?? 0).ToList();
            Prefs.S.MultiCount = _count;
            Prefs.Save();
            Main.Activate();
        }

        public override void FocusFirst()
        {
            Main.Overlay?.Activate();
            _ov.Focusable = true;
            _ov.Focus();
        }

        public override bool OnBack()
        {
            if (_picker.Visibility == Visibility.Visible) { ClosePicker(); return true; }
            return false;
        }

        private void OnHost(Win w, IntPtr hwnd)
        {
            try
            {
                if (w.Player != null || Main.Current != this) return;
                w.Player = MpvPlayer.Create(hwnd, true);
                var win = w;
                w.Player.EndFile += (reason, err) => UiThread.Post(() => OnEnd(win, reason));
                if (_authorized && w.Index < _count) StartWin(w);
            }
            catch (Exception e)
            {
                Log.Error(e, "Multi mpv");
                w.State.Text = "No se pudo iniciar el video";
            }
        }

        private void OnCatalog()
        {
            var s = Catalog.Snap;
            if (s == null) return;
            var ids = Prefs.S.MultiIds ?? new List<int>();
            var recent = Library.RecentLive().Select(id => s.Find(Kind.Live, id)).Where(i => i != null).ToList();
            var pool = recent.Concat(s.Live.Where(i => !s.IsAdultItem(i)).Take(20)).GroupBy(i => i.Id).Select(g => g.First()).ToList();
            for (int i = 0; i < Max; i++)
            {
                var w = _wins[i];
                if (w.Channel != null) continue;
                Item it = i < ids.Count ? s.Find(Kind.Live, ids[i]) : null;
                if (it == null) it = pool.FirstOrDefault(x => _wins.All(o => o.Channel == null || o.Channel.Id != x.Id));
                w.Channel = it;
            }
            BuildCats(s);
            Paint();
            if (_authorized) foreach (var w in _wins.Take(_count)) if (w.Player != null && !w.Player.Disposed && w.Player.CoreIdle) StartWin(w);
        }

        // ------------------------------------------------------- autorización

        private async void Authorize()
        {
            int my = ++_seq;
            foreach (var w in _wins) w.State.Text = "Conectando…";
            var d = await Cloud.Verify();
            if (my != _seq) return;
            if (!d.Allowed)
            {
                foreach (var w in _wins) { w.Player?.Stop(); w.State.Text = d.Message; }
                _authorized = false;
                Dialogs.Message("Acceso a tu servicio", d.Message);
                return;
            }
            _authorized = true;
            for (int i = 0; i < _count; i++) StartWin(_wins[i]);
            _poll?.Stop();
            _poll = UiThread.After(25000, Authorize);
        }

        private void StartWin(Win w)
        {
            if (w.Player == null || w.Channel == null) { w.State.Text = w.Channel == null ? "Enter para elegir canal" : "Conectando…"; return; }
            w.State.Text = "Conectando…";
            w.Retries = 0;
            w.Player.Load(Xtream.LiveUrl(Prefs.Account(), w.Channel.Id, Prefs.S.LiveFormat == "m3u8" ? "m3u8" : "ts"));
            w.Player.SetMute(w.Index != _active);
            Paint();
        }

        private void OnEnd(Win w, int reason)
        {
            if (Main.Current != this || w.Player == null || reason == MpvNative.EndStop || reason == MpvNative.EndQuit) return;
            if (w.Retries < 30 && _authorized && w.Channel != null)
            {
                w.Retries++;
                w.State.Text = w.Retries > 2 ? "Reconectando…" : "";
                var win = w;
                int delay = Math.Min(5000, 400 * w.Retries);
                UiThread.After(delay, () =>
                {
                    if (Main.Current != this || win.Player == null || win.Channel == null) return;
                    // Cada tercer intento prueba el otro formato (.ts ↔ .m3u8).
                    string fmt = Prefs.S.LiveFormat == "m3u8" ? "m3u8" : "ts";
                    if (win.Retries % 3 == 0) fmt = fmt == "ts" ? "m3u8" : "ts";
                    win.Player.Load(Xtream.LiveUrl(Prefs.Account(), win.Channel.Id, fmt));
                    win.Player.SetMute(win.Index != _active);
                });
            }
            else w.State.Text = "Canal no disponible. Enter para elegir otro.";
        }

        /// <summary>Estado de cada ventana (cargando / reproduciendo).</summary>
        private void Watch()
        {
            foreach (var w in _wins.Take(_count))
            {
                var p = w.Player;
                if (p == null || w.Channel == null) continue;
                if (!p.CoreIdle && !p.Buffering && p.Position > 0)
                {
                    if (w.State.Text.Length > 0 && !w.State.Text.StartsWith("Canal no")) w.State.Text = "";
                    w.Retries = 0;
                }
                else if (p.Buffering && w.State.Text.Length == 0) w.State.Text = "Cargando…";
            }
        }

        // ------------------------------------------------------------ medidas

        private List<Rect> Rects(int n, double W, double H, double g)
        {
            var list = new List<Rect>();
            if (n == 2)
            {
                double w = (W - g) / 2, h = w * 9 / 16;
                if (h > H) { h = H; w = h * 16 / 9; }
                double x0 = (W - (2 * w + g)) / 2, y0 = (H - h) / 2;
                list.Add(new Rect(x0, y0, w, h));
                list.Add(new Rect(x0 + w + g, y0, w, h));
            }
            else if (n == 3)
            {
                double bw = (W - g) / 1.5, bh = bw * 9 / 16;
                if (bh > H) { bh = H; bw = bh * 16 / 9; }
                double sh = (bh - g) / 2, sw = sh * 16 / 9;
                double total = bw + g + sw;
                double x0 = (W - total) / 2, y0 = (H - bh) / 2;
                list.Add(new Rect(x0, y0, bw, bh));
                list.Add(new Rect(x0 + bw + g, y0, sw, sh));
                list.Add(new Rect(x0 + bw + g, y0 + sh + g, sw, sh));
            }
            else
            {
                double w = (W - g) / 2, h = w * 9 / 16;
                if (2 * h + g > H) { h = (H - g) / 2; w = h * 16 / 9; }
                double x0 = (W - (2 * w + g)) / 2, y0 = (H - (2 * h + g)) / 2;
                list.Add(new Rect(x0, y0, w, h));
                list.Add(new Rect(x0 + w + g, y0, w, h));
                list.Add(new Rect(x0, y0 + h + g, w, h));
                list.Add(new Rect(x0 + w + g, y0 + h + g, w, h));
            }
            return list;
        }

        private void LayoutWindows()
        {
            double W = ActualWidth - 52, H = ActualHeight - 136 - 18;
            if (W <= 0 || H <= 0) return;
            var rects = Rects(_count, W, H, 14);
            for (int i = 0; i < Max; i++)
            {
                var w = _wins[i];
                if (i < _count)
                {
                    var r = rects[i];
                    r.Offset(26, 136);
                    w.Rect = r;
                    w.Label.MaxWidth = Math.Max(80, r.Width - 48);
                    Canvas.SetLeft(w.Host, Math.Round(r.X));
                    Canvas.SetTop(w.Host, Math.Round(r.Y));
                    w.Host.Width = Math.Round(r.Width);
                    w.Host.Height = Math.Round(r.Height);
                    w.Host.Visibility = Visibility.Visible;
                    Canvas.SetLeft(w.Frame, Math.Round(r.X) - 3);
                    Canvas.SetTop(w.Frame, Math.Round(r.Y) - 3);
                    w.Frame.Width = Math.Round(r.Width) + 6;
                    w.Frame.Height = Math.Round(r.Height) + 6;
                    w.Frame.Visibility = Visibility.Visible;
                }
                else
                {
                    w.Host.Visibility = Visibility.Collapsed;
                    w.Frame.Visibility = Visibility.Collapsed;
                }
            }
            Paint();
        }

        private void Paint()
        {
            for (int i = 0; i < Max; i++)
            {
                var w = _wins[i];
                bool on = i == _active;
                w.Frame.BorderBrush = on ? Ui.B("Accent") : Ui.Hex("#33FFFFFF");
                w.Label.Text = (on ? "🔊  " : "") + (w.Channel == null ? "Sin canal" : w.Channel.Name);
            }
            foreach (var b in _layoutBtns)
            {
                bool sel = b.Tag is int n && n == _count;
                b.BorderBrush = sel ? Ui.B("Accent") : Ui.Hex("#FF3A2D58");
            }
        }

        private void SetCount(int n)
        {
            if (n == _count) return;
            int old = _count;
            _count = n;
            for (int i = n; i < Max; i++) _wins[i].Player?.Stop();
            if (_active >= n) _active = 0;
            LayoutWindows();
            if (_authorized) for (int i = old; i < n; i++) StartWin(_wins[i]);
            SetActive(_active);
        }

        private void SetActive(int i)
        {
            _active = Math.Max(0, Math.Min(_count - 1, i));
            // El audio sigue a la ventana elegida.
            foreach (var w in _wins) w.Player?.SetMute(w.Index != _active);
            Paint();
        }

        private void OpenFull(Win w)
        {
            var ch = w.Channel;
            Main.Replace(new LivePage(ch.Id, null));
        }

        // ------------------------------------------------------------ selector

        private void BuildCats(Snapshot s)
        {
            bool adult = Prefs.S.ShowAdult && !(Profiles.Current()?.Kids ?? false);
            var list = new List<CatEntry>
            {
                new CatEntry { Key = "recent", Name = "Recientes", Items = () => Library.RecentLive().Select(id => s.Find(Kind.Live, id)).Where(i => i != null).ToList() },
                new CatEntry { Key = "fav", Name = "Mis canales", Items = () => Library.Favorites().Where(f => f.Kind == Kind.Live).Select(f => s.Find(Kind.Live, f.Id)).Where(i => i != null).ToList() },
                new CatEntry { Key = "events", Name = "Eventos", Items = () => Scopes.Events(s) },
                new CatEntry { Key = "all", Name = "Todos", Items = () => s.Live.Where(i => adult || !s.IsAdultItem(i)).ToList() }
            };
            foreach (var c in s.LiveCats)
            {
                if (c.Adult && !adult) continue;
                var cat = c;
                int n = s.ItemsOf(Kind.Live, c.Id).Count;
                if (n > 0) list.Add(new CatEntry { Key = c.Id, Name = c.Name, Count = n.ToString(), Items = () => s.ItemsOf(Kind.Live, cat.Id) });
            }
            _entries = list;
            _cats.ItemsSource = _entries;
            ApplyCat(_entries.FirstOrDefault(e => e.Key == "all"));
        }

        private void ApplyCat(CatEntry e)
        {
            if (e == null) return;
            foreach (var x in _entries) x.Applied = x == e;
            _shown = e.Items() ?? new List<Item>();
            _channels.ItemsSource = _shown;
        }

        private void RunSearch()
        {
            var s = Catalog.Snap;
            if (s == null) return;
            string q = TextUtil.Norm(_search.Text.Trim());
            if (q.Length == 0) { ApplyCat(_entries.FirstOrDefault(x => x.Applied)); return; }
            _shown = s.Live.Where(i => (Prefs.S.ShowAdult || !s.IsAdultItem(i)) && i.Norm.Contains(q)).Take(300).ToList();
            _channels.ItemsSource = _shown;
        }

        private void OpenPicker()
        {
            _pickTitle.Text = "Canal para la ventana " + (_active + 1);
            _picker.Visibility = Visibility.Visible;
            // Las ventanas de video quedan debajo: se ocultan mientras se elige.
            foreach (var w in _wins) w.Host.Visibility = Visibility.Hidden;
            Main.Overlay?.Activate();
            var cur = _entries.FirstOrDefault(x => x.Applied);
            _cats.SelectedItem = cur;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (_shown.Count > 0)
                {
                    _channels.SelectedIndex = 0;
                    (_channels.ItemContainerGenerator.ContainerFromIndex(0) as ListBoxItem)?.Focus();
                }
                else _search.Focus();
            }), DispatcherPriority.Loaded);
        }

        private void ClosePicker()
        {
            _picker.Visibility = Visibility.Collapsed;
            LayoutWindows();
            _ov.Focus();
        }

        private void Assign(Item it)
        {
            if (it == null) return;
            var w = _wins[_active];
            w.Channel = it;
            Library.AddRecentLive(it.Id);
            ClosePicker();
            if (_authorized) StartWin(w);
            else Authorize();
        }

        // ------------------------------------------------------------ teclado

        public override bool OnKey(KeyEventArgs e)
        {
            if (_picker.Visibility == Visibility.Visible)
            {
                if (_cats.IsKeyboardFocusWithin)
                {
                    if (e.Key == Key.Enter) { ApplyCat(_cats.SelectedItem as CatEntry); return true; }
                    if (e.Key == Key.Right) { (_channels.ItemContainerGenerator.ContainerFromIndex(Math.Max(0, _channels.SelectedIndex)) as ListBoxItem)?.Focus(); return true; }
                }
                else if (_channels.IsKeyboardFocusWithin)
                {
                    if (e.Key == Key.Enter) { Assign(_channels.SelectedItem as Item); return true; }
                    if (e.Key == Key.Left) { (_cats.ItemContainerGenerator.ContainerFromItem(_cats.SelectedItem) as ListBoxItem)?.Focus(); return true; }
                }
                else if (_search.IsKeyboardFocusWithin && (e.Key == Key.Down || e.Key == Key.Enter))
                {
                    (_channels.ItemContainerGenerator.ContainerFromIndex(0) as ListBoxItem)?.Focus();
                    return true;
                }
                return false;
            }
            if (e.OriginalSource is Button && (e.Key == Key.Enter || e.Key == Key.Space)) return false;
            switch (e.Key)
            {
                case Key.Left: SetActive(_count == 3 && _active == 2 ? 0 : _active - 1); return true;
                case Key.Right: SetActive(_count == 3 && _active == 0 ? 1 : _active + 1); return true;
                case Key.Up: if (_count == 4 && _active >= 2) SetActive(_active - 2); else if (_count == 3 && _active == 2) SetActive(1); return true;
                case Key.Down: if (_count == 4 && _active < 2) SetActive(_active + 2); else if (_count == 3 && _active == 1) SetActive(2); return true;
                case Key.Enter: OpenPicker(); return true;
                case Key.D1: case Key.NumPad1: SetActive(0); return true;
                case Key.D2: case Key.NumPad2: SetActive(1); return true;
                case Key.D3: case Key.NumPad3: SetActive(2); return true;
                case Key.D4: case Key.NumPad4: SetActive(3); return true;
                case Key.F: Main.ToggleFullscreen(); return true;
            }
            return false;
        }
    }
}
