# PTV PLUS Windows 1.0.2 — proyecto para compilar (Windows 10/11 x64)

**Una sola ventana visible de la aplicación:** navegación, reproductor TV, películas,
series, guía y multipantalla permanecen en PTV PLUS. No se abre un reproductor
externo ni se invoca otra aplicación de video. Internamente se usa una capa
transparente superpuesta al mismo marco de la app para que los controles WPF
funcionen encima de libmpv; esta capa no aparece en la barra de tareas ni se
muestra como ventana independiente.

## Compilación fácil

1. Descomprime el ZIP en tu PC con Windows 10/11 de 64 bits.
2. Haz doble clic en `COMPILAR-EXE.cmd`.
3. Necesitas internet la primera vez. Si no tienes .NET SDK 10, el script lo
   instala en la subcarpeta `.tools` sin cambiar la instalación del sistema.
4. El script descarga `libmpv-2.dll` desde la versión 0.42.0 publicada por
   mpv-player, comprueba SHA-256 y compila la app en modo Release.
5. Si todo termina bien, encontrarás **`resultado\PTVPlus.exe`**.

El ZIP contiene código fuente y herramientas de compilación, **no un `.exe`
compilado**. No sobrescribas tu exe previo hasta probar el nuevo.

## Cambios de esta edición

- TV en vivo: guía y preview separados, controles de canal/volumen/ampliar en el
  borde superior derecho; Atrás visible. Botones dentro de la misma aplicación.
- Guía flexible para tamaños de pantalla distintos, sin solapar el preview.
- Nombre de canal, programa, logo y barra inferior limitados al ancho del video.
- En la lista, los nombres largos se recortan sin invadir otras columnas.
- Reproductor de películas y series: play/pausa, ±10 s, siguiente episodio,
  audio, subtítulos, proporción, sonido y pantalla completa distribuidos en dos
  grupos inferiores, **sin montarse unos sobre otros**.
- Inicio: nombre y programa de la vista previa acotados al área del video.
- Multipantalla: encabezado y botones en dos filas, con títulos recortados y
  selector ajustado al tamaño disponible.
- Se conserva el estilo morado, la API y panel existentes.

### Sin ventanas externas

Los botones de reproductor y las listas se dibujan encima de la app, no en una
ventana de reproductor aparte. «2/3/4 vistas» significa mosaicos de video
integrados dentro de la misma página de multipantalla.

## Si hay errores

La ventana de comandos mostrará el error. La descarga del motor de video y del
SDK requiere conexión a Internet. Registros de ejecución de la app:
`%LocalAppData%\PTVPlus\log.txt`.

**Pendiente:** no fue posible compilar ni ejecutar una prueba Windows en el
entorno donde se modificó el código. La reproducción final depende de probar
el ejecutable real en tu PC. Si algo falla al compilar, conserva el mensaje
literal y podemos corregirlo sin adivinar.
