# Lista rápida de pruebas PTV PLUS 1.0.2

- [ ] Inicio: vista previa de TV no tapa textos ni tarjetas.
- [ ] TV en vivo: categorías y canales a la izquierda y preview a la derecha.
- [ ] Nombres de canales muy largos no pisan logos, números ni buscador.
- [ ] TV: botones Atrás, canal anterior/siguiente, silenciar y ampliar visibles.
- [ ] TV: botón Atrás del video ampliado regresa a la guía; Esc vuelve a Inicio.
- [ ] No aparece ventana de reproductor externo al cambiar de canal.
- [ ] Películas y series: controles debajo, a los bordes; barra de progreso sin solaparse.
- [ ] Pantalla completa y ESC funcionan con mouse y teclado.
- [ ] Multipantalla 2/3/4: marcos dentro del área, canal y audio por mosaico.
- [ ] Reducir tamaño de ventana y aumentar escala Windows a 125/150%; nada se monta.
- [ ] Cambiar 10 canales seguidos y revisar reconexión en caso de error.
