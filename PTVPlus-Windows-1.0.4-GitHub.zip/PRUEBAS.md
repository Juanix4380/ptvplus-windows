# Pruebas recomendadas — Windows 1.0.4

- [ ] En GitHub Actions se ejecuta el workflow **PTV Plus Windows 1.0.4 - Compilar**.
- [ ] El artefacto se llama **PTVPlus-Windows-1.0.4-EXE**.
- [ ] Inicio muestra **PTV PLUS · 1.0.4**.
- [ ] Se puede iniciar sesión con una cuenta válida, sin mostrar URL al cliente.
- [ ] Al abrir TV, la pantalla y guía permanecen dentro de la app; no abre VLC.
- [ ] Si `/session/status` falla pero `/login` confirma cuenta activa, puede reproducir.
- [ ] Si ambos fallan, no se reproduce y aparece diagnóstico con Reintentar (sin diálogo modal).
- [ ] Si cuenta vencida/suspendida o servidor borrado, la app bloquea correctamente.
- [ ] El cambio de DNS del panel renueva la URL antes de reproducir.
- [ ] En TV pantalla completa, Atrás regresa a guía; los controles permanecen cerca de orillas.
- [ ] En películas/series, controles en la zona inferior; Reintentar aparece al fallar.
- [ ] En multipantalla, las vistas quedan dentro del mismo programa.
