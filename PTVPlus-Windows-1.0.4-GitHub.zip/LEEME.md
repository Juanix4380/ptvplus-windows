# PTV Plus Windows 1.0.4 — código fuente para GitHub Actions

Este archivo es el proyecto para generar `PTVPlus.exe` en Windows usando GitHub Actions. **No es un EXE compilado, y aún no se ha probado contra el panel.**

## Subir y compilar

1. Descomprime **PTVPlus-Windows-1.0.4-GitHub.zip** en tu PC.
2. En GitHub sube a la raíz de tu repositorio **el contenido** del ZIP. No metas `src` dentro de otra carpeta accidentalmente. Incluye la carpeta oculta `.github` y reemplaza el workflow anterior `.github/workflows/build.yml`.
3. En **Actions**, elige **PTV Plus Windows 1.0.4 - Compilar** y pulsa **Run workflow**.
4. Si compila, descarga el artefacto **PTVPlus-Windows-1.0.4-EXE**. Adentro estará `PTVPlus.exe`.
5. En Inicio debe leerse **PTV PLUS · 1.0.4**. Si aparece otra versión, estás ejecutando el .exe anterior.

Si el repositorio aún contiene código de versiones pasadas, el workflow buscará **únicamente 1.0.4**; no compilará 1.0.3 como si fuera el nuevo.

## Cambios en 1.0.4

- Se prueba `/cloud/session/status` para autorizar, y si falla el endpoint o la comunicación, se intenta revalidar contra `/cloud/login` usando las credenciales almacenadas y **el mismo panel**. Solo se permite reproducir tras confirmación de cuenta activa; rechazo explícito o cuenta vencida permanece bloqueado.
- Al comprobar sesión válida, se incorpora la dirección Xtream actualizada del panel y se vuelve a construir la URL de reproducción antes de cargarla, en caso de cambio de DNS.
- Los errores del panel se muestran dentro del reproductor, con descripción de si falló estado, login o tiempo de espera; no se abre diálogo grande por fallas temporales.
- Botón **Reintentar** para TV en vivo, películas y series si falla la reproducción.
- Se conserva la guía de canales, controles en los bordes y multipantalla dentro de PTV Plus. La app usa una **capa técnica transparente WPF** para dibujar los controles encima del video `libmpv`, pero no abre reproductores externos.
- Marca de versión 1.0.4 visible en Inicio para identificar el .exe realmente ejecutado.

## Limitación importante

Este cambio intenta resolver el caso en que `/session/status` falla pero `/login` sigue funcionando. **Si el sitio del panel no responde en ninguna de las dos rutas, no existe una autorización válida y el video continuará bloqueado**. No es correcto quitar la verificación. Debes comprobar el panel/servidor y los logs.

El código fue revisado estáticamente, pero no se ha compilado ni ejecutado en Windows en este entorno. La vista previa y el diseño deben probarse en pantalla real.

## Si sigue sin reproducir

Comprueba que Inicio diga **PTV PLUS · 1.0.4**. Revisa `%LOCALAPPDATA%\PTVPlus\log.txt` (puede variar según la ruta configurada en `Core/Base.cs`) y comparte solo las líneas de error **Cloud status** y **Cloud relogin**, quitando cualquier dato privado antes de compartirlo. Si `login` también falla, hay que revisar el panel real y no seguir cambiando el reproductor a ciegas.
