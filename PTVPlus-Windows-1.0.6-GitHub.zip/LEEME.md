# PTV Plus para Windows 1.0.6 · Proyecto completo para GitHub

**Este ZIP contiene código fuente, no el EXE ya compilado.** No fue posible ejecutar Windows/.NET ni probar el video real desde este entorno.

## Cambios de esta entrega

- **Primer arranque:** la capa interna de controles se sincroniza con las coordenadas, escala DPI y tamaño del área de video **antes de mostrarse**. Se recalcula tras el primer renderizado, al cambiar de sección y al redimensionar Windows. Esto busca corregir el título de TV debajo de las tarjetas y los controles corridos que desaparecen tras navegar.
- **Serie en reproducción:** nuevo botón **Episodios** en el borde inferior. Abre un panel lateral **dentro del reproductor** con temporadas y capítulos. Permite elegir un capítulo y continuar en el mismo reproductor; `Esc` cierra el panel. Atajo: tecla **E**.
- **Películas y series:** controles compactos pegados al borde inferior, con distribución adaptable a la anchura, evitando grandes botones flotantes a mitad del video.
- **Sin ventanas de reproducción externas:** la navegación, episodios y vistas del reproductor permanecen dentro de PTV Plus. WPF sigue usando una ventana transparente técnica oculta en la barra de tareas para dibujar controles sobre el motor nativo mpv; **no** se abre otro reproductor.
- **Autorización:** no se elimina la comprobación del panel ni se prometen soluciones a fallos independientes de red o cuenta.

## Para compilar en GitHub

1. Descomprime **PTVPlus-Windows-1.0.6-GitHub.zip**.
2. Sube el **contenido extraído**, no la carpeta contenedora, a un repositorio GitHub. Debe existir `src/PTVPlus/PTVPlus.csproj` y `.github/workflows/build.yml` en sus rutas correctas.
3. Reemplaza las versiones previas de los archivos si existen. Si quieres evitar que se compile otro proyecto de forma accidental, usa un repositorio limpio.
4. Abre **Actions → PTV Plus Windows 1.0.6 - Compilar → Run workflow**.
5. Si la ejecución acaba en verde, descarga **PTVPlus-Windows-1.0.6-EXE** y extrae `PTVPlus.exe`.

> Si GitHub muestra un error, abre el **primer paso rojo**, no solo la anotación `exit code 1`. Descarga `PTVPlus-REGISTRO-DEL-ERROR` si aparece.

## Pruebas recomendadas

1. Cierra la app por completo, vuelve a abrirla **sin navegar**: la vista previa debe tener el nombre del canal dentro del recuadro, y los controles no deben quedar desfasados.
2. Redimensiona / maximiza / restaura la ventana, prueba Windows con escala de 125 o 150 %, revisa los bordes y posición de controles.
3. Abre una serie, reproduce un capítulo: **Episodios** → elegir temporada → elegir capítulo → continuar en la misma pantalla. Pulsa `Esc` para cerrar el panel sin salir de la reproducción.
4. Confirma que películas no muestren el botón **Episodios**.
5. Comprueba multipantalla 2/3/4 y TV en vivo, incluyendo audio y controles tras navegar.
6. Comprueba que Inicio muestre **PTV PLUS · 1.0.6**.

No afirmamos que la compilación ni el comportamiento real estén verificados todavía: requieren prueba de Windows.
