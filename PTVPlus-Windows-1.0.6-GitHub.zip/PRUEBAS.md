# Pruebas PTV PLUS 1.0.6

- [ ] Al iniciar por primera vez (antes de navegar), la capa de controles coincide con el video.
- [ ] Título de TV en vivo dentro de la tarjeta, no debajo de Películas / Series.
- [ ] Maximizar, restaurar y redimensionar no desplaza capas; DPI 100/125/150 %.
- [ ] Películas: controles compactos en la zona inferior, sin superposición.
- [ ] Series: botón Episodios en el reproductor, panel lateral dentro de la app.
- [ ] Temporadas y episodios navegables con mouse / teclado. Esc cierra solamente el selector.
- [ ] Al elegir episodio se actualiza título y continúa reproducción sin abrir otra ventana.
- [ ] Los botones de Audio, Subtítulos, Pantalla, Siguiente y Atrás siguen funcionando.
- [ ] TV en vivo y multipantalla 2/3/4 con controles y marcos correctamente alineados.
- [ ] Cuenta caducada sigue bloqueada; cuenta válida y panel en línea permiten reproducir.
