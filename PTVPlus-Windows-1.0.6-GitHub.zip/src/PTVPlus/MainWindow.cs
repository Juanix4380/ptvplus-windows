using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using PTVPlus.Core;
using PTVPlus.Player;
using PTVPlus.UI;
using PTVPlus.UI.Pages;
using Page = PTVPlus.UI.Page;

namespace PTVPlus
{
    /// <summary>
    /// La única ventana de la app: todas las pantallas se cambian adentro (sin abrir más ventanas).
    /// El video va en una superficie que se coloca donde cada pantalla lo pide.
    /// </summary>
    public sealed class MainWindow : Window
    {
        public static MainWindow Instance { get; private set; }

        private readonly Grid _root = new Grid();
        private readonly Grid _pageHost = new Grid();
        private readonly VideoHost _video = new VideoHost
        {
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Top,
            Width = 16,
            Height = 16,
            Visibility = Visibility.Collapsed
        };
        private readonly List<Page> _stack = new List<Page>();
        public OverlayWindow Overlay { get; private set; }
        public Page Current => _stack.Count == 0 ? null : _stack[_stack.Count - 1];
        public bool IsFullscreen { get; private set; }
        private WindowState _prevState = WindowState.Maximized;
        private Rect _lastVideo = Rect.Empty;
        private bool _lastVisible;
        private bool _started;

        public MainWindow()
        {
            Instance = this;
            Title = "PTV PLUS 1.0.6";
            Width = 1360;
            Height = 820;
            MinWidth = 960;
            MinHeight = 600;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = Ui.B("Bg");
            Foreground = Ui.B("Text");
            FontFamily = Ui.Font;
            UseLayoutRounding = true;
            SnapsToDevicePixels = true;
            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Ideal);
            try { Icon = BitmapFrame.Create(new Uri("pack://application:,,,/Assets/app.ico", UriKind.Absolute)); } catch { }
            WindowState = WindowState.Maximized;

            _root.ClipToBounds = true;
            _pageHost.ClipToBounds = true;
            _root.Children.Add(_pageHost);
            _root.Children.Add(_video);
            Content = _root;

            _video.Created += OnVideoCreated;
            SourceInitialized += (s, e) =>
            {
                Native.DarkTitle(new WindowInteropHelper(this).Handle);
                Overlay = new OverlayWindow { Owner = this, KeyHandler = HandleKey };
            };
            Loaded += (s, e) => Start();
            // On initial launch WPF may not have final maximized sizes until
            // ContentRendered. Re-sync also after initial layout/first paint.
            ContentRendered += (s, e) =>
            {
                SyncOverlay();
                PlaceVideo();
                Dispatcher.BeginInvoke(new Action(() => { SyncOverlay(); PlaceVideo(); }),
                    System.Windows.Threading.DispatcherPriority.ApplicationIdle);
            };
            Activated += (s, e) => SyncOverlay();
            LocationChanged += (s, e) => SyncOverlay();
            SizeChanged += (s, e) => SyncOverlay();
            StateChanged += (s, e) =>
            {
                if (Overlay == null) return;
                if (WindowState == WindowState.Minimized) Overlay.Hide();
                else { SyncOverlay(); Overlay.Refresh(); }
            };
            _root.LayoutUpdated += (s, e) =>
            {
                // The initial overlay is not shown until these bounds stabilize.
                // Also covers resizing, DPI changes and Windows taskbar movement.
                SyncOverlay();
                PlaceVideo();
            };
            PreviewKeyDown += (s, e) => HandleKey(e);
            PreviewMouseDown += (s, e) =>
            {
                if (e.ChangedButton == MouseButton.XButton1) { Back(); e.Handled = true; }
            };
            Closing += (s, e) => Shutdown();
            // La reproducción pinta el motivo en su propia pantalla.
            // No abrir cuadros grandes de error que cubran toda la aplicación.
            Playback.Denied += d =>
            {
                // Los fallos temporales se muestran en el reproductor con Reintentar.
                // No abrir ventanas/diálogos superpuestos ni duplicar el texto.
                if (d.Reason != "cloud_unavailable") Toast(d.Message);
            };
        }

        private void Start()
        {
            if (_started) return;
            _started = true;
            SyncOverlay();
            if (Prefs.S.StartFullscreen) ToggleFullscreen();
            if (!Prefs.S.Logged) Replace(new LoginPage());
            else if (!Prefs.S.ProfileChosen) Replace(new ProfilesPage());
            else
            {
                Library.Bind(Prefs.S.AccountId, Prefs.S.ProfileId);
                Catalog.Ensure();
                var t = HistorySync.PullAsync();
                Replace(new HomePage());
            }
        }

        private void OnVideoCreated(IntPtr hwnd)
        {
            if (Playback.Main != null) return;
            try
            {
                if (!MpvPlayer.Available)
                {
                    Dialogs.Message("Falta el motor de video", "No se encontró libmpv-2.dll. Descarga otra vez PTVPlus.exe desde GitHub (Releases).");
                    return;
                }
                Playback.Attach(MpvPlayer.Create(hwnd));
            }
            catch (Exception e)
            {
                Log.Error(e, "mpv");
                Dialogs.Message("No se pudo iniciar el video", "Actualiza el controlador de tu tarjeta de video y vuelve a abrir la app.");
            }
        }

        public void BringToFront()
        {
            if (WindowState == WindowState.Minimized) WindowState = _prevState == WindowState.Minimized ? WindowState.Maximized : _prevState;
            Activate();
            Topmost = true;
            Topmost = false;
            Focus();
        }

        // ------------------------------------------------------------- navegación

        public void Go(Page p)
        {
            var old = Current;
            old?.OnHide();
            _stack.Add(p);
            Show(p, old);
        }

        public void Replace(Page p)
        {
            var old = Current;
            old?.OnHide();
            if (_stack.Count > 0) _stack.RemoveAt(_stack.Count - 1);
            _stack.Add(p);
            Show(p, old);
        }

        /// <summary>Limpia todo y deja solo esta pantalla (al iniciar sesión o elegir perfil).</summary>
        public void Reset(Page p)
        {
            var old = Current;
            old?.OnHide();
            _stack.Clear();
            _stack.Add(p);
            Show(p, old);
        }

        public void Back()
        {
            if (Overlay != null && Overlay.DialogOpen) { Overlay.CloseDialog(); return; }
            var cur = Current;
            if (cur != null && cur.OnBack()) return;
            if (_stack.Count <= 1)
            {
                if (IsFullscreen) ToggleFullscreen();
                return;
            }
            cur.OnHide();
            _stack.RemoveAt(_stack.Count - 1);
            Show(Current, cur);
        }

        public void GoHome()
        {
            while (_stack.Count > 1 && !(Current is HomePage))
            {
                var cur = Current;
                cur.OnHide();
                _stack.RemoveAt(_stack.Count - 1);
            }
            Show(Current, null);
        }

        private void Show(Page p, Page old)
        {
            // Important on first launch: DO NOT attach an overlay at (0,0)
            // before the maximized window, the live card and DPI are measured.
            // This was why the channel title appeared below the Home tiles
            // until the user entered another section.
            Overlay?.SetPage(null);
            _pageHost.Children.Clear();
            _pageHost.Children.Add(p);
            if (p.VideoSlot == null && !p.VideoFull && Playback.Current != null) Playback.Stop();
            _lastVideo = Rect.Empty;
            _lastVisible = false;
            p.Opacity = 0;
            p.OnShow();
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (Current != p) return;
                // Run WPF measure/arrange and card SizeChanged handlers first.
                _root.UpdateLayout();
                SyncOverlay();
                Overlay?.SetPage(p.OverlayContent);
                PlaceVideo();
                p.BeginAnimation(OpacityProperty,
                    new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180)));
                Activate();
                p.FocusFirst();
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    if (Current != p) return;
                    SyncOverlay();
                    PlaceVideo();
                }), System.Windows.Threading.DispatcherPriority.Render);
            }), System.Windows.Threading.DispatcherPriority.Loaded);
        }

        /// <summary>La pantalla cambió lo que va encima del video.</summary>
        public void RefreshOverlay()
        {
            var p = Current;
            SyncOverlay();
            Overlay?.SetPage(p?.OverlayContent);
            PlaceVideo();
        }

        // ------------------------------------------------------------------ video

        // La TV puede pasar de vista previa a pantalla grande sin crear páginas
        // ni ventanas nuevas: pide recalcular la posición del mismo HWND de mpv.
        public void RefreshVideoPlacement()
        {
            Dispatcher.BeginInvoke(new Action(PlaceVideo), System.Windows.Threading.DispatcherPriority.Render);
        }

        private void PlaceVideo()
        {
            var p = Current;
            if (p == null) return;
            bool visible = false;
            Rect r = Rect.Empty;
            double w = _root.ActualWidth, h = _root.ActualHeight;
            if (p.VideoFull)
            {
                r = new Rect(0, 0, w, h);
                visible = true;
            }
            else
            {
                var slot = p.VideoSlot;
                if (slot != null && slot.IsVisible && slot.ActualWidth > 1 && slot.ActualHeight > 1 && slot.IsDescendantOf(_root))
                {
                    r = slot.TransformToAncestor(_root).TransformBounds(new Rect(0, 0, slot.ActualWidth, slot.ActualHeight));
                    visible = r.Top >= p.VideoTopLimit - 0.5 && r.Bottom <= h + 0.5 && r.Left >= -0.5 && r.Right <= w + 0.5;
                }
            }
            if (visible)
            {
                var m = new Thickness(Math.Round(r.Left), Math.Round(r.Top), 0, 0);
                if (_video.Margin != m) _video.Margin = m;
                if (Math.Abs(_video.Width - Math.Round(r.Width)) > 0.5) _video.Width = Math.Round(r.Width);
                if (Math.Abs(_video.Height - Math.Round(r.Height)) > 0.5) _video.Height = Math.Round(r.Height);
                if (_video.Visibility != Visibility.Visible) _video.Visibility = Visibility.Visible;
            }
            else if (_video.Visibility != Visibility.Collapsed)
            {
                // Se pone en 16x16 (no se destruye: mpv sigue con la misma superficie).
                _video.Visibility = Visibility.Collapsed;
            }
            if (r != _lastVideo || visible != _lastVisible)
            {
                _lastVideo = r;
                _lastVisible = visible;
                p.OnVideoPlaced(r, visible);
            }
        }

        private void SyncOverlay()
        {
            if (Overlay == null || !IsLoaded || !_root.IsLoaded ||
                _root.ActualWidth < 200 || _root.ActualHeight < 150) return;
            try
            {
                var src = PresentationSource.FromVisual(_root);
                if (src == null) return;
                Point topLeft = _root.PointToScreen(new Point(0, 0));
                var m = src.CompositionTarget.TransformFromDevice;
                Point dip = m.Transform(topLeft);
                Overlay.Sync(new Rect(dip.X, dip.Y, _root.ActualWidth, _root.ActualHeight));
            }
            catch (Exception e)
            {
                Log.Error(e, "SyncOverlay");
            }
        }

        public void ToggleFullscreen()
        {
            if (!IsFullscreen)
            {
                _prevState = WindowState;
                IsFullscreen = true;
                WindowStyle = WindowStyle.None;
                ResizeMode = ResizeMode.NoResize;
                if (WindowState == WindowState.Maximized) WindowState = WindowState.Normal;
                WindowState = WindowState.Maximized;
            }
            else
            {
                IsFullscreen = false;
                WindowStyle = WindowStyle.SingleBorderWindow;
                ResizeMode = ResizeMode.CanResize;
                WindowState = _prevState == WindowState.Minimized ? WindowState.Maximized : _prevState;
                Native.DarkTitle(new WindowInteropHelper(this).Handle);
            }
            Dispatcher.BeginInvoke(new Action(SyncOverlay), System.Windows.Threading.DispatcherPriority.Loaded);
        }

        // ---------------------------------------------------------------- teclado

        private void HandleKey(KeyEventArgs e)
        {
            if (e.Handled) return;
            if (Overlay != null && Overlay.DialogOpen)
            {
                if (e.Key == Key.Escape || e.Key == Key.BrowserBack)
                {
                    Overlay.CloseDialog();
                    e.Handled = true;
                }
                return;
            }
            if (e.Key == Key.F11)
            {
                ToggleFullscreen();
                e.Handled = true;
                return;
            }
            var p = Current;
            if (p != null && p.OnKey(e))
            {
                e.Handled = true;
                return;
            }
            bool typing = e.OriginalSource is TextBox || e.OriginalSource is PasswordBox;
            if (e.Key == Key.Escape || e.Key == Key.BrowserBack || (e.Key == Key.Back && !typing))
            {
                Back();
                e.Handled = true;
            }
        }

        public void Toast(string text) => Overlay?.Toast(text);

        private void Shutdown()
        {
            try
            {
                Playback.SaveProgress(true);
                Library.SaveNow();
                var t = HistorySync.FlushAsync();
                t.Wait(2500);
            }
            catch { }
            try { Playback.Main?.Dispose(); } catch { }
            try { Overlay?.Close(); } catch { }
            Prefs.SaveNow();
        }
    }
}
