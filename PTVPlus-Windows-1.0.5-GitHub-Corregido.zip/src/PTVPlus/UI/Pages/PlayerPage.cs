using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using PTVPlus.Core;
using PTVPlus.Player;

namespace PTVPlus.UI.Pages
{
    /// <summary>
    /// Reproductor de películas y episodios a pantalla completa: controles premium que se ocultan
    /// solos, adelantar/regresar, audio, subtítulos, siguiente episodio y avance guardado.
    /// </summary>
    public sealed class PlayerPage : Page
    {
        private readonly Media _media;
        private readonly double _start;
        private readonly List<Media> _queue;
        private readonly int _index;
        private readonly Grid _ov = new Grid();
        private readonly Grid _hit = new Grid { Background = new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)), Focusable = true, FocusVisualStyle = null };
        private readonly Grid _controls = new Grid();
        private readonly TextBlock _title = Ui.T("", 24, Brushes.White, FontWeights.Bold);
        private readonly TextBlock _subtitle = Ui.T("", 15, Ui.Hex("#FFCFC6E2"));
        private readonly Slider _seek = new Slider { Minimum = 0, Maximum = 1, IsMoveToPointEnabled = true, Focusable = false };
        private readonly TextBlock _pos = Ui.T("0:00", 14, Brushes.White, FontWeights.SemiBold);
        private readonly TextBlock _dur = Ui.T("0:00", 14, Ui.Hex("#FFCFC6E2"));
        private readonly TextBlock _status = Ui.T("", 20, Brushes.White, FontWeights.SemiBold);
        private readonly TextBlock _stats = Ui.T("", 13, Brushes.White);
        private readonly Border _center = new Border { Width = 46, Height = 46, CornerRadius = new CornerRadius(23), HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(0, 0, 24, 120), IsHitTestVisible = false, Opacity = 0 };
        private readonly TextBlock _centerIcon = Ui.Icon(G.Pause, 20);
        private Button _playBtn, _nextBtn, _muteBtn, _fullBtn, _retryBtn;
        private DispatcherTimer _hide, _tick;
        private bool _dragging;
        private bool _updating;
        private bool _ended;

        public override bool VideoFull => true;
        public override UIElement OverlayContent => _ov;

        public PlayerPage(Media media, double start, List<Media> queue = null, int index = 0)
        {
            _media = media;
            _start = start;
            _queue = queue;
            _index = index;
            Background = Brushes.Black;
            Build();
        }

        private void Build()
        {
            _hit.MouseMove += (s, e) => ShowControls();
            _hit.MouseLeftButtonDown += (s, e) =>
            {
                if (e.ClickCount == 2) { Main.ToggleFullscreen(); e.Handled = true; }
            };
            _hit.MouseLeftButtonUp += (s, e) =>
            {
                if (_controls.Visibility == Visibility.Visible) TogglePause();
                else ShowControls();
            };
            _ov.ClipToBounds = true;
            _ov.Children.Add(_hit);

            _status.HorizontalAlignment = HorizontalAlignment.Center;
            _status.VerticalAlignment = VerticalAlignment.Center;
            _status.TextWrapping = TextWrapping.Wrap;
            _status.TextAlignment = TextAlignment.Center;
            _status.MaxWidth = 760;
            _status.Effect = Ui.Shadow(12, 0.9);
            _status.IsHitTestVisible = false;
            _ov.Children.Add(_status);

            _center.Background = Ui.Hex("#B30B0812");
            _center.Child = _centerIcon;
            _ov.Children.Add(_center);

            // ---------- Controles
            _controls.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            _controls.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            _controls.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var topBar = new Border { Background = Ui.Gradient("#D9000000", "#00000000", 90), Padding = new Thickness(22, 12, 22, 16) };
            var topRow = new StackPanel { Orientation = Orientation.Horizontal };
            topRow.Children.Add(Ui.Round(G.Back, () => Main.Back(), "Atrás"));
            var titles = new StackPanel { Margin = new Thickness(18, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
            _title.TextTrimming = TextTrimming.CharacterEllipsis;
            _subtitle.TextTrimming = TextTrimming.CharacterEllipsis;
            titles.Children.Add(_title);
            titles.Children.Add(_subtitle);
            SizeChanged += (s, e) =>
            {
                double available = Math.Max(220, ActualWidth - 140);
                _title.MaxWidth = available;
                _subtitle.MaxWidth = available;
            };
            topRow.Children.Add(titles);
            topBar.Child = topRow;
            _controls.Children.Add(topBar);

            var bottomBar = new Border { Background = Ui.Gradient("#00000000", "#E6000000", 90), Padding = new Thickness(22, 12, 22, 10) };
            Grid.SetRow(bottomBar, 2);
            var bottom = new StackPanel();
            var seekRow = new Grid();
            seekRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            seekRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            seekRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            _pos.VerticalAlignment = VerticalAlignment.Center;
            _pos.MinWidth = 64;
            seekRow.Children.Add(_pos);
            _seek.Style = Ui.S("Seek");
            _seek.Margin = new Thickness(12, 0, 12, 0);
            _seek.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(_seek, 1);
            seekRow.Children.Add(_seek);
            _dur.VerticalAlignment = VerticalAlignment.Center;
            _dur.MinWidth = 64;
            _dur.TextAlignment = TextAlignment.Right;
            Grid.SetColumn(_dur, 2);
            seekRow.Children.Add(_dur);
            bottom.Children.Add(seekRow);

            // Dos grupos realmente separados. Los botones nunca se superponen
            // ni quedan flotando en el centro al cambiar resolución o escala DPI.
            // Dos líneas bien alineadas a los bordes: los grupos no compiten
            // por el mismo espacio en equipos pequeños o con escala DPI 150%.
            var buttons = new StackPanel { Margin = new Thickness(0, 12, 0, 0) };
            var leftBtns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Left };
            _playBtn = Ui.Round(G.Pause, TogglePause, "Pausa / Reproducir");
            _playBtn.Width = 48;
            _playBtn.Height = 48;
            _playBtn.FontSize = 20;
            leftBtns.Children.Add(_playBtn);
            leftBtns.Children.Add(Spaced(Ui.Pill("−10 s", () => Seek(-10))));
            leftBtns.Children.Add(Spaced(Ui.Pill("+10 s", () => Seek(10))));
            _nextBtn = Ui.Pill("Siguiente episodio", () => Playback.Next(), G.Next);
            leftBtns.Children.Add(Spaced(_nextBtn));
            buttons.Children.Add(leftBtns);
            var rightBtns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 6, 0, 0) };
            rightBtns.Children.Add(Spaced(Ui.Pill("Audio", PickAudio, G.Audio)));
            rightBtns.Children.Add(Spaced(Ui.Pill("Subtítulos", PickSubs, G.Subs)));
            rightBtns.Children.Add(Spaced(Ui.Pill("Pantalla", PickAspect, G.All)));
            _muteBtn = Ui.Round(G.Volume, ToggleMute, "Sonido (M)");
            rightBtns.Children.Add(Spaced(_muteBtn));
            _fullBtn = Ui.Round(G.Full, () => { Main.ToggleFullscreen(); PaintButtons(); }, "Pantalla completa (F)");
            rightBtns.Children.Add(Spaced(_fullBtn));
            buttons.Children.Add(rightBtns);
            bottom.Children.Add(buttons);
            bottomBar.Child = bottom;
            _controls.Children.Add(bottomBar);
            _controls.Visibility = Visibility.Collapsed;
            _ov.Children.Add(_controls);

            var statsBox = new Border
            {
                Background = Ui.Hex("#C0100A1A"), CornerRadius = new CornerRadius(12), Padding = new Thickness(14, 10, 14, 10),
                HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 110, 30, 0),
                Child = _stats, IsHitTestVisible = false
            };
            _stats.FontFamily = new FontFamily("Consolas");
            _stats.TextTrimming = TextTrimming.None;
            statsBox.SetBinding(VisibilityProperty, new System.Windows.Data.Binding("Text") { Source = _stats, Converter = new EmptyToCollapsed() });
            _ov.Children.Add(statsBox);

            _seek.AddHandler(Thumb.DragStartedEvent, new DragStartedEventHandler((s, e) => _dragging = true));
            _seek.AddHandler(Thumb.DragCompletedEvent, new DragCompletedEventHandler((s, e) =>
            {
                _dragging = false;
                Playback.SeekTo(_seek.Value);
                ShowControls();
            }));
            _seek.ValueChanged += (s, e) =>
            {
                if (_updating || _dragging) return;
                // Clic en la barra: salta ahí.
                Playback.SeekTo(_seek.Value);
                ShowControls();
            };
        }

        private static FrameworkElement Spaced(FrameworkElement e)
        {
            e.Margin = new Thickness(7, 0, 0, 0);
            return e;
        }

        private static Button CompactIcon(string glyph, Action click, string tooltip)
        {
            var b = Ui.Round(glyph, click, tooltip);
            b.Width = b.Height = 44;
            b.FontSize = 18;
            return b;
        }

        private static Button Compact(string label, Action click, string tooltip)
        {
            var b = Ui.Pill(label, click);
            b.Width = 55;
            b.Height = 44;
            b.FontSize = 14;
            b.Padding = new Thickness(5, 3, 5, 3);
            b.ToolTip = tooltip;
            return b;
        }

        // ------------------------------------------------------- ciclo de vida

        public override void OnShow()
        {
            Playback.Changed += Paint;
            Playback.Ended += OnEnded;
            _tick = UiThread.Every(500, Tick);
            var cur = Playback.Current;
            if (cur == null || cur.Url != _media.Url) Playback.Play(_media, _start, _queue, _index);
            else Playback.Main?.SetMute(false);
            ShowControls();
            Paint();
        }

        public override void OnHide()
        {
            Playback.Changed -= Paint;
            Playback.Ended -= OnEnded;
            _tick?.Stop();
            _hide?.Stop();
            Playback.SaveProgress(true);
            Main.Activate();
        }

        public override void FocusFirst()
        {
            Main.Overlay?.Activate();
            if (_controls.Visibility == Visibility.Visible) _playBtn.Focus();
            else _hit.Focus();
        }

        public override bool OnBack()
        {
            if (Main.IsFullscreen) { Main.ToggleFullscreen(); return true; }
            return false;
        }

        private void OnEnded()
        {
            if (Playback.HasNext && Prefs.S.AutoNext) return;
            _ended = true;
            UiThread.After(1500, () => { if (_ended && Main.Current == this) Main.Back(); });
        }

        // ------------------------------------------------------------ pintar

        private void Paint()
        {
            var m = Playback.Current ?? _media;
            _title.Text = m.Title;
            _subtitle.Text = m.Subtitle;
            _nextBtn.Visibility = Playback.HasNext ? Visibility.Visible : Visibility.Collapsed;
            PaintButtons();
            var p = Playback.Main;
            if (Playback.LastError != null) _status.Text = Playback.LastError;
            else if (Playback.Notice != null) _status.Text = Playback.Notice;
            else if (p != null && Playback.Current != null && (p.Buffering || (p.CoreIdle && p.Position <= 0 && !p.Paused))) _status.Text = "Cargando…";
            else _status.Text = "";
            _retryBtn.Visibility = Playback.LastError != null ? Visibility.Visible : Visibility.Collapsed;
        }

        private void PaintButtons()
        {
            var p = Playback.Main;
            _playBtn.Content = p != null && p.Paused ? G.Play : G.Pause;
            _muteBtn.Content = p != null && p.Muted ? G.Mute : G.Volume;
            _fullBtn.Content = Main.IsFullscreen ? G.ExitFull : G.Full;
        }

        private void Tick()
        {
            var p = Playback.Main;
            if (p == null) return;
            double dur = p.Duration, pos = p.Position;
            _updating = true;
            if (dur > 0 && !_dragging)
            {
                if (Math.Abs(_seek.Maximum - dur) > 0.5) _seek.Maximum = dur;
                _seek.Value = Math.Max(0, Math.Min(dur, pos));
            }
            _updating = false;
            _pos.Text = TextUtil.Time(_dragging ? _seek.Value : pos);
            _dur.Text = dur > 0 ? TextUtil.Time(dur) : "--:--";
            _stats.Text = Prefs.S.PlayerStats && Playback.Current != null ? p.Stats() : "";
            Paint();
        }

        // --------------------------------------------------------- controles

        private void ShowControls()
        {
            if (_controls.Visibility != Visibility.Visible)
            {
                _controls.Visibility = Visibility.Visible;
                _controls.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(160)));
                Mouse.OverrideCursor = null;
            }
            _hide?.Stop();
            _hide = UiThread.After(3500, () =>
            {
                var p = Playback.Main;
                if (p != null && p.Paused) return;
                if (_controls.IsMouseOver && Mouse.LeftButton == MouseButtonState.Pressed) { ShowControls(); return; }
                HideControls();
            });
        }

        private void HideControls()
        {
            _controls.Visibility = Visibility.Collapsed;
            _hit.Focus();
        }

        private void Flash(string glyph)
        {
            _centerIcon.Text = glyph;
            var a = new DoubleAnimationUsingKeyFrames();
            a.KeyFrames.Add(new LinearDoubleKeyFrame(1, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(80))));
            a.KeyFrames.Add(new LinearDoubleKeyFrame(1, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(500))));
            a.KeyFrames.Add(new LinearDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(800))));
            _center.BeginAnimation(OpacityProperty, a);
        }

        private void TogglePause()
        {
            var p = Playback.Main;
            bool wasPaused = p != null && p.Paused;
            Playback.TogglePause();
            Flash(wasPaused ? G.Play : G.Pause);
            ShowControls();
        }

        private void Seek(double secs)
        {
            Playback.Seek(secs);
            ShowControls();
        }

        private void ToggleMute()
        {
            var p = Playback.Main;
            if (p == null) return;
            p.SetMute(!p.Muted);
            PaintButtons();
            ShowControls();
        }

        private void Volume(int delta)
        {
            var p = Playback.Main;
            if (p == null) return;
            int v = Math.Max(0, Math.Min(150, (int)Math.Round(p.GetDouble("volume")) + delta));
            p.SetVolume(v);
            p.SetMute(false);
            Prefs.S.Volume = Math.Min(100, v);
            Prefs.Save();
            Main.Toast("Volumen " + v + " %");
        }

        private void PickAudio()
        {
            var p = Playback.Main;
            if (p == null) return;
            var tracks = p.Tracks("audio");
            if (tracks.Count == 0) { Main.Toast("Este video no tiene otras pistas de audio"); return; }
            Dialogs.Choice("Audio", tracks.Select(t => t.Label).ToList(), Math.Max(0, tracks.FindIndex(t => t.Selected)), i => p.Set("aid", tracks[i].Id));
        }

        private void PickSubs()
        {
            var p = Playback.Main;
            if (p == null) return;
            var tracks = p.Tracks("sub");
            var labels = new List<string> { "Desactivados" };
            labels.AddRange(tracks.Select(t => t.Label));
            int sel = tracks.FindIndex(t => t.Selected) + 1;
            Dialogs.Choice("Subtítulos", labels, Math.Max(0, sel), i => p.Set("sid", i == 0 ? "no" : tracks[i - 1].Id));
        }

        private void PickAspect()
        {
            var p = Playback.Main;
            if (p == null) return;
            var opts = new[] { "Ajustar (original)", "Llenar la pantalla", "16:9", "4:3" };
            Dialogs.Choice("Pantalla", opts, 0, i =>
            {
                switch (i)
                {
                    case 0: p.SetPanscan(0); p.SetAspect("no"); break;
                    case 1: p.SetAspect("no"); p.SetPanscan(1); break;
                    case 2: p.SetPanscan(0); p.SetAspect("16:9"); break;
                    case 3: p.SetPanscan(0); p.SetAspect("4:3"); break;
                }
            });
        }

        // ------------------------------------------------------------ teclado

        public override bool OnKey(KeyEventArgs e)
        {
            bool visible = _controls.Visibility == Visibility.Visible;
            switch (e.Key)
            {
                case Key.Space:
                case Key.MediaPlayPause:
                case Key.Play:
                case Key.Pause:
                    TogglePause();
                    return true;
                case Key.Enter:
                    if (!visible) { TogglePause(); return true; }
                    ShowControls();
                    return false;
                case Key.Left:
                    if (!visible || _hit.IsKeyboardFocused) { Seek(-10); return true; }
                    ShowControls();
                    return false;
                case Key.Right:
                    if (!visible || _hit.IsKeyboardFocused) { Seek(10); return true; }
                    ShowControls();
                    return false;
                case Key.J:
                    Seek(-10);
                    return true;
                case Key.L:
                    Seek(30);
                    return true;
                case Key.Up:
                    if (!visible) { Volume(5); return true; }
                    ShowControls();
                    return false;
                case Key.Down:
                    if (!visible) { ShowControls(); _playBtn.Focus(); return true; }
                    ShowControls();
                    return false;
                case Key.M:
                    ToggleMute();
                    return true;
                case Key.F:
                    Main.ToggleFullscreen();
                    PaintButtons();
                    return true;
                case Key.N:
                case Key.MediaNextTrack:
                    if (Playback.HasNext) Playback.Next();
                    return true;
                case Key.Escape:
                case Key.BrowserBack:
                    if (visible && !Main.IsFullscreen) { HideControls(); return true; }
                    return false;
                case Key.Tab:
                    ShowControls();
                    return false;
            }
            return false;
        }
    }
}
