using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Threading;
using PTVPlus.Core;

namespace PTVPlus.Player
{
    /// <summary>Lo que se está viendo (canal, película o episodio) y su enlace.</summary>
    public sealed class Media
    {
        public int Kind;
        public string Id = "";
        public string Url = "";
        public string Title = "";
        public string Subtitle = "";
        public string Image = "";
        public bool Wide;
        public int SeriesId;
        public int Season;
        public int EpisodeNum;
        public string Ext = "";
        public Item Channel;

        public bool IsLive => Kind == Core.Kind.Live;

        public string HistoryKey => Kind == Core.Kind.Movie ? "m:" + Id : Kind == Core.Kind.Episode ? "s:" + SeriesId : "";

        public static Media ForChannel(Item it)
        {
            var a = Prefs.Account();
            return new Media
            {
                Kind = Core.Kind.Live, Id = it.Id.ToString(), Url = Xtream.LiveUrl(a, it.Id, Prefs.S.LiveFormat == "m3u8" ? "m3u8" : "ts"),
                Title = it.Name, Image = it.Icon, Channel = it
            };
        }

        public static Media ForMovie(Item it)
        {
            var a = Prefs.Account();
            return new Media
            {
                Kind = Core.Kind.Movie, Id = it.Id.ToString(), Url = Xtream.MovieUrl(a, it.Id, it.Ext), Title = it.Title,
                Subtitle = it.YearOrName, Image = string.IsNullOrEmpty(it.Backdrop) ? it.Icon : it.Backdrop,
                Wide = !string.IsNullOrEmpty(it.Backdrop), Ext = it.Ext
            };
        }

        public static Media ForEpisode(Item series, Episode e, string seriesTitle, string image)
        {
            var a = Prefs.Account();
            string sub = (e.Season > 0 ? "T" + e.Season + " · " : "") + "E" + e.Num + (string.IsNullOrWhiteSpace(e.Title) ? "" : " · " + e.Title);
            return new Media
            {
                Kind = Core.Kind.Episode, Id = e.Id, Url = Xtream.EpisodeUrl(a, e.Id, e.Ext), Title = seriesTitle, Subtitle = sub,
                Image = !string.IsNullOrEmpty(e.Image) ? e.Image : image, Wide = !string.IsNullOrEmpty(e.Image),
                SeriesId = series?.Id ?? 0, Season = e.Season, EpisodeNum = e.Num, Ext = e.Ext
            };
        }
    }

    /// <summary>
    /// Reproducción principal (vista previa, TV en vivo, películas y series) con un solo mpv:
    /// autorización Cloud antes de cada video y cada 25 s, reconexión sola, otro formato si el
    /// canal no abre (.ts ↔ .m3u8) y avance guardado.
    /// </summary>
    public static class Playback
    {
        public static MpvPlayer Main { get; private set; }
        public static Media Current { get; private set; }
        public static List<Media> Queue { get; private set; } = new List<Media>();
        public static int Index { get; private set; }
        public static string Notice { get; private set; }
        public static string LastError { get; private set; }
        public static bool Paused => Main != null && Main.Paused;

        private static volatile bool _busy;
        /// <summary>Se está viendo algo (lo leen tareas de fondo para no competir con el video).</summary>
        public static bool Busy => _busy || MultiOpen;
        public static volatile bool MultiOpen;

        public static event Action Changed;
        public static event Action<Cloud.Decision> Denied;
        public static event Action Ended;

        private static int _seq;
        private static int _netRetry;
        private static int _liveEnds;
        private static bool _formatTried;
        private static bool _loaded;
        private static double _lastGoodPos;
        private static DateTime _bufferSince = DateTime.MinValue;
        private static double _bufferMark;
        private static DispatcherTimer _tick;
        private static DispatcherTimer _poll;
        private static int _pollRetry;
        private static DateTime _lastSave = DateTime.MinValue;

        private static void Fire()
        {
            var h = Changed;
            if (h != null) h();
        }

        public static void Attach(MpvPlayer p)
        {
            Main = p;
            p.FileLoaded += () => UiThread.Post(OnLoaded);
            p.PlaybackRestart += () => UiThread.Post(OnRestart);
            p.EndFile += (reason, err) => UiThread.Post(() => OnEnd(reason, err));
            p.StateChanged += () => UiThread.Post(Fire);
            if (_tick == null) _tick = UiThread.Every(1000, Tick);
        }

        // ------------------------------------------------------------- reproducir

        public static void PlayChannel(Item it, bool preview = false)
        {
            var m = Media.ForChannel(it);
            Play(m, 0, null, 0, preview);
        }

        public static async void Play(Media m, double startSecs = 0, List<Media> queue = null, int index = 0, bool preview = false)
        {
            if (Main == null || m == null) return;
            SaveProgress(true);
            // Mantener el canal anterior mientras Cloud autoriza el siguiente.
            // Cerrar el vídeo antes del HTTP añadía pantalla negra a cada cambio.
            int my = ++_seq;
            Current = m;
            Queue = queue != null && queue.Count > 0 ? queue : new List<Media> { m };
            Index = Math.Max(0, Math.Min(index, Queue.Count - 1));
            Notice = "Conectando…";
            LastError = null;
            _loaded = false;
            _netRetry = 0;
            _liveEnds = 0;
            _formatTried = false;
            _lastGoodPos = startSecs;
            StopPoll();
            Main.SetMute(preview);
            Fire();
            // Cada reproducción requiere autorización de Cloud (sin datos guardados).
            var d = await Cloud.Verify();
            if (my != _seq || Current != m) return;
            if (!d.Allowed)
            {
                StopInternal();
                LastError = d.Message;
                Fire();
                Denied?.Invoke(d);
                return;
            }
            // El panel puede enviar una URL de servidor nueva al renovar la sesión.
            // No intentar la URL creada ANTES de validar: podría apuntar al DNS anterior.
            var a = Prefs.Account();
            if (m.IsLive && m.Channel != null)
                m.Url = Xtream.LiveUrl(a, m.Channel.Id, Prefs.S.LiveFormat == "m3u8" ? "m3u8" : "ts");
            else if (m.Kind == Kind.Movie)
                m.Url = Xtream.MovieUrl(a, J.ToInt(m.Id), m.Ext);
            else if (m.Kind == Kind.Episode)
                m.Url = Xtream.EpisodeUrl(a, m.Id, m.Ext);
            _busy = true;
            Main.Load(m.Url, m.IsLive ? 0 : startSecs);
            if (m.IsLive && m.Channel != null)
            {
                Prefs.S.LastLiveId = m.Channel.Id;
                Prefs.Save();
                if (!preview) Library.AddRecentLive(m.Channel.Id);
            }
            StartPoll();
            Fire();
        }

        public static void PlayAt(int i)
        {
            if (i < 0 || i >= Queue.Count) return;
            var q = Queue;
            Play(q[i], StartFor(q[i]), q, i);
        }

        public static bool HasNext => Current != null && Index < Queue.Count - 1;
        public static bool HasPrev => Current != null && Index > 0;
        public static void Next() { if (HasNext) PlayAt(Index + 1); }
        public static void Prev() { if (HasPrev) PlayAt(Index - 1); }

        /// <summary>Segundo donde quedó (si no terminó).</summary>
        public static double StartFor(Media m)
        {
            if (m == null || m.IsLive) return 0;
            if (m.Kind == Kind.Episode)
            {
                var p = Library.EpisodeProgress(m.Id);
                if (p != null && p[1] > 0 && p[0] < p[1] - 60_000 && p[0] > 30_000) return p[0] / 1000.0;
                return 0;
            }
            var h = Library.Of(m.HistoryKey);
            if (h != null && h.Dur > 0 && h.Pos < h.Dur - 60_000 && h.Pos > 30_000) return h.Pos / 1000.0;
            return 0;
        }

        public static void Stop()
        {
            SaveProgress(true);
            _seq++;
            StopInternal();
            Fire();
        }

        private static void StopInternal()
        {
            StopPoll();
            Main?.Stop();
            Current = null;
            Notice = null;
            _busy = false;
            _loaded = false;
            var t = HistorySync.FlushAsync();
        }

        /// <summary>Pausa / sigue. Reanudar vuelve a consultar Cloud.</summary>
        public static async void TogglePause()
        {
            if (Main == null || Current == null) return;
            if (!Main.Paused)
            {
                Main.SetPause(true);
                SaveProgress(true);
                var t = HistorySync.FlushAsync();
                Fire();
                return;
            }
            int my = _seq;
            var d = await Cloud.Verify();
            if (my != _seq || Current == null) return;
            if (!d.Allowed)
            {
                StopInternal();
                LastError = d.Message;
                Fire();
                Denied?.Invoke(d);
                return;
            }
            if (!_loaded || Main.CoreIdle && Main.Position <= 0) Reconnect();
            else Main.SetPause(false);
            Fire();
        }

        public static void Seek(double deltaSecs)
        {
            if (Main == null || Current == null || Current.IsLive) return;
            Main.SeekRelative(deltaSecs);
        }

        public static void SeekTo(double secs)
        {
            if (Main == null || Current == null || Current.IsLive) return;
            Main.SeekAbsolute(secs);
        }

        // ------------------------------------------------------------ autorización

        private static void StartPoll()
        {
            StopPoll();
            _pollRetry = 0;
            _poll = UiThread.After(25000, PollNow);
        }

        private static void StopPoll()
        {
            _poll?.Stop();
            _poll = null;
        }

        private static async void PollNow()
        {
            if (Current == null) return;
            int my = _seq;
            var d = await Cloud.Verify();
            if (my != _seq || Current == null) return;
            // Un tropiezo de internet: se pregunta otra vez a los 4 s antes de cortar.
            if (!d.Allowed && d.Reason == "cloud_unavailable" && _pollRetry < 1)
            {
                _pollRetry++;
                _poll = UiThread.After(4000, PollNow);
                return;
            }
            _pollRetry = 0;
            if (!d.Allowed)
            {
                SaveProgress(true);
                StopInternal();
                LastError = d.Message;
                Fire();
                Denied?.Invoke(d);
                return;
            }
            _poll = UiThread.After(25000, PollNow);
        }

        // --------------------------------------------------------------- eventos

        private static void OnLoaded()
        {
            _loaded = true;
            Fire();
        }

        private static void OnRestart()
        {
            if (Notice != null) Notice = null;
            LastError = null;
            Fire();
        }

        private static void OnEnd(int reason, int error)
        {
            var m = Current;
            if (m == null || Main == null) return;
            if (reason == MpvNative.EndStop || reason == MpvNative.EndQuit) return;
            if (reason == MpvNative.EndEof)
            {
                if (m.IsLive)
                {
                    // El servidor cortó la transmisión (pasa en IPTV): se vuelve a abrir solo.
                    if (_liveEnds < 15)
                    {
                        _liveEnds++;
                        int my = _seq;
                        UiThread.After(300 * _liveEnds, () => { if (my == _seq && Current == m) Reconnect(_liveEnds > 2 ? "Reconectando…" : null); });
                    }
                    else
                    {
                        LastError = "El canal dejó de transmitir. Elige otro o vuelve a intentar.";
                        _busy = false;
                        Fire();
                    }
                    return;
                }
                // Terminó la película / episodio.
                if (Main.Duration > 0) SaveEntry(m, (long)(Main.Duration * 1000), (long)(Main.Duration * 1000));
                _busy = false;
                Ended?.Invoke();
                if (m.Kind == Kind.Episode && Prefs.S.AutoNext && HasNext)
                {
                    int my = _seq;
                    UiThread.After(1500, () => { if (my == _seq) Next(); });
                }
                Fire();
                return;
            }
            // Error al abrir o se cayó la conexión.
            if (m.IsLive && !_formatTried && (_netRetry >= 2 || !_loaded))
            {
                string alt = AltFormat(m.Url);
                if (alt != null)
                {
                    _formatTried = true;
                    m.Url = alt;
                    Reconnect("Conectando…");
                    return;
                }
            }
            int max = m.IsLive ? 40 : 24;
            if (_netRetry < max)
            {
                _netRetry++;
                Notice = _netRetry <= 2 ? "Reconectando…" : "Reconectando… (" + _netRetry + ")";
                Fire();
                int my = _seq;
                UiThread.After(RetryDelay(_netRetry), () => { if (my == _seq && Current == m) Reconnect(Notice); });
                return;
            }
            Notice = null;
            _busy = false;
            LastError = m.IsLive ? "Este canal no está disponible ahora. Prueba otro." : "No se pudo reproducir. Revisa tu internet y vuelve a intentar.";
            Fire();
        }

        private static int RetryDelay(int n)
        {
            switch (n)
            {
                case 1: return 400;
                case 2: return 1000;
                case 3: return 2000;
                case 4: return 3000;
                case 5: return 4000;
                default: return 5000;
            }
        }

        private static string AltFormat(string url)
        {
            int q = url.IndexOf('?');
            string path = q >= 0 ? url.Substring(0, q) : url;
            string query = q >= 0 ? url.Substring(q) : "";
            if (path.EndsWith(".m3u8", StringComparison.OrdinalIgnoreCase)) return path.Substring(0, path.Length - 5) + ".ts" + query;
            if (path.EndsWith(".ts", StringComparison.OrdinalIgnoreCase)) return path.Substring(0, path.Length - 3) + ".m3u8" + query;
            return null;
        }

        /// <summary>Conexión nueva al mismo contenido (en vivo al directo; película en el último segundo bueno).</summary>
        public static void Reconnect(string notice = "Reconectando…")
        {
            var m = Current;
            if (m == null || Main == null) return;
            Notice = notice;
            LastError = null;
            _busy = true;
            double pos = m.IsLive ? 0 : Math.Max(Main.Position, _lastGoodPos);
            bool muted = Main.Muted;
            Main.Load(m.Url, pos);
            Main.SetMute(muted);
            _bufferSince = DateTime.MinValue;
            Fire();
        }

        /// <summary>Cada segundo: vigilante de carga y avance guardado.</summary>
        private static void Tick()
        {
            var m = Current;
            var p = Main;
            if (m == null || p == null) return;
            if (!m.IsLive && p.Position > 1) _lastGoodPos = p.Position;
            // Reproduce bien: se reinician los reintentos.
            if (!p.Buffering && !p.CoreIdle && p.Position > 0)
            {
                if (_netRetry > 0 || _liveEnds > 0) { _netRetry = 0; _liveEnds = 0; }
                if (Notice != null) { Notice = null; Fire(); }
                _bufferSince = DateTime.MinValue;
            }
            // Se quedó cargando sin recibir datos: conexión nueva (8 s en vivo, 20 s películas).
            if (_loaded && !p.Paused && (p.Buffering || (p.CoreIdle && p.Position <= 0)))
            {
                if (_bufferSince == DateTime.MinValue)
                {
                    _bufferSince = DateTime.UtcNow;
                    _bufferMark = p.CacheSecs;
                }
                else
                {
                    double limit = m.IsLive ? 8 : 20;
                    if ((DateTime.UtcNow - _bufferSince).TotalSeconds > limit)
                    {
                        if (p.CacheSecs > _bufferMark + 0.7)
                        {
                            // Los datos siguen llegando (internet lento): se espera.
                            _bufferSince = DateTime.UtcNow;
                            _bufferMark = p.CacheSecs;
                        }
                        else Reconnect();
                    }
                }
            }
            if (!m.IsLive && !p.Paused && (DateTime.UtcNow - _lastSave).TotalSeconds >= 10) SaveProgress(false);
        }

        // ----------------------------------------------------------------- avance

        public static void SaveProgress(bool force)
        {
            var m = Current;
            var p = Main;
            if (m == null || p == null || m.IsLive) return;
            double dur = p.Duration, pos = p.Position;
            if (dur <= 0 || pos < 1) return;
            _lastSave = DateTime.UtcNow;
            SaveEntry(m, (long)(pos * 1000), (long)(dur * 1000));
        }

        private static void SaveEntry(Media m, long pos, long dur)
        {
            Library.SaveProgress(new HistoryEntry
            {
                Key = m.HistoryKey,
                Kind = m.Kind,
                Id = m.Id,
                SeriesId = m.SeriesId,
                Season = m.Season,
                Episode = m.EpisodeNum,
                Title = m.Title,
                Subtitle = m.Subtitle,
                Image = m.Image,
                Wide = m.Wide,
                Ext = m.Ext,
                Pos = pos,
                Dur = dur
            });
        }
    }
}
