# Pruebas manuales Windows (pendientes)
- Abrir Inicio: confirmar marca 1.0.5.
- Abrir TV: título del canal truncado dentro del video; Atrás, Canal +/- y Silenciar visibles.
- Reproducir película y episodio: controles abajo, sin solapamiento a 960px y 1366px de ancho.
- Multipantalla: alternar 2, 3 y 4; verificar ratio 16:9, marco completo y etiquetas dentro del mosaico; redimensionar 960x600 a pantalla completa.
- Cambiar canal 5 veces: no se deben solapar solicitudes; validar cuenta en cada reproducción.
- Si falla panel: consultar %LOCALAPPDATA%\PTVPlus\log.txt. No se debe suponer cuenta autorizada.
- Confirmar que no aparecen reproductores VLC ni ventanas independientes en la barra de tareas.
