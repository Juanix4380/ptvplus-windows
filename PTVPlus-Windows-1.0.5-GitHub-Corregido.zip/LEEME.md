# PTV Plus Windows 1.0.5 — GitHub Actions

Esta es una versión de CÓDIGO FUENTE para compilar. No ha sido ejecutada ni probada en Windows dentro de este entorno.

## Compilación
1. Descomprime el ZIP.
2. Sube su **contenido** a un repositorio GitHub (no una carpeta exterior).
3. Comprueba que `.github/workflows/build.yml` esté en el repositorio.
4. GitHub → Actions → **PTV Plus Windows 1.0.5 - Compilar** → Run workflow.
5. Descarga el artefacto **PTVPlus-Windows-1.0.5-EXE** si termina correctamente.

## Correcciones de código
- Multipantalla: diseño 2/3/4 mosaicos 16:9 limitado al área visible; etiquetas y marcos recortados y alineados.
- TV: nombre del canal dentro del área de video y botón Atrás.
- Películas y series: botones en dos filas junto al borde inferior para evitar solapamientos.
- Validación: registra el detalle de FileLoadException y presenta el error en el reproductor, sin diálogos emergentes para ese caso.
- Publicación: se desactiva la compresión y extracción forzada de ensamblados administrados del EXE para reducir errores de carga, sin garantizar que sea la causa.

## ¿Sigue apareciendo FileLoadException?
Abre `%LOCALAPPDATA%\PTVPlus\log.txt` desde el PC Windows y comparte solo las líneas `ERROR Cloud session/status` y `ERROR Cloud login revalidación`, **borrando direcciones privadas, tokens o credenciales si aparecen**. La reproducción no se habilita sin autorización válida del panel.

## Limitación sobre ventanas
El reproductor mpv dibuja con una ventana hija de Windows dentro de PTV Plus. El proyecto WPF también usa una capa transparente propietaria para mostrar controles encima del video. No abre VLC ni reproductores externos; esta versión no reemplaza todavía la capa por un renderizador completamente integrado en una única HWND.
